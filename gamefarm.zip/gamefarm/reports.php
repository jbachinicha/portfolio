<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
	if(isset($_POST['add'])){
	    include 'connection.php';
	    $name=addslashes($_POST['name']);
	    $price=floatval($_POST['price']);

	    $query="INSERT INTO expenses VALUES('','$name','$price','0')";
	    $result=mysqli_query($con,$query);
	    if($result===false){$err_msg=mysqli_error($con);$err=true;}
	    mysqli_close($con);
	}

    if(isset($_POST['update'])){
    	include 'connection.php';
    	$code=$_POST['code'];
    	$name=addslashes($_POST['name']);
	    $price=floatval($_POST['price']);
    	$query="UPDATE expenses SET name='$name', price='$price' WHERE code='$code'";

    	$result=mysqli_query($con,$query);
    	if($result===false){$err_msg=mysqli_error($con);$err=true;}
    	mysqli_close($con);
  	}	

  	if(isset($_POST['stockin']) || isset($_POST['expired']) || isset($_POST['damaged'])){
  		include 'connection.php';
  		$code=$_POST['code'];
  		$name=$_POST['name'];
  		$qty=intval($_POST['qty']);
  		$price=floatval($_POST['price']);
  		$units=intval($_POST['units']);
  		$value=$qty*$price;
  		$date=gd();
  		$date=fd($date,'Y-m-d');
  		$time=gd();
  		$time=fd($time,'H:i:s');
  		$sql;
  		$action=(isset($_POST['stockin']))?'Purchased':(((isset($_POST['damaged'])))?'Damaged':'Expired');

  		mysqli_query($con,"BEGIN");
  		if(isset($_POST['stockin'])){
  			$sql="UPDATE expenses SET qty=qty+'$qty' WHERE code='$code'";
  		}else{
  			$sql="UPDATE expenses SET qty=qty-'$qty' WHERE code='$code'";
  		}
  		$sql1="INSERT INTO expensestockhistory VALUES('','$code','$name','$price','$action','$qty','$value','$date','$time')";
  		ae($name,$action,$value);
  		$r=mysqli_query($con,$sql);
  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
  		$r1=mysqli_query($con,$sql1);
  		if($r1===false){$err_msg=mysqli_error($con);$err=true;}
  		if($err){
  			mysqli_query($con,"ROLLBACK");
  		}else{
  			mysqli_query($con,"COMMIT");
  		}
  		mysqli_close($con);
  	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Reports</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button class='mr10' id="salesbtn">Sales</button>
					<button class='mr10' id="expensestn">Expenses</button>
					<button class='mr10' id="incomebtn">Income</button>
				</div>
			</div>
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<!--<div class="input">
						<label>Date From</label>
						<input type="date" id="dateFrom">
					</div>
					<div class="input mr10">
						<label>Date To</label>
						<input type="date" id="dateTo">
					</div>-->
					<button class='mr10 opps' id="dailybtn">Daily</button>
					<button class='mr10 opps' id="weeklybtn">Weekly</button>
					<button class='mr10 opps' id="monthlybtn">Monthly</button>
					<button class='mr10 opps' id="yearlybtn">Yearly</button>
					<button class='mr10' id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Reports</label>
					<input type="text" id="searchTxt" style="width: 300px;">
				</div>
			</div>
			<div class="table-wrapper" id="myTable"></div>
		</div>
	</div>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Reports';
		$('.pagemenus a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		$('#printpage').on('click',function(){window.print();});
		var m=new Modal(['addForm','updateForm','choiceMenu','inventoryForm']);
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;
		$('#expenselistbtn').on('click',function(){
			data=$('#myTable').DataTable({
				tableLabel:'Report History',
				filterSelector:'#searchTxt',
				getLink:'getReports.php',
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Price',name:'price',format:'cur'},
					{label:'Quantity',name:'qty',format:'wnum'}
				],
				tableLimit: 30,
			});
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		$("#stockhisotrybtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			var sh=$('#myTable').DataTable({
				tableLabel:'Report Stock History',
				filterSelector:'#searchTxt',
				getLink:'getStockHistory.php',
				requestData: {filter:'expense'},
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Action',name:'action'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Value',name:'value',format:'cur'},
					{label:'Date',name:'date'},
					{label:'Time',name:'time'},
				],
				tableLimit:30,
			});
		});
		$('#expenselistbtn').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>