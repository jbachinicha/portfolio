<?php
	include 'session.php';

	include 'connection.php';
	date_default_timezone_set('Asia/Manila');
	$date=date('Y-m-d');

	$r=mysqli_query($con,"SELECT pt.code,pt.name,pt.description,p.* FROM sales AS p INNER JOIN products AS pt ON p.product_code=pt.code WHERE transaction_no IN (SELECT MAX(transaction_no) FROM sales)");
	$count=0;echo mysqli_error($con);
	$myArr=array();
	while($rw=mysqli_fetch_assoc($r)){
		$arr['name']=$rw['name'];
		$arr['description']=$rw['description'];
		$arr['t_no']=intval($rw['transaction_no']);
		$arr['sqty']=intval($rw['quantity']);
		$arr['price']=floatval($rw['price']);
		$arr['sub']=intval($rw['subtotal']);
		$arr['grand']=floatval($rw['grandtotal']);
		$arr['payment']=floatval($rw['payment']);
		$arr['change']=floatval($rw['vchange']);
		$arr['sub']=floatval($rw['subtotal']);
		$date=date_create($rw['date']);
		$date=date_format($date,'F d, Y');
		$arr['date']=$date;
		$time=date_create($rw['time']);
		$time=date_format($time,'h:i:s A');
		$arr['time']=$time;
		array_push($myArr,$arr);
	}
	echo "<script>var data = ".json_encode($myArr)."</script>";

?>
<!DOCTYPE html>
<html>
<head>
	<title>Receipt</title>
	<style type="text/css">
		html,body{
			width: 100%;
			height: 100%;
			padding: 0;
			margin: 0;
			font-family: Arial;
			font-size: 14px;
		}

		.table-header{
			font-size: 16px;
			font-weight: bold;
			margin-bottom: 10px;
		}

		.aw{
			width: calc(100% - 20px);
			height: calc(100% - 20px);
			padding: 10px 0px 10px 10px;
		}

		table{
			width: 100%;
			border-collapse: collapse;
			margin-bottom: 5px;
		}
		tr{border: 1px solid black;}
		tr:nth-child(2n+1){background-color: rgba(0,0,0,0);}
		th{font-size: 16px;text-align: left;padding: 5px 5px;}
		td{padding: 5px 5px;}
		@media print{
			table {page-break-inside:auto;}
		 	tr    {page-break-inside:avoid; page-break-after:auto;}
		}
		.mb05{margin-bottom: 5px;}
		.mb10{margin-bottom: 10px;}
		.mb15{margin-bottom: 15px;}
		.mb20{margin-bottom: 20px;}
		.flex{display: flex;}
		.tar{text-align: right;}
		.tal{text-align: left;}
		.tac{text-align: center;}
		.bold{font-weight: bold;}
		.large{font-size: 30px;}
		.medium{font-size: 24px;}
		.small{font-size: 18px;}
		.header{
			font-family: Arial !important;
			color: black;
		}
		.row{display: flex;flex-direction: column;}
		.col{display: flex;flex-direction: row;}
		.spb{justify-content: space-between;}
		.fe{justify-content: flex-end;}
	</style>
</head>
<body>
	<div class="aw">
		<div class="header large bold tac mb20">Lola Kaps Chicharon Receipt</div>
		<div class="col spb">
			<div class="small mb05" id="t_no"></div>
			<div class="small mb05" id="date"></div>
		</div>
		<table>
			<thead>
				<tr>
					<th>Product</th>
					<th style='width: 20px; white-space: nowrap; text-align: center;'>Price</th>
					<th style="width: 20px; white-space: nowrap;">Qty</th>
					<th style="width: 20px;">SubTotal</th>
				</tr>
			</thead>
			<tbody id="table">
				
			</tbody>
		</table>
		<div class="row">
			<div class="small" id="titxt"></div>
			<div class="small" id="trtxt"></div>
			<div class="small" id="aptxt"></div>
			<div class="small" id="chtxt"></div>
		</div>
	</div>
	<script>
		var table = document.getElementById('table'),
		ti = document.getElementById('titxt'),
		tr = document.getElementById('trtxt'),
		ap = document.getElementById('aptxt'),
		ch = document.getElementById('chtxt'),
		date = document.getElementById('date'),
		t_no = document.getElementById('t_no'),
		tItems,totalItems,totalRevenue,transaction_no,payment,change,grandtotal,today,transaction_no,time;
		function cv(obj){
			return JSON.parse(JSON.stringify(obj));
		}

		function nf(a,b){
			if(b==='whole'){
				let h = a.toFixed(2);
				if(h.indexOf('.00')>0){
					return parseFloat(a).toLocaleString('en');		
				}
			}else{
				return parseFloat(a).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,')	
			}
		}

		function refreshTable(){
			tItems=cv(data);
			totalItems=0;
			tItems.forEach((el)=>{
				let name = el.name;
				if(typeof el.size !== 'undefined'){
					name+=el.size!==''?' ('+el.size+')':'';	
				}
				name+=el.description!==''?' ('+el.description+')':'';
				table.insertAdjacentHTML('beforeend',`
					<tr>
						<td>`+name+`</td>
						<td style='width: 20px; white-space: nowrap; text-align: center;'>&#8369;`+nf(el.price)+`</td>
						<td style='width: 20px; white-space: nowrap; text-align: center;'>`+el.sqty+`</td>
						<td style='width: 20px;text-align: right'>&#8369;`+nf(el.sub)+`</td>
					</tr>
				`);
				totalRevenue+=el.sub;
				totalItems++;
				transaction_no=el.transaction_no;
				grandtotal=el.grand;
				payment=el.payment;
				change=el.change;
				today=el.date;
				time=el.time;
				transaction_no=el.t_no;
			});
			ti.innerHTML = "Total Number of Items Sold: "+nf(totalItems,'whole');
			ap.innerHTML = "Amount Paid: &#8369;"+nf(payment);
			ch.innerHTML = "Change: &#8369;"+nf(change);
			tr.innerHTML = "Total: &#8369;"+nf(grandtotal);
			date.innerHTML = "Date: "+today+" - "+time;
			t_no.innerHTML = "Transaction Number: "+transaction_no;
		}

		refreshTable();
	</script>
	<script>window.print();</script>
</body>
</html>