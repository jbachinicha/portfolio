<?php
	include 'connection.php';

	$a=json_decode(file_get_contents('php://input'),true);
	$myArr=array('status'=>'','message'=>'','data'=>array());

	date_default_timezone_set('Asia/Manila');
	$date=date('Y-m-d');
	$time=date('H:i:s');

	$tno=$a['transaction_no'];
	$grandtotal=$a['grandTotal'];
	$payment=$a['payment'];
	$change=$a['change'];
	$items=$a['items'];
	
	mysqli_query($con,"BEGIN");
	for($x=0;$x<count($items);$x++){$arr=array();
		$code=$items[$x]['code'];
		$price=$items[$x]['price'];
		$qty=$items[$x]['qty'];
		$subtotal=$items[$x]['subtotal'];
		$r=mysqli_query($con,"INSERT INTO sales VALUES ('','$tno','$code','$price','$qty','$subtotal','$grandtotal','$payment','$change','$date','$time')");
		array_push($arr,mysqli_error($con));
		$r1=mysqli_query($con,"UPDATE products set qty=qty-'$qty' WHERE code='$code'");
		array_push($arr,$r);
		array_push($arr,$r1);
		array_push($myArr['data'],$arr);
		if($r===false || $r1===false){
			mysqli_query($con,"ROLLBACK");
			$myArr['status']='error';
			$myArr['message']=mysqli_error($con);
			exit(json_encode($myArr));
		}
	}
	sleep(1);
	mysqli_query($con,"COMMIT");
	$myArr['status']='success';
	echo json_encode($myArr);
?>