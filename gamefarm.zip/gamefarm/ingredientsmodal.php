<div class='modal' style='display: none;'>
    <form name='choiceMenu' style='display: none;'>
      <header>
          <label>Choose Action</label>
          <span title='Close'><div><div>&times;</div><div></span>
      </header>
      <div class='choice-menu'>
        <button class='mb10' name='choicemenu1'>Update Feed Information</button>
        <button class='mb10' name='choicemenu2'>Manage Inventory</button>
      </div>
    </form>
    <form name='addForm' action='' method='post' style='display: none;'>
      <header>
        <label>Add New Feed</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width: 300px;'>
          <div class='form-header'>Feed Information</div>
          <div class='form-content'>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Description</label>
              <input type='text' name='des' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Units</label>
              <input type='number' step='1' min='1' name='units' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Unit Label</label>
              <input type='text' name='unitlabel' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Price</label>
              <input type='number' name='price' step='0.01' min='0' required autocomplete>
            </div>
            <!--<div class='input-btn'>
              <span class='btn'>&plus; Add Feed</span>
            </div>-->
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='add' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='updateForm' action='' method='post' style='display: none;'>
      <header>
        <label>Update Feed Information</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <div class='input mb10'>
              <label>Code</label>
              <input type='text' name='code' readonly>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Description</label>
              <input type='text' name='des' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Units</label>
              <input type='number' step='1' min='1' name='units' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Unit Label</label>
              <input type='text' name='unitlabel' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Price</label>
              <input type='number' name='price' step='0.01' min='0' required autocomplete>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='update' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='inventoryForm' action='' method='post' style='display: none;'>
      <header>
        <label>Manage Ingredient Inventory</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <input type='hidden' name='price'>
            <input type='hidden' name='units'>
            <div class='input mb10'>
              <label>Code</label>
              <input type='text' name='code' readonly>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' readonly>
            </div>
            <div class='input mb10'>
              <label>In Stock Quantity</label>
              <input type='text' name='instockqty' readonly>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Quantity</label>
              <input type='number' name='qty' step='0.01' min='0.01' required autocomplete autofocus>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='stockin' style='width: 50%; padding: 10px 20px;font-size: 16px;'>Purchase</button>
        <button name='expired' style='width: 50%; padding: 10px 20px;font-size: 16px;'>Expired</button>
      </div>
    </form>
  </div>