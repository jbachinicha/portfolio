<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
	if(isset($_POST['add'])){
	    include 'connection.php';
	    $name=addslashes($_POST['name']);
	    $price=floatval($_POST['price']);

	    $query="INSERT INTO equipments VALUES('','$name','$price','0')";
	    $result=mysqli_query($con,$query);
	    if($result===false){$err_msg=mysqli_error($con);$err=true;}
	    mysqli_close($con);
	}

    if(isset($_POST['update'])){
    	include 'connection.php';
    	$code=$_POST['code'];
    	$name=addslashes($_POST['name']);
	    $price=floatval($_POST['price']);
    	$query="UPDATE equipments SET name='$name', price='$price' WHERE code='$code'";

    	$result=mysqli_query($con,$query);
    	if($result===false){$err_msg=mysqli_error($con);$err=true;}
    	mysqli_close($con);
  	}	

  	if(isset($_POST['stockin']) || isset($_POST['expired']) || isset($_POST['damaged'])){
  		include 'connection.php';
  		$code=$_POST['code'];
  		$name=$_POST['name'];
  		$qty=intval($_POST['qty']);
  		$price=floatval($_POST['price']);
  		$units=intval($_POST['units']);
  		$value=$qty*$price;
  		$date=gd();
  		$date=fd($date,'Y-m-d');
  		$time=gd();
  		$time=fd($time,'H:i:s');
  		$sql;
  		$action=(isset($_POST['stockin']))?'Purchased':(((isset($_POST['damaged'])))?'Damaged':'Expired');

  		mysqli_query($con,"BEGIN");
  		if(isset($_POST['stockin'])){
  			$sql="UPDATE equipments SET qty=qty+'$qty' WHERE code='$code'";
  		}else{
  			$sql="UPDATE equipments SET qty=qty-'$qty' WHERE code='$code'";
  		}
  		$sql1="INSERT INTO equipmentstockhistory VALUES('','$code','$name','$price','$action','$qty','$value','$date','$time')";
  		ae($name,$action,$value);
  		$r=mysqli_query($con,$sql);
  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
  		$r1=mysqli_query($con,$sql1);
  		if($r1===false){$err_msg=mysqli_error($con);$err=true;}
  		if($err){
  			mysqli_query($con,"ROLLBACK");
  		}else{
  			mysqli_query($con,"COMMIT");
  		}
  		mysqli_close($con);
  	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Equipments</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
  	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button id="openDialogNew" class="mr10">New Equipment</button>
					<button id="equipmentlistbtn" class="mr10">Equipment List</button>
					<button id="stockhisotrybtn" class="mr10">Stock History</button>
					<button id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Equipments</label>
					<input type="text" id="searchTxt" style="width: 300px;">
				</div>
			</div>
			<div class="table-wrapper" id="myTable"></div>
		</div>
	</div>
	<?php include 'equipmentsmodal.php'; ?>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Equipments';
		$('.nav-title p').html('Equipments');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		$('#printpage').on('click',function(){window.print();});
		var m=new Modal(['addForm','updateForm','choiceMenu','inventoryForm']);
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;
		$('#equipmentlistbtn').on('click',function(){
			data=$('#myTable').DataTable({
				tableLabel:'Equipment Lists',
				filterSelector:'#searchTxt',
				getLink:'getEquipments.php',
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Price',name:'price',format:'cur'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Value',name:'value',format:'cur'},
				],
				onHoverTitle:'Click to update equipment',
				tableLimit:14,
				onClick:function(e){
					var target=e.currentTarget;
		  			var code=target.children[0].innerHTML;
		  			var equipment=data.find(code,'code','int');
		  			m.show('choiceMenu');
		  			m.forms.choiceMenu.find('button[name=choicemenu1]').on('click',function(e){
		  				e.preventDefault();
		  				m.show('updateForm');
		  				m.forms.updateForm.find("input[name='code']").val(equipment.code);
			  			m.forms.updateForm.find("input[name='name']").val(equipment.name);
			  			m.forms.updateForm.find("input[name='price']").val(equipment.price);
		  			});
		  			m.forms.choiceMenu.find('button[name=choicemenu2]').on('click',function(e){
		  				e.preventDefault();
		  				m.show('inventoryForm');
		  				m.forms.inventoryForm.find("input[name='code']").val(equipment.code);
			  			m.forms.inventoryForm.find("input[name='name']").val(equipment.name);
			  			m.forms.inventoryForm.find("input[name='price']").val(equipment.price);
			  			m.forms.inventoryForm.find("input[name='instockqty']").val(equipment.qty);
		  			});
						
				}
			});
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		$("#stockhisotrybtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			var sh=$('#myTable').DataTable({
				tableLabel:'Equipment Stock History',
				filterSelector:'#searchTxt',
				getLink:'getStockHistory.php',
				requestData: {filter:'equipment'},
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Action',name:'action'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Value',name:'value',format:'cur'},
					{label:'Date',name:'date'},
					{label:'Time',name:'time'},
				],
				tableLimit:30,
			});
		});
			
		$("form[name=updateForm]").on('submit',function(e){
			var code=$("form[name=updateForm] input[name=code]").val();
	  		var equipment=data.find(code,'code','int');
			if(!confirm(`Are you sure you want to change the details of '`+equipment.name+`'?`)){
				e.preventDefault();
			}
		});
		$("form[name=inventoryForm]").on('submit',function(e){
			var btn=$("form[name=inventoryForm] button:focus").attr('name');
			var code=$("form[name=inventoryForm] input[name=code]").val();
			var qty=parseInt($("form[name=inventoryForm] input[name=qty]").val());
	  		var equipment=data.find(code,'code','int');
	  		flag=false;
	  		if(btn==='expired' || btn==='damaged'){
	  			if((equipment.qty-qty)<0){
	  				e.preventDefault();
	  				alert('Cannot add '+btn+' equipments more than its quantity');
	  			}
	  		}
		});
		$('#equipmentlistbtn').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>