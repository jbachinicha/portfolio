$.fn.PayslipPlugin=function(obj){
  var link=obj.getLink,
  tableColumns=obj.tableColumns,
  ajaxProperties=obj.ajaxDataProperties,
  payrollData=[],
  payrollPeriod='',
  payrollStart='',
  payrollEnd='',
  today='',
  totalSalaries=0,
  tableWrapper=$(this);
  tableWrapper.html('');

  function showData(){
    payrollData.forEach(function(el){
      tableWrapper.append(`
        <div class='row' style='border: 2px solid black;padding: 10px 20px;font-size: 12px;'>
          <center><label style='font-weight: bold;font-size: 14px;'>Pay Slip</label></center>
          <div class='row' style='margin-top: 10px;'>
            <div class='col'>
              <label style='width: 50%;'>Name: `+el.name+`</label>
              <label style='width: 50%;'>Date: `+today+`</label>
            </div>
            <div class='col' style='margin-top: 5px;'>
              <label style='width: 50%;'>Position: `+el.position+`</label>
            </div>
            <div class='col' style='margin-top: 5px;'>
              <label style='width: 100%;'>Payroll Period: `+payrollStart+` to `+payrollEnd+`</label>
            </div>
            <div class='col' style='margin-top: 5px;'>
              <label style='width: 50%;'>Hourly Rate: &#8369;`+$.formatNumber(el.hourly_rate)+`</label>
            </div>
            <div class='col' style='margin-top: 5px;margin-bottom: 10px;'>
              <label style='width: 50%;'>Total Hours Worked: `+$.formatNumber(el.hours_worked,'whole')+`</label>
            </div>
            <table>
              <tbody>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Gross Salary:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.gross_salary)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Deductions:</td>
                  <td class='payslip'>&nbsp;</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>SSS Contribution:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.sss)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Philhealth Contribution:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.philhealth)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Pag-ibig Contribution:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.pagibig)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Cash Advance:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.cash_advance)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Total Deductions:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.deductions)+`</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>&nbsp;</td>
                  <td class='payslip'>&nbsp;</td>
                </tr>
                <tr style='cursor:default;background-color:transparent !important;'>
                  <td class='payslip'>Net Salary:</td>
                  <td class='payslip'>&#8369;`+$.formatNumber(el.net_salary)+`</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class='print-gap'></div>
      `);
    });    
  }

  function getData(){
    $.ajax(link).then(function(r){
      payrollData=$.convert(r.data);
      payrollStart=r.startDate;
      payrollEnd=r.endDate;
      totalSalaries=r.totalSalaries;
      today=r.today;
      console.log(r);
      showData();
    }); 
  }
  getData();
}