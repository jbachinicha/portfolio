window.modals=[];
function Modal(formSelectors){
	var modal_holder=$('.modal');
	var me=this;
	me.status='hidden';
	me.name='';
  me.forms={};
  formSelectors.forEach(function(el){
    me.forms[el]=$("form[name='"+el+"']");
  });

	me.show=function(key){
		modal_holder.css('display','flex');
		me.status='shown';
		me.name=key;
		me.forms[key].css('display','flex');
		var flag=false;
		Object.keys(me.forms).forEach(function(k){
			if(k==='choiceMenu'){flag=true;}
		});
		if(flag){
			if(key!=='choiceMenu'){
				me.forms['choiceMenu'].css('display','none');
			}	
		}
		$('[autofocus]').focus();
	}
	me.hide=function(){
		var pre = (typeof activeTab!=='undefined')?activeTab.toLowerCase():'';
		if(me.name!=='payrollForm'){
			$(".modal > form > content input:not([type='radio']:not([type='checkbox']))").val('');
		}else{
			$("form[name=payrollForm] input[name*='hw']").val('');
			$("form[name=payrollForm] input[name*='hw']").keyup();
		}
		
		$('.modal > form > content img').attr('src',pre+'/nopreview.png');
		modal_holder.css('display','none');
		me.status='hidden';
		Object.keys(me.forms).forEach(function(k){
			me.forms[k].css('display','none');
		});
	}
	$('.modal > form > header > span').on('click',function(e){
		e.preventDefault();
		me.hide();
	});
  $(document).keyup(function(e){
    if(e.keyCode===27){
      if($('.confirm-holder').css('display')==='flex'){
      	$('.confirm-holder').css('display','none');
      }else{
      	window.modals.forEach(function(el){
	      el.hide();
	    });
      }
    }
  });
	window.modals.push(me);
}