$.fn.PayrollPlugin=function(obj){
  var link=obj.getLink,
  tableColumns=obj.tableColumns,
  ajaxProperties=obj.ajaxDataProperties,
  payrollData=[],
  payrollPeriod='',
  payrollStart='',
  payrollEnd='',
  totalSalaries=0,
  tableWrapper=$(this);
  tableWrapper.html('');
  
  function createTable(){
    tableWrapper.html('');
    var table=$(ce('table'));
    var thead=$(ce('thead'));
    var tablelabel_tr=$(ce('tr'));
    var tablelabel_th=$(ce('th'));
    var tr=$(ce('tr'));
    var tbody=$(ce('tbody'));
    tbody.attr('id','jqueryPayrollTableTbody');
    var colspan=0;
    tableColumns.forEach(function(el){
      var th=$(ce('th'));
      th.addClass('print-cb');
      th.html(el);
      th.appendTo(tr);
      colspan++;
    });
    tablelabel_th.attr('id','jqueryPayrollHeading');
    tablelabel_th.attr('colspan',String(colspan));
    tablelabel_th.addClass('table_label');
    tablelabel_th.appendTo(tablelabel_tr);
    tablelabel_tr.appendTo(thead);
    tr.appendTo(thead);
    thead.appendTo(table);
    tbody.appendTo(table);
    table.appendTo(tableWrapper);
  }
  function ce(a){return document.createElement(a);}
  function showData(){
    var tbody=$('#jqueryPayrollTableTbody');
    tbody.html('');
    var total=0;
    payrollData.forEach(function(el){
      var tr=$(ce('tr'));
      ajaxProperties.forEach(function(k){
        var td=$(ce('td'));
        if(k==='image'){
          var img=$(ce('img'));
          img.attr('src',imgSrc+el[k]);
          img.appendTo(td);
          td.addClass('img');
        }else if(k==='hourly_rate' || k==='gross_salary' || k==='deductions' || k==='net_salary' || k==='hours_worked'){
          if(k==='net_salary'){total+=parseFloat(el[k]);}
          if(k==='hours_worked'){
            td.html($.formatNumber(el[k]));
          }else{
            td.html('&#8369;'+$.formatNumber(el[k])); 
          }
        }else{td.html(el[k]);}
        td.appendTo(tr);
      });
      tr.css('cursor','default');
      tr.appendTo(tbody); 
    });
    var parentDiv=$(ce('div'));
    var childDiv1=$(ce('div'));
    var childDiv2=$(ce('div'));
    var childDiv3=$(ce('div'));
    childDiv1.html('Employee Payroll');
    childDiv2.html('Payroll Period: '+payrollStart+' to '+payrollEnd);
    childDiv3.html('Total Salaries: &#8369;'+$.formatNumber(total));
    childDiv1.css('margin-bottom','10px');
    childDiv2.css('margin-bottom','10px');
    childDiv3.css('margin-bottom','10px');
    parentDiv.append(childDiv1);
    parentDiv.append(childDiv2);
    parentDiv.append(childDiv3);
    $('#jqueryPayrollHeading').append(parentDiv);
  }

  function getData(){
    $.ajax(link).then(function(r){
      payrollData=$.convert(r.data);
      payrollStart=r.startDate;
      payrollEnd=r.endDate;
      totalSalaries=r.totalSalaries;
      showData();
    }); 
  }
  getData();
  createTable();
}