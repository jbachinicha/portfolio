function alerts(message,type){
	var a = document.getElementById('alerts');
	//x = document.getElementById('cheer'),
	//y = document.getElementById('raven');
	//x.pause();x.currentTime=0;y.pause();y.currentTime=0;
	a.insertAdjacentHTML('afterbegin',`
		<div class="alert `+type+`"><div class="msg">`+message+`</div>
		<div title='Close' class="closebtn" onclick="x=this.parentNode;x.style.opacity='0';
		setTimeout(function(){ x.parentNode.removeChild(x);}, 600);">
			&#10006;</div></div>`);
	//if(type==='success') document.getElementById('cheer').play();
	//else if(type==='warning') document.getElementById('raven').play();
	//else if(type==='info') document.getElementById('fart').play();
	setTimeout(function(){
			a.lastElementChild.style.opacity='0';
			setTimeout(function(){
			try{a.removeChild(a.lastElementChild)}catch(e){}},600);
	},10000);
}

function confirms(message,callback){
	$('#confirms').css('display','flex');
	$('#confirm-msg').html(message);
	$('#confirm-yes-btn').off();
	$('#confirm-yes-btn').on('click',function(){callback();$('#confirms').css('display','none');});
	$('#confirm-no-btn').on('click',function(){$('#confirms').css('display','none');});
	$('#confirm-yes-btn').focus();
}

function loc(add){
	window.location.assign(add);
}