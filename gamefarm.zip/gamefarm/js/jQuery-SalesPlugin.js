$.fn.salesPlugin=function(options){
	'use strict';
	this.append(`
		<div class="container">
		<div id='salesPluginProductList'>
		  <div id='salesPluginCategoriesWrapper'></div>
          <div id='salesPluginProductListWrapper'></div>
		</div>
		</div>
		<div id="salesPluginSalesListButtonToggle">
			<div class="salesToggleCart" id="icon"></div>
			<div id="salesButtonToggle">Show List</div>
		</div>
        <div id='salesPluginSaleList'>
          <div id='salesPluginTransactionNumberLabels'>
            <div id='salesPluginTransactionNumberLabel'>Transaction No:</div>
            <div id='salesPluginTransactionNumber'></div>
		  </div>
          <div id='salesPluginSaleListTableWrapper'>
            <table>
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th style='width: 1.464vw;white-space:nowrap;text-align:center;'>Price</th>
                  <th style='width: 1.464vw;white-space:nowrap;text-align:center;'>Qty</th>
                  <th style='width: 1.464vw;white-space:nowrap;text-align:center;'>Subtotal</th>
                  <th style='width: 7vw;'>Actions</th>
                </tr>
              </thead>
              <tbody id='salesPluginSaleListSaleItemsList'></tbody>
            </table>
          </div>
          <div id='salesPluginGrandTotalLabels'>
            <div id='salesPluginGrandTotalLabel'>Grand Total: &#8369;</div>
            <div id='salesPluginGrandTotalNumber'>0.00</div>
          </div>
          <div id='salesPluginSalesListButtons'>
            <button id='salesPluginSalesListButtonsCancel' title='Not allowed' disabled='true'>Cancel</button>
            <div></div>
            <button id='salesPluginSalesListButtonsPayment' title='Not allowed' disabled='true'>Payment</button>
          </div>
        </div>
	`);
	
	$('body').append(`
		<div id='salesPluginModal' style='display:none'>
		    <div class='salesPluginModalForm'>
		      <header>Payment Information</header>
		      <div class='salesPluginModalLabelWrapper'>
		        <button id='salesPluginModalGrandTotalLabel' title='Click to generate payment equal to the grand total'>Grand Total</button>
		        <div><span>&#8369; </span><span id='salesPluginModalGrandTotal'>999.00</span></div>
		      </div>
		      <div class='salesPluginModalLabelWrapper'>
		        <div id='salesPluginModalPaymentLabel'>Payment</div>
		        <div><span>&#8369; </span><input type='number' step='0.01' required autocomplete autofocus id='salesPluginModalPayment'></div>
		      </div>
		      <div class='salesPluginModalLabelWrapper'>
		        <div id='salesPluginModalChangeLabel'>Change</div>
		        <div><span>&#8369; </span><span id='salesPluginModalChange'>999.00</span></div>
		      </div>
		      <div class='salesPluginModalButtonWrapper'>
		        <button id='salesPluginModalSaveButton'>Save</button>
		      </div>
		    </div>
		  </div>
	`);

	$(window).keyup(function(e){
		if(e.keyCode===27 || e.key==='27'){
			$('#salesPluginModal').css('display','none');
		}
	});

	var salesButtonIsClicked = true;
	document.getElementById('icon').addEventListener('click', function() {
		if(salesButtonIsClicked) {
			salesButtonIsClicked = false;
			document.getElementById('icon').style.backgroundImage = "url(close.png)";
			document.getElementById('salesButtonToggle').innerHTML = "Hide List";
			document.getElementById('salesPluginSaleList').style.display = "flex";
		} else {
			salesButtonIsClicked = true;
			document.getElementById('icon').style.backgroundImage = "url(cartIcon.png)";
			document.getElementById('salesButtonToggle').innerHTML = "Show List";
			document.getElementById('salesPluginSaleList').style.display = "none";
		}
	});

	function calculateChange(payment){
		let a = $.salesPluginData.salesInfo;
		a.payment=payment;
		a.change=payment-a.grandTotal;
		a.change=a.change<0?0:a.change;
		$('#salesPluginModalChange').html($.formatNumber(a.change));
	}

	$('#salesPluginModalGrandTotalLabel').on('click',function(){
		let a = $.salesPluginData.salesInfo;
		let payment=parseFloat(a.grandTotal);
		$('#salesPluginModalPayment').val(payment).focus();
		calculateChange(payment);
	});

	$('#salesPluginModalPayment').keyup(function(e){
		let payment=e.target.value===''?0:parseFloat(e.target.value);
		let a = $.salesPluginData.salesInfo;
		if(e.keyCode===13 || e.key==='13'){
			a.items.forEach(function(el){
				el.code=parseInt(el.code);
			});
			$('#salesPluginModalSaveButton').trigger('click');
		}else{
			calculateChange(payment);
		}
	});

	$('#salesPluginSalesListButtonsPayment').on('click',function(){
		$.salesPluginData.salesInfoOpenPaymentWindow();
	});

	$('#salesPluginSalesListButtonsCancel').on('click',function(){
		if(confirm('Are you sure you want to cancel the current transaction?')){
			var a=$.salesPluginData;
			a.salesInfo.items.forEach(function(el){
				el.quantity+=el.qty;
			});
			a.salesInfo.items=[];
			a.salesInfoRefreshTable();
			a.productListFilter('All');
		}
	});

	$('#salesPluginModalSaveButton').on('click',function(){
		var a=$.salesPluginData.salesInfo;
		var btnTxt=$('#salesPluginModalSaveButton').html();
		if(btnTxt==='Save'){
			if(a.payment<a.grandTotal){
			alert("Payment canno't be less than the Grand Total");
			}else{
				$('#salesPluginModalSaveButton').html('Saving... Please Wait');
				$('#salesPluginModal').addClass('wait');
				$('#salesPluginModalGrandTotalLabel').attr('disabled',true);
				$('#salesPluginModalSaveButton').attr('disabled',true);
				$('#salesPluginModal input').attr('readonly',true);
				var count=0;
				var loading=setInterval(function(){
					if(count===6){count=0};
					switch(count){
						case 0:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait');
							break;
						case 1:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait.');
							break;
						case 2:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait..');
							break;
						case 3:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait...');
							break;
						case 4:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait....');
							break;
						case 5:
							$('#salesPluginModalSaveButton').html('Saving... Please Wait.....');
							break;
					}
					count++;
				},500);
				
				a.items.forEach(function(el){
					el.code=parseInt(el.code);
				});
				$.ajax(options.saveSalesUrl,a).then(function(r){console.log(r);
					if(r.status==='error'){
						alert(r.message);
					}else{
						clearInterval(loading);
						$('#salesPluginModal').removeClass('wait');
						$('#salesPluginModalGrandTotalLabel').removeAttr('disabled');
						$('#salesPluginModalSaveButton').removeAttr('disabled');
						$('#salesPluginModal input').removeAttr('readonly');
						$('#salesPluginModalSaveButton').html('Next Transaction');
						document.getElementById('salesPluginReceipt').click();
						//$('#salesPluginReceipt').trigger('click');

					}
				});
			}
		}else if(btnTxt==='Next Transaction'){
			$.salesPluginData.refreshAll();
			$('#salesPluginModal').css('display','none');
			$('#salesPluginModalSaveButton').html('Save');
		}
		
	});

	let categoriesWrapper=$(this).find('#salesPluginCategoriesWrapper');
	let productListWrapper=$('#salesPluginProductListWrapper');
	$.salesPluginData={
		productListData:[],
		productList:[],
		productListLastFilter:'',
		productListFilter:function(cat){
			let a = this;
			a.productListLastFilter=cat;
			productListWrapper.html('');
			a.productListData.forEach(function(el){
				let product=$(document.createElement('div'));
				let imagewrapper=$(document.createElement('div'));
				let image=$(document.createElement('img'));
				let name=$(document.createElement('div'));
				let descriptionTag=$(document.createElement('div'));
				let quantity=$(document.createElement('div'));
				let price=$(document.createElement('div'));
				var description='';
				product.addClass('salesPluginProducts');
				name.addClass('salesPluginProductName');
				quantity.addClass('salesPluginProductQuantity');
				price.addClass('salesPluginProductPrice');

				function addElements(){
					if(el.quantity!==0){
						name.html(el.name);
						descriptionTag.addClass('salesPluginProductDescription');
						if(el.size!=='' && (typeof el.size !== 'undefined')){
							description+='('+el.size+')';
						}
						if(el.description!==''){
							description+='('+el.description+')';
						}
						quantity.html('Q'+el.quantity);
						price.html('&#8369; '+$.formatNumber(el.price));
						descriptionTag.html(description);
						imagewrapper.addClass('salesPluginProductImageWrapper');
						image.attr('src','products/'+el.image);
						imagewrapper.append(image).append(quantity).append(price);
						product.append(name).append(imagewrapper).append(descriptionTag);
						product.attr('data-id',el.code);
						product.on('click',function(e){
							let productContainerHeight = document.getElementById('salesPluginProductListWrapper').clientHeight;
							if(productContainerHeight > 350){
								document.getElementById('salesPluginSalesListButtonToggle').style.display = "grid";
							} else {
								document.getElementById('salesPluginSaleList').style.display = "flex";
							}
							let code = $(this).attr('data-id');
							$.salesPluginData.productListAdd(code);
						});
						product.appendTo(productListWrapper);
					}
				}
				if(cat==='All'){
					addElements();
				}else{
					if(el.category===cat){
						addElements();
					}
				}
			});
			let receipt=$(document.createElement('a'));
			receipt.attr('id','salesPluginReceipt');
			receipt.attr('href',options.receiptUrl);
			receipt.attr('target','_blank');
			receipt.css('display','none');
			productListWrapper.append(receipt);
		},
		productListAdd:function(code){
			let a=this;code=parseInt(code);
			if(a.salesInfoIsDup(code)){
				a.salesInfoProductList(code,'add');
			}else{
				let product=a.find('productList',code),salesInfoItems={};
				product.salesName=product.name;
				if(typeof product.size !== 'undefined'){
					product.salesName+=product.size!==''?' ('+product.size+')':'';	
				}
				product.salesName+=product.description!==''?' ('+product.description+')':'';
				product.qty=0;
				product.subtotal=product.price;
				a.salesInfo.items.push(product);
				a.salesInfoProductList(code,'add');
			}
		},
		find:function(what,code){
			let temp={},a=this,flag=false;
			if(what==='productList'){
				a.productListData.forEach(function(el){
					if(el.code===code){
						//temp=$.convert(el);
						temp=el;
					}
				});
			}else{
				a.salesInfo.items.forEach(function(el){
					if(el.code===code){
						temp=el;
					}
				});
			}
			return temp;
			//return $.convert(this.productListData.find(function(el){return el.code===code;}));
		},
		salesInfo:{
			items:[],
			transaction_no:'',
			grandTotal:'',
			payment:'',
			change:''
		},
		salesInfoProductList:function(code,what){
			let a=this;code=parseInt(code);
			let product=a.find('salesList',code);

			function removeItem(){
				let temp=[]
				a.salesInfo.items.forEach(function(el){
					if(el.code!==product.code){
						temp.push(el);
					}else{
						el.quantity+=el.qty;
					}
				});
				a.salesInfo.items=temp;
				a.salesInfoRefreshTable();
			}
			switch(what){
				case 'add':
					let quantity=product.quantity;
					if(quantity===0){
						alert('Insufficient stocks!');
					}else{
						product.quantity--;
						product.qty++;
						product.subtotal=product.price*product.qty;	
					}
					break;
				case 'minus':
					if(product.qty===1){
						if(confirm(product.salesName+' only contains 1 quantity. Proceeding will remove the product from the sales list do you want to proceed?')){
							removeItem();
						}
					}else{
						product.quantity++;
						product.qty--;
						product.subtotal=product.price*product.qty;
					}
					break;
				case 'remove':
					if(confirm('Are you sure you want to remove '+product.salesName+' from the sales list?')){
						removeItem();
					}
					break;
			}
			a.productListFilter(a.productListLastFilter);
			a.salesInfoRefreshTable();
		},
		salesInfoRefreshTable:function(){
			let a=this,grandTotal=0;
			let table=$('#salesPluginSaleListSaleItemsList');
			table.html('');
			a.salesInfo.items.forEach(function(el){
				let row=$(document.createElement('tr'));

				let name=$(document.createElement('td'));
				name.html(el.salesName);

				let price=$(document.createElement('td'));
				price.css({'width':'1.464vw','white-space':'nowrap','text-align':'center'});
				price.html('&#8369; '+($.formatNumber(el.price)));

				let qty=$(document.createElement('td'));
				qty.css({'width':'1.464vw','white-space':'nowrap','text-align':'center'});
				qty.html($.formatNumber(el.qty,'whole'));

				let subtotal=$(document.createElement('td'));
				subtotal.css({'width':'1.464vw','white-space':'nowrap','text-align':'center'});
				subtotal.html('&#8369; '+($.formatNumber(el.subtotal)));

				grandTotal+=el.subtotal;

				let actions=$(document.createElement('td'));

				let addButton=$(document.createElement('button'));
				addButton.html('&plus;');
				addButton.attr('data-id',el.code);
				addButton.attr('title','Add Product Quantity');
				addButton.on('click',function(e){
					let code=e.target.getAttribute('data-id');
					a.salesInfoProductList(code,'add');
				});

				let deductButton=$(document.createElement('button'));
				deductButton.html('&minus;');
				deductButton.attr('data-id',el.code);
				deductButton.attr('title','Deduct Product Quantity');
				deductButton.on('click',function(e){
					let code=e.target.getAttribute('data-id');
					a.salesInfoProductList(code,'minus');
				});

				let removeButton=$(document.createElement('button'));
				removeButton.html('&times;');
				removeButton.attr('data-id',el.code);
				removeButton.attr('title','Remove Product');
				removeButton.on('click',function(e){
					let code=e.target.getAttribute('data-id');
					a.salesInfoProductList(code,'remove');
				});

				actions.append(addButton).append(deductButton).append(removeButton);
				row.append(name).append(price).append(qty).append(subtotal).append(actions);
				table.append(row);
			});
			a.salesInfo.grandTotal=grandTotal;
			//a.salesInfo.change=0-grandTotal;
			a.salesInfo.change=0;
			$('#salesPluginGrandTotalNumber').html($.formatNumber(grandTotal));
			if(a.salesInfo.items.length===0){
				$('#salesPluginSalesListButtonsCancel').attr('disabled','disabled');
				$('#salesPluginSalesListButtonsCancel').attr('title','Not allowed');
				$('#salesPluginSalesListButtonsPayment').attr('disabled','disabled');
				$('#salesPluginSalesListButtonsPayment').attr('title','Not allowed');
			}else{
				$('#salesPluginSalesListButtonsCancel').removeAttr('disabled');
				$('#salesPluginSalesListButtonsCancel').attr('title','Cancel transaction');
				$('#salesPluginSalesListButtonsPayment').removeAttr('disabled');
				$('#salesPluginSalesListButtonsPayment').attr('title','Opens payment dialog');
			}
		},
		salesInfoIsDup:function(code){
			let a=this,flag=false;
			a.salesInfo.items.forEach(function(el){
				if(el.code===code)flag=true;
			});
			return flag;
			//let flag=this.salesInfo.items.find(function(el){return el.code===code;});
			//return typeof flag==='undefined'?false:true;
		},
		salesInfoOpenPaymentWindow:function(){
			$('#salesPluginModal').css('display','flex');
			$('#salesPluginModalGrandTotal').html($.formatNumber($.salesPluginData.salesInfo.grandTotal));
			$('#salesPluginModalChange').html($.formatNumber($.salesPluginData.salesInfo.change));
			$('#salesPluginModalPayment').val('');
			$('[autofocus]').focus();
		},
		refreshAll:function(){
			let a=this;
			$.ajax(options.getProductsUrl).then(function(r){
				if(r.status==='error'){
					alert('Error getting products information');
				}else{
					let sorted=r.data.sort((aa,bb)=>{
						let na = aa.name.toUpperCase();
						let nb = bb.name.toUpperCase();
						if(na<nb) return -1;
						if(na>nb) return 1;
						return 0;
					});
					let categories=['All'];
					$('#salesPluginTransactionNumber').html(r.transactionNumber);
					$('#salesPluginCategoriesWrapper').html('');
					r.data.forEach(function(el){
						let flag=true;
						categories.forEach(function(el1){
							if(el.category===el1){flag=false;}
						});
						if(flag){
							categories.push(el.category);
						}
					});
					
					categories.forEach(function(el){
						let category=$(document.createElement('button'));
						category.html(el);
						category.on('click',function(e){
							let filter=e.target.innerHTML;
							$('#salesPluginCategoriesWrapper > button').removeClass('active');
							$(this).addClass('active');
							$.salesPluginData.productListFilter(filter);
						});
						category.appendTo(categoriesWrapper);
						if(category.html()==='All'){category.addClass('active');}
					});
					a.productListData=$.convert(sorted);
					a.productListFilter('All');
					a.salesInfo.items=[];
					a.salesInfo.payment='';
					a.salesInfo.transaction_no=r.transactionNumber;
					a.salesInfoRefreshTable();
				}
			});
		}
	};

	$.salesPluginData.refreshAll();
}