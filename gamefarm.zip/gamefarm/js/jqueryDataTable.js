$.fn.DataTable=function(obj){
	var link=obj.getLink,
	imgSrc=obj.imgSrc,
	onHoverTitle=obj.onHoverTitle,
	tableLimit=(typeof obj.tableLimit==='undefined')?100:obj.tableLimit,
	msgOnEmptyTable=obj.msgOnEmptyTable,
	filterElement=$(obj.filterSelector),
	requestData=obj.requestData,
	dataProperties=obj.dataProperties,
	sumColumns=obj.sumColumns,
	tableWrapper=$(this),
	tableCount=($(this).attr('id')).replace(/[^0-9]/g,'');

	function check(a){return typeof a!=='undefined';}
	function ce(a){return document.createElement(a);}
	var dt={
		ajaxData:[],
		filteredAjaxData:[],
		find:function(code,key,type){
			if(type==='int'){code=parseInt(code);}
			var a;this.ajaxData.forEach(function(el){
				if(el[key]===code){a=$.convert(el);}
			});return a;
		},
		refresh:function(){
			getData();
		}
	};

	function createTable(){
		tableWrapper.html('');
		var table=$(ce('table'));
		var thead=$(ce('thead'));
		var tablelabel_tr=$(ce('tr'));
		var tablelabel_th=$(ce('th'));
		var tr=$(ce('tr'));
		var tbody=$(ce('tbody'));
		var div=$(ce('div'));
		var span=$(ce('span'));
		tbody.attr('id','jqueryDataTableTbody'+tableCount);
		var colspan=0;
		dataProperties.forEach(function(el){
			var th=$(ce('th'));
			th.addClass('print-cb');
			th.html(el.label);
			if(check(el.nowrap) || check(el.nowrapLabel)){th.css('white-space','nowrap');}
			if(check(el.fit)){th.css('width','10px').css('white-space','nowrap');}
			if(check(el.hide)){th.css('display','none');}
			if(check(el.hideOnPrint)){th.addClass('no-print');}
			th.appendTo(tr);
			colspan++;
		});
		tablelabel_th.html(obj.tableLabel);
		tablelabel_th.attr('colspan',String(colspan));
		tablelabel_th.addClass('table_label');
		tablelabel_th.appendTo(tablelabel_tr);
		tablelabel_tr.appendTo(thead);
		tr.appendTo(thead);
		thead.appendTo(table);
		tbody.appendTo(table);
		table.appendTo(tableWrapper);
		//div.css({'display':'flex','flex-grow':'1','height':'100%'});
		//span.css({'margin':'0px auto','font-size':'20px','font-weight':'bold','margin-top':'40px'});
		//span.html(msgOnEmptyTable);
		//span.appendTo(div);
		//div.appendTo(tableWrapper);
		//div.hide();
	}

	function showFilteredData(){
		var tbody=$('#jqueryDataTableTbody'+tableCount);
		var tr_count=0;
		tbody.html('');
		if(check(sumColumns)){sumColumns.forEach(function(el){el['total']=0;el['txt']='';})}
		if(dt.filteredAjaxData.length===0){
			//$(tableWrapper.children()[0]).hide();
			//$(tableWrapper.children()[1]).show();
		}else{
			//$(tableWrapper.children()[1]).hide();
			//$(tableWrapper.children()[0]).show();
			dt.filteredAjaxData.forEach(function(el){
				if(tr_count<tableLimit){
					var tr=$(ce('tr'));
					tr.attr('title',onHoverTitle);
					dataProperties.forEach(function(o){
						var td=$(ce('td'));
						if(check(o.format)){
							switch(o.format){
								case 'img':
									var img=$(ce('img'));
									img.attr('src',imgSrc+el[o.name]).appendTo(td);
									td.addClass('img');break;
								case 'cur': td.html('&#8369;'+$.formatNumber(el[o.name]));break;
								case 'num': td.html($.formatNumber(el[o.name]));break;
								case 'wnum': td.html($.formatNumber(el[o.name],'whole'));break;
								case 'fn4': td.html('&#8369;'+$.fn4(el[o.name]));break;
								case 'sq.m': td.html($.formatNumber(el[o.name])+' (m<sup>2</sup>)');break;
								case '%': td.html($.formatNumber(el[o.name])+'%');break;
								case 'cube.m': td.html($.formatNumber(el[o.name],'whole')+' (m<sup>3</sup>)');break;
								default: td.html(el[o.name]);break;
							}
						}else{td.html(el[o.name]);}
						if(check(o.nowrap)){td.css('white-space','nowrap');}
						if(check(o.fit)){td.css('width','10px').css('white-space','nowrap');}
						if(check(o.hide)){td.css('display','none');}
						if(check(o.hideOnPrint)){td.addClass('no-print');}
						if(check(o.dataTextCentered)){td.css('text-align','center');}
						if(check(o.sumID)){
							if(check(o.total)){o['total']=0;}
						}
						if(check(sumColumns)){
							sumColumns.forEach(function(p){
								if(p.name===o.name){
									p.total+=parseFloat(el[o.name]);
									switch(o.format){
										case 'cur': p.txt='&#8369;'+$.formatNumber(p.total);break;
										case 'num': p.txt=$.formatNumber(p.total);break;
										case 'wnum': p.txt=$.formatNumber(p.total,'whole');break;
										case 'fn4': p.txt='&#8369;'+$.fn4(p.total);break;
										case 'sq.m': p.txt=$.formatNumber(p.total)+' (m<sup>2</sup>)';break;
										case '%': p.txt=$.formatNumber(p.total)+'%';break;
										case 'cube.m': p.txt=$.formatNumber(p.total,'whole')+' (m<sup>3</sup>)';break;
										default: break;
									}
								}
							});
						}
						td.appendTo(tr);
					});
					if(check(obj.onClick)){
						tr.on('click',obj.onClick);	
					}else{
						tr.css('cursor','default');
					}
					tr_count++;
					tr.appendTo(tbody);
				}
			});
			if(check(sumColumns)){
				sumColumns.forEach(function(el){
					$('#'+el.id).html(el.txt);
				});
			}
		}
	}

	function filterData(f){
		function sort(a){
			var b=a.sort((aa,bb)=>{
				var na = aa.name.toUpperCase();
				var nb = bb.name.toUpperCase();
				if(na<nb) return -1;
				if(na>nb) return 1;
				return 0;
			});
			return b;
		}
		var pat = new RegExp(f,'i'),b=[];
		if(f===''){dt.filteredAjaxData=$.convert(dt.ajaxData);}
		else{
			dt.ajaxData.forEach(function(el){
				var c={},flag=false;
				dataProperties.forEach(function(o){
					if(o.name!=='img' && !check(o.hide)){
						let d = (String(el[o.name]).search(pat));
						if(d>=0) flag=true;	
					}
				});
				if(flag){c=$.convert(el);b.push(c);}
			});
			dt.filteredAjaxData=b;
		}
		showFilteredData();
	}

	function getData(request_data){
		if(typeof request_data==='undefined'){
			$.ajax(link).then(function(r){
				dt.ajaxData=$.convert(r.data);console.log(dt.ajaxData);
				filterData('');
			});	
		}else{
			$.ajax(link,request_data).then(function(r){
				dt.ajaxData=$.convert(r.data);console.log(dt.ajaxData);
				filterData('');
			});
		}
		
	}

	filterElement.keyup(function(e){
		filterData(e.target.value);
	});
	getData(requestData);
	createTable();
	return dt;
};