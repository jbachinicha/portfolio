<?php
	include 'session.php';
	include 'getDate.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());

	$r=mysqli_query($con,"SELECT * FROM products ORDER BY code DESC");
	while($rw=mysqli_fetch_assoc($r)){
		$code=intval($rw['code']);
		$arr['code']=intval($rw['code']);
		$arr['name']=$rw['name'];
		$arr['cat']=$rw['category'];
		$arr['des']=$rw['description'];
		$arr['bp']=floatval($rw['buyingprice']);
		$bp=floatval($rw['buyingprice']);
		$arr['markup']=floatval($rw['markup']);
		$markup=(floatval($rw['markup'])/100)+1;
		$arr['hasingredients']=intval($rw['hasingredients']);
		$arr['stockinable']=0;
		$arr['image']=$rw['image'];
		$arr['qty']=intval($rw['qty']);
		$arr['quantity']=intval($rw['qty']);
		$arr['category']=$rw['category'];
		$arr['description']=$rw['description'];
		$arr['sqty']=0;
		$arr['sub']=0;
		$price;
		if($arr['hasingredients']===1){
			$arr['ingredients']=array();
			$cost=0;
			$rr=mysqli_query($con,"SELECT pi.*,i.name,i.unitprice,i.totalunits,i.unitlabel FROM productingredients pi INNER JOIN ingredients i ON pi.icode=i.code WHERE pi.pcode='$code'");
			while($rrw=mysqli_fetch_assoc($rr)){
				$arr1['code']=intval($rrw['icode']);
				$arr1['name']=$rrw['name'];
				$arr1['totalunits']=intval($rrw['totalunits']);
				$totalunits=$arr1['totalunits'];
				$arr1['unitprice']=floatval($rrw['unitprice']);
				$arr1['unitlabel']=$rrw['unitlabel'];
				$arr1['myUnits']=intval($rrw['qty']);
				$req_units=$arr1['myUnits'];
				$arr1['myCost']=floatval($rrw['unitprice'])*intval($rrw['qty']);
				$arr1['myCost']=round($arr1['myCost'],2);
				$cost+=$arr1['myCost'];
				$arr1['makables']=$totalunits/$req_units;
				array_push($arr['ingredients'],$arr1);
			}
			$qty=1000000;
			for($x=0;$x<count($arr['ingredients']);$x++){
				$qty=$arr['ingredients'][$x]['makables']<$qty?$arr['ingredients'][$x]['makables']:$qty;
			}
			$arr['stockinable']=floor($qty);
			$arr['cost']=round($cost,2);
			$price=round($cost*$markup,2);
		}else{
			$price=(($bp*$markup)*100)/100;
			$arr['cost']=round($bp,2);
		}
		$arr['price']=$price;
		$arr['markup_price']=round(($arr['cost']*($markup-1)),2);
		$arr['value']=$arr['qty']*$arr['cost'];
		array_push($myArr['data'], $arr);
	}

	$r=mysqli_query($con,"SELECT max(transaction_no) AS tno FROM sales;");
	$rw=mysqli_fetch_assoc($r);
	$myArr['transactionNumber']=$rw['tno']===NULL?1:intval($rw['tno'])+1;

	exit(json_encode($myArr));
?>