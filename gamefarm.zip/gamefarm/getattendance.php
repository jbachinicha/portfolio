<?php
include 'connection.php';
if (isset($_POST['signin'])) {
    date_default_timezone_set('Asia/Manila');
    $today = date("Y-m-d");
    $id = $_POST['id'];
    $time = date("H:i:s");
    $status = $_POST['status'];
    $todayString = strval($today);
    $sqlverify = "SELECT * FROM `employeeattendance` WHERE `date` = '".$todayString."' AND empId = '".$id."'";
    $sqlverifyresult = $con->query($sqlverify);
    if($_POST['status'] == "in") {
        if($sqlverifyresult->num_rows == 0) {
            $sql1 = "INSERT INTO `employeeattendance` (`empId`, `date`, `time_in`) VALUES (?, ?, ?)";
            $stmt = $con->prepare($sql1);
            $stmt->bind_param("sss", $id, $today, $time);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "<script type='text/javascript'>alert('You have already logged in');</script>";
        }
        
        
        
    }
    if($_POST['status'] == 'out') {
        $sqlOut = "UPDATE employeeattendance SET time_out = ? WHERE `date` = ? AND `empId` = ?";
        $stmt1 = $con->prepare($sqlOut);
        $stmt1->bind_param("sss", $time, $today, $id);
        $stmt1->execute();
        $stmt1->close();
    }
    header("Location: attendance.php");
    die();
};
?>