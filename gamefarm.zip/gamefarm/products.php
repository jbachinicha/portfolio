<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
  	if(isset($_POST['stockin']) || isset($_POST['expired']) || isset($_POST['damaged'])){
  		include 'connection.php';
  		$data=json_decode($_POST['data'],true);
  		//var_dump($data);
  		$code=intval($data['code']);
  		$name=$data['name'];
  		$radio=intval($data['hasingredients']);
  		$qty=intval($_POST['qty']);
  		$instockqty=intval($data['qty']);
  		$ingredients;
  		$price=floatval($data['price']);
  		$date=gd();
  		$date=fd($date,'Y-m-d');
  		$time=gd();
  		$time=fd($time,'H:i:s');
  		$sql;
  		$action;
  		$value;
  		$shval;
  		if($radio===1){
  			$action=(isset($_POST['stockin']))?'Produced':(((isset($_POST['damaged'])))?'Damaged':'Expired');
  		}else{
  			$action=(isset($_POST['stockin']))?'Purchased':(((isset($_POST['damaged'])))?'Damaged':'Expired');
  		}

  		mysqli_query($con,"BEGIN");
  		if(isset($_POST['stockin'])){
  			if($radio===1){
  				$value=floatval($data['cost'])*$qty;
  				$shval=floatval($data['cost']);
  			}else{
  				$value=floatval($data['bp'])*$qty;
  				$shval=floatval($data['bp']);
  			}
  			$sql="UPDATE products SET qty=qty+'$qty' WHERE code='$code'";
  		}else{
  			if($radio===1){
  				$value=floatval($data['cost'])*$qty;
  				$shval=floatval($data['cost']);
  			}else{
  				$value=floatval($data['bp'])*$qty;
  				$shval=floatval($data['bp']);
  			}
  			$sql="UPDATE products SET qty=qty-'$qty' WHERE code='$code'";
  		}
  		$value=round($value,2);
  		$sql1="INSERT INTO productstockhistory VALUES('','$code','$name','$shval','$action','$qty','$value','$date','$time')";
  		$act;
  		switch ($action) {
  			case 'Produced': $act='Production';break;
  			case 'Purchased': $act='Purchases';break;
  			case 'Damaged': $act='Damages';break;
  			case 'Expired': $act='Expiries';break;
  			default: break;
  		}
  		if($action!=='Produced'){
  			ae($name,$act,$value);
  		}
  		$r=mysqli_query($con,$sql);
  		if($r===false){$err_msg=mysqli_error($con).' Line 45';$err=true;}
  		$r1=mysqli_query($con,$sql1);
  		if($r1===false){$err_msg=mysqli_error($con).' Line 47';$err=true;}
  		if($action==='Produced'){
  			$ingredients=$data['ingredients'];
  			for($x=0;$x<count($ingredients);$x++){
  				$icode=intval($ingredients[$x]['code']);
  				$unit=floatval($ingredients[$x]['myUnits']);
  				$unit=$unit*$qty;
  				$r=mysqli_query($con,"UPDATE ingredients SET totalunits=totalunits-'$unit' WHERE code='$icode'");
  				if($r===false){mysqli_query($con,"ROLLBACK");echo mysqli_error($con).' '.$x;exit();}
  			}
  		}
  		if($err){
  			mysqli_query($con,"ROLLBACK");
  		}else{
  			mysqli_query($con,"COMMIT");
  		}
  		mysqli_close($con);
  	}

  	if(isset($_POST['sub'])){
  		include 'connection.php';
  		$date=gd();
  		$today=fd($date,'YmdHis');
  		$code=$_POST['code'];
  		$name=$_POST['name'];
  		$cat=$_POST['cat'];
  		$des=$_POST['des'];
  		$bp=$_POST['bp'];
  		$bp=$bp===''?0:$bp;
  		$markup=$_POST['markup'];
  		$radio=$_POST['radyo'];
  		$radio=$radio==='Produced'?1:0;
  		$action=$_POST['action'];
  		$ing=json_decode($_POST['ing'],true);
  		$tempimage;
	    $imageext;
	    $imageDes="products/";
	    $imageName;
	    
	    if(empty($_FILES["image"]["name"])){
	      if($action==='add'){
	      	$imageName="nopreview.png";
	      }
	    }else{
	      $tempimage=$_FILES["image"]["tmp_name"];
	      $imageext=pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);  
	      $imageName=$name.$today.".".$imageext;
	    }

  		mysqli_query($con,"BEGIN");
  		if($action==='add'){
  			$r=mysqli_query($con,"INSERT INTO products VALUES('','$name','$cat','$des','$bp','$markup','$radio','0','$imageName')");
	  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
	  		$r=mysqli_query($con,'SELECT code FROM products ORDER BY code DESC LIMIT 1');
	  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
	  		$rw=mysqli_fetch_assoc($r);
	  		$code=$rw['code'];
	  		if($radio===1){
	  			for($x=0;$x<count($ing);$x++){
	  				$icode=$ing[$x]['code'];
	  				$qty=$ing[$x]['myUnits'];
	  				$r=mysqli_query($con,"INSERT INTO productingredients VALUES('$code','$icode','$qty')");
	  				if($r===false){$err_msg=mysqli_error($con);$err=true;}
		  		}
	  		}
		  	if($err){mysqli_query($con,"ROLLBACK");}
		  	else{
		  		mysqli_query($con,"COMMIT");
			  		if(!empty($_FILES['image']['name'])) {
		        move_uploaded_file($tempimage, $imageDes.$imageName);
		      }
		  	}
		  }else{
		  	if(!empty($_FILES['image']['name'])) {
		  		$r=mysqli_query($con,"UPDATE products SET name='$name', description='$des', category='$cat', buyingprice='$bp', markup='$markup', hasingredients='$radio', image='$imageName' WHERE code='$code'");
		  	}else{
		  		$r=mysqli_query($con,"UPDATE products SET name='$name', description='$des', category='$cat', buyingprice='$bp', markup='$markup', hasingredients='$radio' WHERE code='$code'");
		  	}
	  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
	  		if($radio===1){
	  			$r=mysqli_query($con,"DELETE FROM productingredients WHERE pcode='$code'");
	  			if($r===false){$err_msg=mysqli_error($con);$err=true;}
	  			for($x=0;$x<count($ing);$x++){
	  				$icode=$ing[$x]['code'];
	  				$qty=$ing[$x]['myUnits'];
	  				$r=mysqli_query($con,"INSERT INTO productingredients VALUES('$code','$icode','$qty')");
	  				if($r===false){$err_msg=mysqli_error($con);$err=true;}
		  		}
	  		}
		  	if($err){mysqli_query($con,"ROLLBACK");}
		  	else{
		  		mysqli_query($con,"COMMIT");
			  	if(!empty($_FILES['image']['name'])) {
			        move_uploaded_file($tempimage, $imageDes.$imageName);
			    }
		  	}
		  }
  		mysqli_close($con);
  	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Products</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button id="openDialogNew" class="mr10">New Product</button>
					<button id="productlistbtn" class="mr10">Product List</button>
					<button id="stockhisotrybtn" class="mr10">Stock History</button>
					<button id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Products</label>
					<input type="text" id="searchTxt" style="width: 278px;">
				</div>
			</div>
			<div class="table-wrapper" id="myTable"></div>
		</div>
	</div>
	<?php include 'productsmodal.php'; ?>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Products';
		var ingredientList={
			data:[],
			find:function(code){
				code=parseInt(code);
				var temp;
				this.data.forEach(function(el){
					if(el.code===code){
						temp=el;
					}
				});
				return temp;
			}
		};
		var newProduct={
			ingredientList:[],
			calc:function(){
				var a=$("form[name=addForm] input[name=bns]:checked").val();
				var cost;
				if(a==='Produced'){
					cost=parseFloat($("form[name=addForm] input[name=icost]").val());
				}else{
					cost=parseFloat($("form[name=addForm] input[name=bp]").val());
				}
				cost=isNaN(cost)?0:cost;
				cost=cost<0?0:cost;
				var markup=(parseFloat($("form[name=addForm] input[name=markup]").val())/100)+1;
				markup=isNaN(markup)?1:markup;
				markup=markup<1?1:markup;
				var price=cost*markup;
				price=Math.round(price*100)/100;
				$("form[name=addForm] input[name=price]").val(price);
			},
			find:function(code){
				code=parseInt(code);
				var temp;
				this.ingredientList.forEach(function(el){
					if(el.code===code){
						temp=el;
					}
				});
				return temp;
			},
			add:function(code,qty){
				var dup=this.find(code);
				if(typeof dup==='undefined'){
					var i=ingredientList.find(code);
					i.myUnits+=parseInt(qty);
					i.myCost=i.myUnits*i.unitprice;
					this.ingredientList.push(i);
					this.refresh();
				}else{
					dup.myUnits+=parseInt(qty);
					dup.myCost=dup.myUnits*dup.unitprice;
					this.refresh();
				}
			},
			remove:function(code){
				var i=this.find(code);
				if(confirm('Are you sure you want to remove ingredient '+i.name+' from the list?')){
					var temp=[];
					this.ingredientList.forEach(function(el){
						if(el.code!==code){
							temp.push(el);
						}else{
							el.myUnits=0;
						}
					});
					this.ingredientList=temp;
					this.refresh();
				}
			},
			refresh:function(){
				var total=0;
				$('#productingredientsTable').html('');
				this.ingredientList.forEach(function(el){
					$('#productingredientsTable').append(`
						<tr>
							<td style='display:none'>`+el.code+`</td>
							<td>`+el.name+`</td>
							<td>`+el.myUnits+`(`+el.unitlabel+`)</td>
							<td>&#8369;`+$.formatNumber(el.unitprice)+`</td>
							<td>&#8369;`+$.formatNumber(el.myCost)+`</td>
							<td class='width:10px;'><button onclick='newProduct.remove(`+el.code+`)'>Remove</button></td>
						</tr>
					`);
					total+=el.myCost;
				});
				$("form[name=addForm] input[name=icost]").val(Math.round(total * 100)/100);
				this.calc();
			}
		}

		$('#printpage').on('click',function(){window.print();});
		$('#openDialogNew').on('click',function(){
			m.show('addForm');
			m.forms.addForm.find('input[name=action]').val('add');
			newProduct.ingredientList=[];
			newProduct.refresh();
			
			$('.bought').css('display','inherit');
				$('.production').css('display','none');
				$('#addIngredientsForm').css('display','none');
				$('#addFormContent').css('width','350px');
		});
		var m=new Modal(['addForm','choiceMenu','inventoryForm']);
		
		$('.nav-title p').html('Products');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});

		$.ajax('getIngredients.php').then(function(r){
			ingredientList.data=$.convert(r.data);
			$("form[name=addForm] select[name=ingredients]").html('');
			ingredientList.data.forEach(function(el){

				$("form[name=addForm] select[name=ingredients]").append(`
				<option value='`+el.code+`'>`+el.name+` (`+el.unitlabel+`)</option>
				`);
			});
		});

		
		$('#addnewproductingredient').on('click',function(){
			var val=parseInt($("form[name=addForm] select[name=ingredients]").val());
			var units=$("form[name=addForm] input[name=qty]").val();
			units=units===''?0:parseInt(units);
			if(units>0){
				newProduct.add(val,units);
			}
		});
		$("form[name=addForm] input:radio[name=bns]").change(function(){//console.log(this.value);
			if(this.value==='Produced'){
				$('.bought').css('display','none');
				$('.production').css('display','inherit');
				$('#addIngredientsForm').css('display','flex');
				$('#addFormContent').css('width','850px');
			}else{
				$('.bought').css('display','inherit');
				$('.production').css('display','none');
				$('#addIngredientsForm').css('display','none');
				$('#addFormContent').css('width','350px');
			}
			newProduct.calc();
		});
		var data;
		var stockhistory;
		$("#productlistbtn").on('click',function(){
			data=$('#myTable').DataTable({
				tableLabel:'Products Lists',
				filterSelector:'#searchTxt',
				getLink:'getProducts.php',
				imgSrc:'products/',
				dataProperties:[
					{label:'Image',name:'image',format:'img',hideOnPrint:''},
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Category',name:'cat'},
					{label:'Description',name:'des'},
					{label:'Production/Buying Cost',name:'cost',format:'cur'},
					{label:'Mark Up (%)',name:'markup',format:'%'},
					{label:'Mark Up (&#8369;)',name:'markup_price',format:'cur'},
					{label:'Price',name:'price',format:'cur'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Value',name:'value',format:'cur'},
				],
				onHoverTitle:'Click to update product',
				tableLimit:14,
				onClick:function(e){
					var target=e.currentTarget;
		  			var code=target.children[1].innerHTML;
		  			var product=data.find(code,'code','int');
		  			m.show('choiceMenu');
		  			m.forms.choiceMenu.find('button[name=choicemenu1]').on('click',function(e){
						
						$('.bought').css('display','inherit');
						$('.production').css('display','none');
						$('#addIngredientsForm').css('display','none');
						$('#addFormContent').css('width','350px');
		  				e.preventDefault();
		  				m.show('addForm');
		  				var hasingredients=product.hasingredients;
		  				if(hasingredients===1){
		  					newProduct.ingredientList=product.ingredients;
		  					newProduct.refresh();
		  				}
		  				hasingredients=hasingredients===1?'Produced':'Bought'
		  				m.forms.addForm.find('input[name=action]').val('update');
		  				m.forms.addForm.find("input[name='code']").val(product.code);
			  			m.forms.addForm.find("input[name='name']").val(product.name);
			  			m.forms.addForm.find("input[name='cat']").val(product.cat);
			  			m.forms.addForm.find("input[name='des']").val(product.des);
			  			m.forms.addForm.find("input[name='bp']").val(product.bp);
			  			m.forms.addForm.find("input[name='markup']").val(product.markup);
			  			m.forms.addForm.find("input[name='price']").val(product.price);
			  			m.forms.addForm.find("input[type='radio'][value='"+hasingredients+"']").trigger('click');
			  			$('#imagePreviewAdd').attr('src','products/'+product.image);
		  			});
		  			m.forms.choiceMenu.find('button[name=choicemenu2]').on('click',function(e){
		  				e.preventDefault();
		  				m.show('inventoryForm');
		  				m.forms.inventoryForm.find("input[name='code']").val(product.code);
			  			m.forms.inventoryForm.find("input[name='name']").val(product.name);
			  			m.forms.inventoryForm.find("input[name='price']").val(product.price);
			  			m.forms.inventoryForm.find("input[name='units']").val(product.units);
			  			m.forms.inventoryForm.find("input[name='instockqty']").val(product.qty);
			  			m.forms.inventoryForm.find("input[name='stockinableqty']").val(0);
			  			if(product.hasingredients===1){
			  				$('#stockinableqtyholder').css('display','flex');
			  				m.forms.inventoryForm.find("input[name='stockinableqty']").val(product.stockinable);
			  				m.forms.inventoryForm.find("button[name='stockin']").html('Produce');
			  				m.forms.inventoryForm.find("input[name='hasingredients']").val('1');
			  			}else{
			  				$('#stockinableqtyholder').css('display','none');
			  				m.forms.inventoryForm.find("button[name='stockin']").html('Produce');
			  				m.forms.inventoryForm.find("input[name='hasingredients']").val('0');
			  			}
			  			m.forms.inventoryForm.find("input[name='data']").val(JSON.stringify(product));
		  			});
						
				}
			});
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		$("#stockhisotrybtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			var sh=$('#myTable').DataTable({
				tableLabel:'Product Stock History',
				filterSelector:'#searchTxt',
				getLink:'getStockHistory.php',
				requestData: {filter:'product'},
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Action',name:'action'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Value',name:'value',format:'cur'},
					{label:'Date',name:'date'},
					{label:'Time',name:'time'},
				],
				tableLimit:30,
			});
		});
			
		function ci(a,b){
			var e=document.createElement('input');
			e.name=a;
			if(a==='image'){
				e.type='file';
				e.files=b;
			}else{
				e.type=a==='sub'?'submit':'text';
				e.value=b;
			}
			
			return e;
		}
		$("form[name=addForm]").on('submit',function(e){
			e.preventDefault();
			var r=$("form[name=addForm] input[name=bns]:checked").val();
			var price=parseFloat($("form[name=addForm] input[name=price]").val());
			if(price<=0){
				if(r==='Produced'){
					alert('No ingredients was added!');
				}else{
					alert('Buying price must be higher than zero');
				}
			}else{
				var form=document.createElement('form');
				form.enctype='multipart/form-data';
				form.method='post';
				form.action='';
				form.style.display='none';
				var action=ci('action',$(this).find('input[name=action]').val());;
				var code=ci('code',$(this).find('input[name=code]').val());;
				var name=ci('name',$(this).find('input[name=name]').val());
				var cat=ci('cat',$(this).find('input[name=cat]').val());
				var des=ci('des',$(this).find('input[name=des]').val());
				var bp=ci('bp',$(this).find('input[name=bp]').val());
				var icost=ci('icost',$(this).find('input[name=icost]').val());
				var markup=ci('markup',$(this).find('input[name=markup]').val());
				var price=ci('price',$(this).find('input[name=price]').val());
				var radio=ci('radyo',r);
				var img=ci('image',$(this).find('input[name=image]')[0].files);
				var ing=ci('ing',JSON.stringify(newProduct.ingredientList));
				var sub=ci('sub','Sub');
				form.insertAdjacentElement('beforeend',action);
				form.insertAdjacentElement('beforeend',code);
				form.insertAdjacentElement('beforeend',name);
				form.insertAdjacentElement('beforeend',cat);
				form.insertAdjacentElement('beforeend',des);
				form.insertAdjacentElement('beforeend',bp);
				form.insertAdjacentElement('beforeend',markup);
				form.insertAdjacentElement('beforeend',icost);
				form.insertAdjacentElement('beforeend',price);
				form.insertAdjacentElement('beforeend',radio);
				form.insertAdjacentElement('beforeend',img);
				form.insertAdjacentElement('beforeend',ing);
				form.insertAdjacentElement('beforeend',sub);
				document.body.insertAdjacentElement('beforeend',form);
				sub.click();
			}
		})
		$("form[name=updateForm]").on('submit',function(e){
			var code=$("form[name=updateForm] input[name=code]").val();
	  		var product=data.find(code,'code','int');
			if(!confirm(`Are you sure you want to change the details of '`+product.name+`'?`)){
				e.preventDefault();
			}
		});
		$("form[name=inventoryForm]").on('submit',function(e){
			var btn=$("form[name=inventoryForm] button:focus").attr('name');
			var code=$("form[name=inventoryForm] input[name=code]").val();
			var qty=parseInt($("form[name=inventoryForm] input[name=qty]").val());
	  		var product=data.find(code,'code','int');
	  		flag=false;
	  		if(btn==='expired' || btn==='damaged'){
	  			if((product.qty-qty)<0){
	  				e.preventDefault();
	  				alert('Cannot add '+btn+' products more than its quantity');
	  			}else{
	  				if(!confirm('Are you sure you want to add '+btn+' '+product.name+' products?')){
	  					e.preventDefault();
	  				}
	  			}
	  		}else{
	  			if(product.hasingredients===1){
	  				if(qty>product.stockinable){
	  					e.preventDefault();
	  					alert('There is not enough ingredients to make the product!');
	  				}
	  			}
	  		}
		});
		$('#productlistbtn').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>