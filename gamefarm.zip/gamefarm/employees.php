<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
	date_default_timezone_set('Asia/Manila');
	if(isset($_POST['add'])){
	    include 'connection.php';
	    $tToday=date_create();
	    $tToday=date_format($tToday,'Y-m-d');
	    $today=date('Ymdhsi');
	    $pos=$_POST['pos'];
	    $name=$_POST['name'];
	    $add=$_POST['address'];
	    $cno=$_POST['cno'];
	    $drate=floatval($_POST['drate']);
	    $hrate=round(((floatval($_POST['drate']))/8),4);
	    $sss=floatval($_POST['sss']);
	    $pi=floatval($_POST['pi']);
	    $ph=floatval($_POST['ph']);
	    $cut_off=date_create();
		$day=intval(date('d'));
	    if($day<16){
	      date_modify($cut_off,'first day of this month');
	      date_modify($cut_off,'+15 days');
	    }else{
	      date_modify($cut_off,'first day of this month');
	      date_modify($cut_off,'+1 month');
	    }
	    $cut_off=date_format($cut_off,'Y-m-d');

	    $query="INSERT INTO employees VALUES('','$today','$pos','$drate','$hrate','$name','$add','$cno','$tToday','0','0','$sss','$pi','$ph','$cut_off')";
	    $result=mysqli_query($con,$query);

	    if($result===false){$err=true;$err_msg=mysqli_error($con);}
	    mysqli_close($con);
	  }

	  if(isset($_POST['update'])){
	    include 'connection.php';
	    date_default_timezone_set('Asia/Manila');
	    $code=$_POST['id_num'];
	    $pos=$_POST['pos'];
	    $name=$_POST['name'];
	    $add=$_POST['address'];
	    $cno=$_POST['cno'];
	    $drate=floatval($_POST['drate']);
	    $hrate=round(((floatval($_POST['drate']))/8),4);
	    $sss=floatval($_POST['sss']);
	    $pi=floatval($_POST['pi']);
	    $ph=floatval($_POST['ph']);

	    $r=mysqli_query($con,"UPDATE employees SET position='$pos', daily_rate='$drate', hourly_rate='$hrate', name='$name', address='$add', contactno='$cno',sss='$sss',pagibig='$pi',philhealth='$ph' WHERE id_num='$code'");
	    echo mysqli_error($con);
	    if($r===false){$err=true;$err_msg=mysqli_error($con);}
	    mysqli_close($con);
	  }

	  if(isset($_POST['attendance'])){
	  	include 'connection.php';
	  	$id_num=$_POST['id_num'];
	  	$pos=$_POST['pos'];
	  	$name=$_POST['name'];
	  	$hw=$_POST['hours_worked'];
	  	$date=date_create();
	  	$date=date_format($date,'Y-m-d');

	  	mysqli_query($con,"BEGIN");
	  	$r=mysqli_query($con,"UPDATE employees SET hours_worked=hours_worked+'$hw' WHERE id_num='$id_num'");
	  	$r1=mysqli_query($con,"INSERT INTO attendance VALUES('','$id_num','$pos','$name','$hw','$date')");
	  	if($r===false || $r1===false){$err=true;$err_msg=mysqli_error($con);mysqli_query($con,"ROLLBACK");}
	  	else{mysqli_query($con,"COMMIT");}
	  	mysqli_close($con);
	  }

	  if(isset($_POST['cashadvance'])){
	  	include 'connection.php';
	  	$id_num=$_POST['id_num'];
	  	$pos=$_POST['pos'];
	  	$name=$_POST['name'];
	  	$ca=$_POST['ca'];
	  	$date=date_create();
	  	$date=date_format($date,'Y-m-d');

	  	mysqli_query($con,"BEGIN");
	  	$r=mysqli_query($con,"UPDATE employees SET cash_advance=cash_advance+'$ca' WHERE id_num='$id_num'");
	  	$r1=mysqli_query($con,"INSERT INTO cashadvance VALUES('','$id_num','$pos','$name','$ca','$date')");
	  	ae($name,'Cash Advances',$ca);
	  	if($r===false || $r1===false){$err=true;$err_msg=mysqli_error($con);mysqli_query($con,"ROLLBACK");}
	  	else{mysqli_query($con,"COMMIT");}
	  	mysqli_close($con);
	  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Employees</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
  	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button id="openDialogNew" class="mr10">New Employee</button>
					<button id="employee_info" class='mr10'>Employee Information</button>
					<button id="employee_payroll" class='mr10'>Payroll</button>
					<button id="employee_payslip" class='mr10'>Pay Slip</button>
					<button id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Employees</label>
					<input type="text" id="searchTxt" style="width: 300px;">
				</div>
			</div>
			<div class="table-wrapper" id="myTable"></div>
		</div>
	</div>
	<?php include 'employeesmodal.php' ?>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript" src='js/jqueryPayrollPlugin.js'></script>
	<script type="text/javascript" src='js/jqueryPayslipPlugin.js'></script>
	<script type="text/javascript">
		var activeTab='Employees';
		$('.nav-title p').html('Employees');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		var m=new Modal(['addForm','updateForm','choiceMenu','attendanceForm','cashAdvanceForm']);
		$('#printpage').on('click',function(){window.print();});
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;
		$('#employee_info').on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			$('.search .input').css('display','flex');
			data=$('#myTable').DataTable({
				tableLabel:'Employee List',
				filterSelector:'#searchTxt',
				getLink:'getEmployees.php',
				dataProperties:[
					{label:'ID',name:'id_num',fit:''},
					{label:'Position',name:'position'},
					{label:'Name',name:'name'},
					{label:'Hourly Rate',name:'hourly_rate',format:'cur'},
					{label:'SSS',name:'sss',format:'cur'},
					{label:'Pag-ibig',name:'pagibig',format:'cur'},
					{label:'Philhealth',name:'philhealth',format:'cur'},
					{label:'Cash Advance',name:'cash_advance',format:'cur'},
					{label:'Hours Worked',name:'hours_worked',format:'wnum'}
				],
				onHoverTitle:'Click to update employee',
				tableLimit:20,
				onClick:function(e){
					var target=e.currentTarget;
		  			var code=target.children[0].innerHTML;
		  			var employee=data.find(code,'id_num','int');
		  			m.show('choiceMenu');
		  			m.forms.choiceMenu.on('submit',function(e){e.preventDefault();});
		  			m.forms.choiceMenu.find('header > label').html("("+employee.id_num+") "+employee.name)
		  			m.forms.choiceMenu.find("button[name='choicemenu1']").on('click',function(e){
		  				e.preventDefault();
		  				m.show('updateForm');
		  				m.forms.updateForm.find("input[name='id_num']").val(employee.id_num);
		  				m.forms.updateForm.find("input[name='pos']").val(employee.position);
			            m.forms.updateForm.find("input[name='name']").val(employee.name);
			            m.forms.updateForm.find("input[name='address']").val(employee.address);
			            m.forms.updateForm.find("input[name='cno']").val(employee.contactno);
			            m.forms.updateForm.find("input[name='drate']").val(employee.daily_rate);
			            m.forms.updateForm.find("input[name='sss']").val(employee.sss);
			            m.forms.updateForm.find("input[name='pi']").val(employee.pagibig);
			            m.forms.updateForm.find("input[name='ph']").val(employee.philhealth);
			            m.forms.updateForm.find("input[name='date_hired']").val(employee.date_hired);
		  			});
		  			m.forms.choiceMenu.find("button[name='choicemenu2']").on('click',function(e){
		  				e.preventDefault();
		  				m.show('attendanceForm');
		  				m.forms.attendanceForm.find("input[name='id_num']").val(employee.id_num);
		          		m.forms.attendanceForm.find("input[name='pos']").val(employee.position);
			  			m.forms.attendanceForm.find("input[name='name']").val(employee.name);
			  			m.forms.attendanceForm.find("input[name='hours_worked']").val('');
		  			});
		  			m.forms.choiceMenu.find("button[name='choicemenu3']").on('click',function(e){
		  				e.preventDefault();
		  				m.show('cashAdvanceForm');
		  				m.forms.cashAdvanceForm.find("input[name='id_num']").val(employee.id_num);
		          		m.forms.cashAdvanceForm.find("input[name='pos']").val(employee.position);
			  			m.forms.cashAdvanceForm.find("input[name='name']").val(employee.name);
			  			m.forms.cashAdvanceForm.find("input[name='ca']").val('');
		  			});
				}
			});
		});

		$('#employee_payroll').on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			$('.search .input').css('display','none');
			$('#myTable').PayrollPlugin({
				getLink:'getPayroll.php',
				tableColumns:['Position','Name','Hourly Rate','Hours Worked','Gross Salary','Deductions','Net Salary'],
				ajaxDataProperties:['position','name','hourly_rate','hours_worked','gross_salary','deductions','net_salary']
			});
		});

		$('#employee_payslip').on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			$('.search .input').css('display','none');
			$('#myTable').PayslipPlugin({
				getLink:'getPayroll.php',
				tableColumns:['Position','Name','Hourly Rate','Hours Worked','Gross Salary','Deductions','Net Salary'],
				ajaxDataProperties:['position','name','hourly_rate','hours_worked','gross_salary','deductions','net_salary']
			});
		});
		
		
		$("form[name=updateForm]").on('submit',function(e){
			var code=$("form[name=updateForm] input[name=id_num]").val();
	  		var employee=data.find(code,'id_num','int');
			if(!confirm(`Are you sure you want to change the details of '`+employee.position+` `+employee.name+`'?`)){
				e.preventDefault();
			}
		});
		$("form[name=attendanceForm]").on('submit',function(e){
			var code=$("form[name=attendanceForm] input[name=id_num]").val();
			var hw=$("form[name=attendanceForm] input[name=hours_worked]").val();
	  		var employee=data.find(code,'id_num','int');
			if(!confirm(`Are you sure you want to add '`+hw+`' hours of work to '`+employee.position+` `+employee.name+`'?`)){
				e.preventDefault();
			}
		});
		$("form[name=cashAdvanceForm]").on('submit',function(e){
			var code=$("form[name=cashAdvanceForm] input[name=id_num]").val();
			var ca=$("form[name=cashAdvanceForm] input[name=ca]").val();
	  		var employee=data.find(code,'id_num','int');
			if(!confirm(`Are you sure you want to add '`+ca+`' pesos cash advance to '`+employee.position+` `+employee.name+`'?`)){
				e.preventDefault();
			}
		});
		$('#employee_info').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>
