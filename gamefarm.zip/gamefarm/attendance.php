<?php
	include 'session.php';
    include 'connection.php';
    include 'getattendance.php';
    $sql = "SELECT * FROM employees";
    $sql1 = "SELECT employeeattendance.date, employeeattendance.time_in, employeeattendance.time_out, employees.name FROM employeeattendance INNER JOIN employees ON employees.id_num = employeeattendance.empId ORDER BY date DESC, time_in DESC";
             
    $results = mysqli_query($con, $sql);
    $results_attendance = mysqli_query($con, $sql1);
    $alloted_time = '08:00:00';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
    <meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
</head>
<body>
    <?php include 'getDate.php'; ?>
    
	<div class="app">
		<?php include 'pagemenus.php' ?>
        <div class="row" style="margin-top: 3rem;">
            <div class="container">
                <div class="col-md-6 col-xs-12">
                    <div class="login-box-body">
                        <h3>Select Employee</h3>
                        <form id="attendance" method="POST" action="getattendance.php">
                            <div class="form-group has-feedback">
                                <!-- <input type="text" class="form-control input-lg" name="employee" style="background-color: #fff;" required autocomplete="off" placeholder="Employee ID" autofocus> -->
                                <select class="form-control" name="id">
                                    <?php foreach($results as $result) : ?>
                                        <option value="<?php echo $result['id_num'];?>"><?php echo $result['name'];?></option>
                                    <?php endforeach; ?>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="status">
                                <option value="in">Time In</option>
                                <option value="out">Time Out</option>
                                </select>
                            </div>
                            <div class="row">
                            <div class="col-xs-6">
                                    <button type="submit" class="btn btn-theme" name="signin"><i class="fa fa-sign-in"></i>Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>        
                </div>
            </div> <!-- end of container -->
        </div> <!-- end of row -->
        <div class="row">
            <div class="container">   
                <div class="col-xs-12">
                    <h2>Attendance List</h2>
                    <table id="example1" class="table table-bordered">
                        <thead>
                            <th class="hidden"></th>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Remarks</th>
                        </thead>
                        <tbody>
                            <?php 
                            foreach($results_attendance as $results) {
                                if($results['time_in'] < $alloted_time) {
                                    echo '<tr">';
                                    echo '<td>' . $results['date'] . '</td>';
                                    echo '<td>' . $results['name'] . '</td>';
                                    echo '<td>' . $results['time_in'] . '</td>';
                                    echo '<td>' . $results['time_out'] . '</td>';
                                    echo '<td> On time </td>';
                                } else {
                                    echo '<tr style="background-color: #ffb3b3">';
                                    echo '<td>' . $results['date'] . '</td>';
                                    echo '<td>' . $results['name'] . '</td>';
                                    echo '<td>' . $results['time_in'] . '</td>';
                                    echo '<td>' . $results['time_out'] . '</td>';
                                    echo '<td> Late </td>';
                                }
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end of row -->

</div>
    </div>
    
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Attendance';
		$('.nav-title p').html('Attendance');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
    </script>
    


</body>
</html>

