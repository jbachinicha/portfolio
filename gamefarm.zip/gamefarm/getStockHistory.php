<?php
	include 'session.php';
	include 'getDate.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());
	$a=json_decode(file_get_contents('php://input'),true);
	$filter=$a['filter'];

	$sql="SELECT * FROM ".$filter."stockhistory ORDER BY date DESC, time DESC";
	$r=mysqli_query($con,$sql);
	while($rw=mysqli_fetch_assoc($r)){
		$arr['code']=intval($rw['code']);
		$arr['name']=$rw['name'];
		$arr['price']=floatval($rw['price']);
		$arr['action']=$rw['action'];
		$arr['qty']=floatval($rw['qty']);
		$arr['value']=floatval($rw['value']);
		$date=gd($rw['date']);
		$arr['date']=fd($date,'M d, Y');
		$time=gd($rw['time']);
		$arr['time']=fd($time,'h:i:s A');
		array_push($myArr['data'], $arr);
	}

	exit(json_encode($myArr));
?>