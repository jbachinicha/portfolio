<?php
  echo "<div class='modal' style='display: none;'>
    <form name='choiceMenu' style='display: none;'>
      <header>
          <label>Choose Action</label>
          <span title='Close'><div><div>&times;</div><div></span>
      </header>
      <div class='choice-menu'>
        <button class='mb10' name='choicemenu1'>Update Employee Information</button>
        <button class='mb10' name='choicemenu2'>Add Attendance</button>
        <button class='mb10' name='choicemenu3'>Add Cash Advance</button>
      </div>
    </form>
    <form name='addForm' action='' method='post' style='display: none;'>
      <header>
        <label>Add New Employee</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:300px;'>
          <div class='form-header'>Employee Information</div>
          <div class='form-content'>
            <div class='input mb10'>
              <label>Position</label>
              <input type='text' name='pos' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Address</label>
              <input type='text' name='address' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Contact Number</label>
              <input type='text' name='cno' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Daily Rate</label>
              <input type='number' name='drate' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>SSS</label>
              <input type='number' name='sss' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Pag-ibig</label>
              <input type='number' name='pi' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Philhealth</label>
              <input type='number' name='ph' required autocomplete>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='add' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='updateForm' action='' method='post' style='display: none;'>
      <header>
        <label>Update Employee Information</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <div class='input mb10'>
              <label>ID Number</label>
              <input type='text' name='id_num' readonly>
            </div>
            <div class='input mb10'>
              <label>Position</label>
              <input type='text' name='pos' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Address</label>
              <input type='text' name='address' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Contact Number</label>
              <input type='text' name='cno' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Daily Rate</label>
              <input type='number' name='drate' step='0.01' min='1' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>SSS</label>
              <input type='number' name='sss' step='0.01' min='1' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Pag-ibig</label>
              <input type='number' name='pi' step='0.01' min='1' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Philhealth</label>
              <input type='number' name='ph' step='0.01' min='1' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Date Hired</label>
              <input type='text' name='date_hired' readonly>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='update' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='attendanceForm' action='' method='post' style='display: none;'>
      <header>
        <label>Change Hours Worked</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <div class='input mb10'>
              <label>ID Number</label>
              <input type='text' name='id_num' readonly>
            </div>
            <div class='input mb10'>
              <label>Position</label>
              <input type='text' name='pos' readonly>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' readonly>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Hours Worked</label>
              <input type='number' name='hours_worked' step='0.01' min='1' required autocomplete autofocus>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='attendance' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='cashAdvanceForm' action='' method='post' style='display: none;'>
      <header>
        <label>Add Employee Cash Advance</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <div class='input mb10'>
              <label>ID Number</label>
              <input type='text' name='id_num' readonly>
            </div>
            <div class='input mb10'>
              <label>Position</label>
              <input type='text' name='pos' readonly>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' readonly>
            </div>
            <div class='input mb10' title='Enter a valid number'>
              <label>Cash Advance</label>
              <input type='number' name='ca' step='0.01' min='1' required autocomplete autofocus>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='cashadvance' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
  </div>";
?>