<?php
  include 'session.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Point Of Sales</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="js/jQuery-SalesPlugin.css">
  <script type="text/javascript" src='js/jquery3-3-1.js'></script>
  <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->
  <!-- <script src="js/bootstrap.min.js"></script>   -->
  
</head>
<body>
<div class="app">
  <?php include 'pagemenus.php' ?>
      <div class="pagebody">
        <div id="sales"></div>
      </div>
  
</div>
<?php include 'productsmodal.php' ?>
<script type="text/javascript" src='js/jquery3-3-1.js'></script>
<script type="text/javascript" src='js/jQuery-SalesPlugin.js'></script>
<script type="text/javascript">
  
    var activeTab='POS';
    $('.nav-links a').each(function(){
      $(this).removeClass('active');
      if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
    });
    $('.nav-title p').html('POS');
  $(function() {
    $('#sales').salesPlugin({
        getProductsUrl:'getProducts.php',
        saveSalesUrl:'pos.php',
        receiptUrl: 'receipt.php'
      });
  });

</script>
</body>
</html>