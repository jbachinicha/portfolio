<div class='modal' style='display: none;'>
    <form name='choiceMenu' style='display: none;'>
      <header>
          <label>Choose Action</label>
          <span title='Close'><div><div>&times;</div><div></span>
      </header>
      <div class='choice-menu'>
        <button class='mb10' name='choicemenu1'>Update Product Information</button>
        <button class='mb10' name='choicemenu2'>Manage Inventory</button>
      </div>
    </form>
    <form name='addForm' style='display: none;height: 500px;'>
      <header>
        <label id='addFormHeader'>Add New Product</label>
        <input type='hidden' name='action'>
        <input type='hidden' name='code'>
        <span class='close-btn'>&times</span>
      </header>
      <content style='height:100%;width:850px;' id='addFormContent'>
        <div class='form' style='max-width: 350px;flex-grow:1;justify-content:flex-start;'>
          <div class='form-header'>Product Information</div>
          <div class='form-content'>
            <div class='img-holder'>
              <img src='products/nopreview.png' id='imagePreviewAdd' style='width: 150px;height: 150px;' title='Click to change image' onclick='changeImage(event)'>
              <input type='file' name='image' accept='image/*' style='display: none;' onchange='getPreview(event,0)'>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Category</label>
              <input type='text' name='cat' required autocomplete>
            </div>
            <div class='input mb10'>
              <label>Description</label>
              <input type='text' name='des' autocomplete>
            </div>
            <div class='input mb10'  style="display: none">
              <label style="display: none"><input type='radio' value='Bought' name='bns' checked />Default</label>
              <label style="display: none"><input type='radio' value='Produced' name='bns'/>Has Ingredients</label>
            </div>
            <div class='input mb10 bought' title='Enter a valid numerical value' style='display:none;'>
              <label>Buying Price</label>
              <input type='number' name='bp' step='0.01' min='0' autocomplete onkeyup='newProduct.calc()'>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Mark Up Margin (%)</label>
              <input type='number' name='markup' step='0.01' min='1' required autocomplete onkeyup='newProduct.calc()'>
            </div>
            <div class='input mb10 production'>
              <label>Cost of Ingredients:</label>
              <input type='text' name='icost' readonly>
            </div>
            <div class='input mb10'>
              <label>Price:</label>
              <input type='text' name='price' readonly>
            </div>
          </div>
        </div>
        <div class='form' style='justify-content: flex-start;min-width:-webkit-min-content;flex-grow:1;' id='addIngredientsForm'>
          <div class='form-header'>Product Ingredient Information</div>
          <div class='form-content'>
            <div class='row'>
              <div class='input mb10'>
                <label>Name</label>
                <select name='ingredients'></select>
                <label>Units</label>
                <input type='text' name='qty' autocomplete style='width: 60px;margin-right:20px;'>
                <div class='input-btn'>
                  <span class='btn' id='addnewproductingredient'>Add Ingredient</span>
                </div>
              </div>
              <div class='table-wrapper'>
                <table>
                  <thead>
                    <tr>
                      <th class='table_label' colspan='6'>Product Ingredient List</th>
                    </tr>
                    <tr>
                      <th style='display:none;'></th>
                      <th>Name</th>
                      <th>Units</th>
                      <th>Price Per Unit</th>
                      <th>Cost</th>
                      <th style='width: 10px;'>Action</th>
                    </tr>
                  </thead>
                  <tbody id='productingredientsTable'></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='add' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='inventoryForm' action='' method='post' style='display: none;'>
      <header>
        <label>Manage Product Inventory</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <input type='hidden' name='price'>
            <input type='hidden' name='units'>
            <div class='input mb10'>
              <label>Code</label>
              <input type='text' name='code' readonly>
            </div>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' readonly>
            </div>
            <div class='input mb10'>
              <label>In Stock Quantity</label>
              <input type='text' name='instockqty' readonly>
            </div>
            <div class='input mb10' id='stockinableqtyholder' style='display:none;'>
              <label>Stockinable Quantity</label>
              <input type='text' name='stockinableqty' readonly>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Quantity</label>
              <input type='number' name='qty' step='1' min='1' required autocomplete autofocus>
            </div>
            <input type='hidden' name='data'>
            <input type='hidden' name='hasingredients'>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='stockin' style='width: 50%; padding: 10px 20px;font-size: 16px;'>Stock In</button>
        <button name='expired' style='width: 50%; padding: 10px 20px;font-size: 16px;'>Expired</button>
      </div>
    </form>
  </div>