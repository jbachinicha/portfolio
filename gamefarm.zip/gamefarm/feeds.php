<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
	if(isset($_POST['add'])){
	    include 'connection.php';
	    $name=addslashes($_POST['name']);
	    $des=addslashes($_POST['des']);
	    $units=floatval($_POST['units']);
	    $unitlabel=addslashes($_POST['unitlabel']);
	    $price=floatval($_POST['price']);
	    $ppu=round(($price/$units),4);

	    $query="INSERT INTO ingredients VALUES('','$name','$des','$units','$unitlabel','$price','$ppu','0')";
	    $result=mysqli_query($con,$query);
	    if($result===false){$err_msg=mysqli_error($con);$err=true;}
	    mysqli_close($con);
	}

    if(isset($_POST['update'])){
    	include 'connection.php';
    	$code=$_POST['code'];
    	$name=addslashes($_POST['name']);
	    $des=addslashes($_POST['des']);
	    $units=floatval($_POST['units']);
	    $unitlabel=addslashes($_POST['unitlabel']);
	    $price=floatval($_POST['price']);
	    $ppu=round(($price/$units),4);
    	$query="UPDATE ingredients SET name='$name', price='$price',description='$des',units='$units',unitlabel='$unitlabel',unitprice='$ppu' WHERE code='$code'";

    	$result=mysqli_query($con,$query);
    	if($result===false){$err_msg=mysqli_error($con);$err=true;}
    	mysqli_close($con);
  	}	

  	if(isset($_POST['stockin']) || isset($_POST['expired']) || isset($_POST['damaged'])){
  		include 'connection.php';
  		$code=$_POST['code'];
  		$name=$_POST['name'];
  		$qty=floatval($_POST['qty']);
  		$instockqty=floatval($_POST['instockqty']);
  		$price=floatval($_POST['price']);
  		$units=intval($_POST['units']);
  		$value=$qty*$price;
  		$totalunits;
  		$date=gd();
  		$date=fd($date,'Y-m-d');
  		$time=gd();
  		$time=fd($time,'H:i:s');
  		$sql;
  		$action=(isset($_POST['stockin']))?'Purchased':(((isset($_POST['damaged'])))?'Damaged':'Expired');

  		mysqli_query($con,"BEGIN");
  		if(isset($_POST['stockin'])){
  			$totalunits=(($instockqty+$qty)*$units);
  			$sql="UPDATE ingredients SET totalunits='$totalunits' WHERE code='$code'";
  		}else{
  			$totalunits=(($instockqty-$qty)*$units);
  			$sql="UPDATE ingredients SET totalunits='$totalunits' WHERE code='$code'";
  		}
  		$sql1="INSERT INTO ingredientstockhistory VALUES('','$code','$name','$price','$action','$qty','$value','$date','$time')";
  		$act;
  		switch ($action) {
  			case 'Produced': $act='Production';break;
  			case 'Purchased': $act='Purchases';break;
  			case 'Damaged': $act='Damages';break;
  			case 'Expired': $act='Expiries';break;
  			default: break;
  		}
  		ae($name,$act,$value);
  		$r=mysqli_query($con,$sql);
  		if($r===false){$err_msg=mysqli_error($con);$err=true;}
  		$r1=mysqli_query($con,$sql1);
  		if($r1===false){$err_msg=mysqli_error($con);$err=true;}
  		if($err){
  			mysqli_query($con,"ROLLBACK");
  		}else{
  			mysqli_query($con,"COMMIT");
  		}
  		mysqli_close($con);
  	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Feeds</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button id="openDialogNew" class="mr10">New Feed</button>
					<button id="ingredientlistbtn" class="mr10">Feeds List</button>
					<button id="stockhisotrybtn" class="mr10">Stock History</button>
					<button id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Feeds</label>
					<input type="text" id="searchTxt" style="width: 295px;">
				</div>
			</div>
			<div class="table-wrapper" id="myTable"></div>
		</div>
	</div>
	<?php include 'ingredientsmodal.php'; ?>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Feeds';
		$('.nav-title p').html('Feeds');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		$('#printpage').on('click',function(){window.print();});
		var m=new Modal(['addForm','updateForm','choiceMenu','inventoryForm']);
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;
		$('#ingredientlistbtn').on('click',function(){
			data=$('#myTable').DataTable({
				tableLabel:'Feed Lists',
				filterSelector:'#searchTxt',
				getLink:'getIngredients.php',
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Description',name:'des'},
					{label:'Price',name:'price',format:'cur'},
					{label:'Quantity',name:'qty',format:'num'},
					{label:'Unit Per Quantity',name:'myLabel'},
					{label:'Price Per Unit',name:'unitprice',format:'fn4'},
					{label:'Total Units',name:'myTotalLabel'},
					{label:'Value',name:'value',format:'cur'},
				],
				onHoverTitle:'Click to update feed',
				tableLimit:14,
				onClick:function(e){
					var target=e.currentTarget;
		  			var code=target.children[0].innerHTML;
		  			var ingredient=data.find(code,'code','int');
		  			m.show('choiceMenu');
		  			m.forms.choiceMenu.find('button[name=choicemenu1]').on('click',function(e){
		  				e.preventDefault();
		  				m.show('updateForm');
		  				m.forms.updateForm.find("input[name='code']").val(ingredient.code);
			  			m.forms.updateForm.find("input[name='name']").val(ingredient.name);
			  			m.forms.updateForm.find("input[name='des']").val(String(ingredient.des));
			  			m.forms.updateForm.find("input[name='units']").val(ingredient.units);
			  			m.forms.updateForm.find("input[name='unitlabel']").val(ingredient.unitlabel);
			  			m.forms.updateForm.find("input[name='price']").val(ingredient.price);
		  			});
		  			m.forms.choiceMenu.find('button[name=choicemenu2]').on('click',function(e){
		  				e.preventDefault();
		  				m.show('inventoryForm');
		  				m.forms.inventoryForm.find("input[name='code']").val(ingredient.code);
			  			m.forms.inventoryForm.find("input[name='name']").val(ingredient.name);
			  			m.forms.inventoryForm.find("input[name='price']").val(ingredient.price);
			  			m.forms.inventoryForm.find("input[name='units']").val(ingredient.units);
			  			m.forms.inventoryForm.find("input[name='instockqty']").val(ingredient.qty);
		  			});
						
				}
			});
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		$("#stockhisotrybtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			var sh=$('#myTable').DataTable({
				tableLabel:'Feed Stock History',
				filterSelector:'#searchTxt',
				getLink:'getStockHistory.php',
				requestData: {filter:'ingredient'},
				dataProperties:[
					{label:'Code',name:'code',fit:''},
					{label:'Name',name:'name'},
					{label:'Action',name:'action'},
					{label:'Quantity',name:'qty',format:'num'},
					{label:'Value',name:'value',format:'cur'},
					{label:'Date',name:'date'},
					{label:'Time',name:'time'},
				],
				tableLimit:30,
			});
		});
			
		$("form[name=updateForm]").on('submit',function(e){
			var code=$("form[name=updateForm] input[name=code]").val();
	  		var ingredient=data.find(code,'code','int');
			if(!confirm(`Are you sure you want to change the details of '`+ingredient.name+`'?`)){
				e.preventDefault();
			}
		});
		$("form[name=inventoryForm]").on('submit',function(e){
			var btn=$("form[name=inventoryForm] button:focus").attr('name');
			var code=$("form[name=inventoryForm] input[name=code]").val();
			var qty=parseFloat($("form[name=inventoryForm] input[name=qty]").val());
	  		var ingredient=data.find(code,'code','int');
	  		flag=false;
	  		if(btn==='expired' || btn==='damaged'){
	  			if((ingredient.qty-qty)<0){
	  				e.preventDefault();
	  				alert('Cannot add '+btn+' feed more than its quantity');
	  			}
	  		}
		});
		$('#ingredientlistbtn').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>