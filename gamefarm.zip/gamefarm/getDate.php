<?php
	function gd($a1=false){
		date_default_timezone_set('Asia/Manila');
		$a=$a1?date_create($a1):date_create();
		return $a;
		echo $a;
	}

	function fd($d,$f){
		return date_format($d,$f);
	}

	function ae($a,$b,$c){
		include 'connection.php';
		$date=gd();
		$date=fd($date,'Y-m-d');
		$r=mysqli_query($con,"INSERT INTO expenses VALUES('','$a','$b','$c','$date')");
		if($r===false){echo mysqli_error($con);}
	}
?>