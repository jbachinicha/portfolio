<?php
  include 'session.php';
  include 'connection.php';
  date_default_timezone_set('Asia/Manila');

  $myArr=array('status'=>'','message'=>'','data'=>array(),'startDate'=>'','endDate'=>'','totalSalaries'=>0,'today'=>'');
  $startDate;
  $endDate;
  $total=0;
  $day=intval(date('d'));
  $today=date_create();
  $todayF=date_format($today,'F d, Y');
  $today=date_format($today,'Y-m-d');
  $startDate=date_create();
  $endDate=date_create();

  if($day>15){
    date_modify($startDate,'first day of this month');
    $startDate=date_format($startDate,'Y-m-d');
    date_modify($endDate,'first day of this month');
    date_modify($endDate,'+14 days');
    $endDate=date_format($endDate,'Y-m-d');
  }else{
    date_modify($startDate,'first day of this month');
    date_modify($startDate,'-1 month');
    date_modify($startDate,'+15 days');
    $startDate=date_format($startDate,'Y-m-d');
    date_modify($endDate,'first day of this month');
    date_modify($endDate,'+14 days');
    date_modify($endDate,'-1 month');
    date_modify($endDate,'last day of this month');
    $endDate=date_format($endDate,'Y-m-d');
  }

  $r=mysqli_query($con,"SELECT MAX(payroll_id) as pid FROM payroll");
  $rw=mysqli_fetch_assoc($r);
  $payroll_id=$rw['pid']===NULL?1:$rw['pid'];

  $r=mysqli_query($con,"SELECT * FROM payroll WHERE payroll_id='$payroll_id'");
  while($rw=mysqli_fetch_assoc($r)){
    $arr['startDate']=$rw['startDate'];
    $startDate=$rw['startDate'];
    $arr['endDate']=$rw['endDate'];
    $endDate=$rw['endDate'];
    $arr['position']=$rw['position'];
    $arr['name']=$rw['name'];
    $arr['hourly_rate']=$rw['hourly_rate'];
    $arr['hours_worked']=$rw['hours_worked'];
    $arr['gross_salary']=$rw['gross_salary'];
    $arr['cash_advance']=$rw['cash_advance'];
    $arr['sss']=$rw['sss'];
    $arr['pagibig']=$rw['pagibig'];
    $arr['philhealth']=$rw['philhealth'];
    $arr['deductions']=$rw['deductions'];
    $arr['net_salary']=$rw['net_salary'];
    $arr['total']=$rw['total'];
    $total=$rw['total'];
    array_push($myArr['data'],$arr);
  }

  $myArr['startDate']=date_format(date_create($startDate),'F d, Y');
  $myArr['endDate']=date_format(date_create($endDate),'F d, Y');
  $myArr['totalSalaries']=$total;
  $myArr['today']=$todayF;

  exit(json_encode($myArr));
?>