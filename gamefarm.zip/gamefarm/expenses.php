<?php
	include 'session.php';
	include 'getDate.php';
	$err=false;
	$err_msg;
	if(isset($_POST['add'])){
	    include 'connection.php';
	    $name=addslashes($_POST['name']);
	    $type=addslashes($_POST['type']);
	    $amount=floatval($_POST['amount']);
	    $date=gd();
	    $date=fd($date,'Y-m-d');
	    $query="INSERT INTO expenses VALUES('','$name','$type','$amount','$date')";
	    $result=mysqli_query($con,$query);
	    if($result===false){$err_msg=mysqli_error($con);$err=true;}
	    mysqli_close($con);
	}

    if(isset($_POST['update'])){
    	include 'connection.php';
    	$code=$_POST['code'];
    	$name=addslashes($_POST['name']);
	    $type=addslashes($_POST['type']);
	    $amount=floatval($_POST['amount']);
    	$query="UPDATE expenses SET name='$name', type='$type', price='$amount' WHERE id='$code'";

    	$result=mysqli_query($con,$query);
    	if($result===false){$err_msg=mysqli_error($con);$err=true;}
    	mysqli_close($con);
  	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Expenses</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button id="openDialogNew" class="mr10">New Expense</button>
					<button class='mr10' id="latestBtn">Latest</button>
					<button class='mr10' id="dailyBtn">Day</button>
					<button class='mr10' id="weeklyBtn">Week</button>
					<button class='mr10' id="monthlyBtn">Month</button>
					<button class='mr10' id="yearlyBtn">Year</button>
					<button class='mr10' id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Expenses</label>
					<input type="text" id="searchTxt" style="width: 300px;">
				</div>
			</div>
			<div class="table-wrapper">
				<div id="myTable1"></div>
				<div id="myTable2"></div>
			</div>
		</div>
	</div>
	<?php include 'expensesmodal.php'; ?>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Expenses';
		$('.nav-title p').html('Expenses');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		$('#printpage').on('click',function(){window.print();});
		var m=new Modal(['addForm','updateForm','choiceMenu','inventoryForm']);
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;

		$('#latestBtn').on('click',function(){
			data=$('#myTable1').DataTable({
				tableLabel:'Latest Expenses',
				filterSelector:'#searchTxt',
				getLink:'getExpenses.php',
				requestData:{filter:'History'},
				dataProperties:[
					{label:'Code',name:'code',hide:''},
					{label:'Name',name:'name'},
					{label:'Type',name:'type'},
					{label:'Amount',name:'amount',format:'cur'},
					{label:'Date',name:'date'}
				],
				tableLimit: 20,
				onHoverTitle:'Click to update expense',
				onClick:function(e){
					var target=e.currentTarget;
		  			var code=target.children[0].innerHTML;
		  			var expense=data.find(code,'code','int');
	  				m.show('updateForm');
	  				m.forms.updateForm.find("input[name='code']").val(expense.code);
		  			m.forms.updateForm.find("input[name='name']").val(expense.name);
		  			m.forms.updateForm.find("input[name='type']").val(expense.type);
		  			m.forms.updateForm.find("input[name='amount']").val(expense.amount);
				}
			});
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		function get(a){
			data=$('#myTable1').DataTable({
				tableLabel:`<div style='margin-bottom:10px'>`+a+` Expense Report</div>
					<div style='margin-bottom:10px'>Total Expense: <span id='wetwew'></span></div>
				`,
				filterSelector:'#searchTxt',
				getLink:'getExpenses.php',
				requestData:{filter:a},
				dataProperties:[
					{label:'Name',name:'name'},
					{label:'Type',name:'type'},
					{label:'Amount',name:'amount',format:'cur'},
				],
				sumColumns:[
					{name:'amount',id:'wetwew'}
				],
			});
		}

		$("#dailyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get("Today's");
		});
		$("#weeklyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get("This Week's");
		});
		$("#monthlyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get("This Month's");
		});
		$("#yearlyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get("This Year's");
		});
		$('#latestBtn').trigger('click');
	</script>
</body>
</html>
<?php
	if($err){
		echo "<script>setTimeout(function(){alert(`".$err_msg."`)},100);</script>";
	}
?>