<?php
	include 'session.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());

	$r=mysqli_query($con,"SELECT * FROM equipments ORDER BY code DESC");
	while($rw=mysqli_fetch_assoc($r)){
		$arr['code']=intval($rw['code']);
		$arr['name']=$rw['name'];
		$arr['price']=floatval($rw['price']);
		$arr['qty']=intval($rw['qty']);
		$arr['value']=$arr['qty']*$arr['price'];
		array_push($myArr['data'], $arr);
	}

	exit(json_encode($myArr));
?>