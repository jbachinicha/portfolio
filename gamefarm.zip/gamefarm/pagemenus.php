<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->

</head>
<body>
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0px;
  font-family: 'segoe ui';
}

.nav-container {
  position: sticky;
  top: 0;
  background-color: #1a4758;
  z-index: 1;
}

.nav {
  position: relative;
  margin-left: auto;
  margin-right: auto;
  height: 51px;
  width: 100%;
  max-width: 1026px;
}

.nav > .nav-header {
  display: inline;
}

.nav > .nav-header > .nav-title {
  display: inline-block;
  font-size: 22px;
  color: #fff;
  padding: 10px 10px 10px 10px;
}

.nav > .nav-header > .nav-title p{
    display: none;
}

.nav > .nav-btn {
  display: none;
}

.nav > .nav-links {
  display: inline;
  float: right;
  font-size: 18px;
}

.nav > .nav-links > a {
  display: inline-block;
  padding: 13px 10px 13px 10px;
  text-decoration: none;
  color: #efefef;
  font-weight: bold;
}

.nav > .nav-links > a:hover {
  background-color: rgba(0, 0, 0, 0.3);
}

.nav > #nav-check {
  display: none;
}

label {
    cursor: pointer;
}

.icon {
    position: absolute;
    top: 0;
    left: 0;
    background-image: url('logo-icon.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    width: 50px;
    height: 50px;
}

@media (max-width: 650px) {
    .nav > .nav-header > .nav-title p{
        font-size: 20px;
    }
        
}

@media (max-width:900px) {
  .nav > .nav-btn {
    display: inline-block;
    position: absolute;
    right: 0px;
    top: 0px;
  }
  .nav > .nav-btn > label {
    display: inline-block;
    width: 50px;
    padding: 13px;
  }
  .nav > .nav-btn > label:hover {
    background-color: rgba(0, 0, 0, 0.3);
  }
  .nav > .nav-btn > label > span {
    display: block;
    width: 25px;
    height: 10px;
    border-top: 2px solid #eee;
  }
  .nav > .nav-links {
    position: absolute;
    display: block;
    width: 100%;
    background-color: #1a4758;
    height: 100vh;
    /* transition: all 0.3s ease-in; */
    overflow: hidden;
    top: 50px;
    left: 0px;
  }
  .nav > .nav-links > a {
    display: block;
    width: 100%;
    text-align: left;
  }
  .nav > #nav-check:not(:checked) + .nav-links {
    height: 0px;
  }
  .nav > #nav-check:checked + .nav-links {
    height: calc(100vh - 50px);
    overflow-y: auto;
  }
  .nav > .nav-header > .nav-title p{
      display: block;
      position: absolute;
      left: 60px;
      margin-top: 0;
  }

}
</style>
<div class="nav-container">
    <div class="nav">
        <div class="nav-header">
            <div class="nav-title">
                <div class="icon"></div>
                <p></p>
            </div>
        </div>
        <div class="nav-btn" id="nav-btn">
            <label for="nav-check">
            <span></span>
            <span></span>
            <span></span>
            </label>
        </div>
        <input type="checkbox" id="nav-check">
        <div class="nav-links">
                    <a href='pointofsales.php'>POS</a>
                    <a href='products.php'>Products</a>
                    <a href='feeds.php'>Feeds</a>
                    <a href='equipments.php'>Equipments</a>
                    <a href='employees.php'>Employees</a>
                    <a href='attendance.php'>Attendance</a>
                    <a href='sales.php'>Sales</a>
                    <a href='expenses.php'>Expenses</a>
                    <a href='logout.php'>Logout</a>
        </div>
    </div>
</div>
<!-- <script>
  document.getElementById('nav-btn').addEventListener('click', function() {

    document.getElementById('salesPluginProductListWrapper').style.display = "none";
  });
</script> -->
</body>
</html>