<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody"></div>
	</div>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/modal.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Home';
		$('.pagemenus a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
	</script>
</body>
</html>