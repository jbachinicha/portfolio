<?php
	include 'session.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());

	$r=mysqli_query($con,"SELECT * FROM ingredients ORDER BY code DESC");
	while($rw=mysqli_fetch_assoc($r)){
		$arr['code']=intval($rw['code']);
		$arr['name']=$rw['name'];
		$arr['des']=$rw['description'];
		$arr['price']=floatval($rw['price']);
		$arr['units']=intval($rw['units']);
		$arr['unitlabel']=$rw['unitlabel'];
		$arr['myLabel']=number_format($rw['units']).''.$rw['unitlabel'].'';
		$arr['myTotalLabel']=number_format($rw['totalunits']).''.$rw['unitlabel'].'';
		$arr['myUnits']=intval(0);
		$arr['myCost']=intval(0);
		$arr['unitprice']=floatval($rw['unitprice']);
		$arr['totalunits']=intval($rw['totalunits']);
		$arr['value']=$arr['totalunits']*$arr['unitprice'];
		$arr['qty']=($arr['totalunits']/$rw['units']);
		$arr['qty']=round($arr['qty'],2);
		array_push($myArr['data'], $arr);
	}

	exit(json_encode($myArr));
?>