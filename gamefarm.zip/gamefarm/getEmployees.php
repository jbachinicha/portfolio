<?php
	include 'session.php';
	include 'connection.php';

	//$a=json_decode(file_get_contents('php://input'),true);
	$myArr=array('status'=>'','message'=>'','data'=>array());
	date_default_timezone_set('Asia/Manila');
    $date=date('M d, Y');

	$r=mysqli_query($con,"SELECT * FROM employees ORDER BY id DESC");
	// $r=mysqli_query($con, "SELECT employees.id,
	// 							  employees.id_num,
	// 							  employees.position,
	// 							  employees.daily_rate,
	// 							  employees.hourly_rate,
	// 							  employees.name,
	// 							  employees.address,
	// 							  employees.contactno,
	// 							  employees.date_hired,
	// 							  employees.hours_worked,
	// 							  employees.cash_advance,
	// 							  employees.sss,
	// 							  employees.pagibig,
	// 							  employees.philhealth,
	// 							  employees.payroll_cut_off,
	// 							  employeeattendance.time_in,
	// 							  employeeattendance.time_out
	// 					   FROM employees 
	// 					   INNER JOIN employeeattendance
	// 					   ON employeeattendance.empId = employee.id_num ");
	while($rw=mysqli_fetch_assoc($r)){
		$arr['dateF']=$date;
		$arr['id_num']=floatval($rw['id_num']);
		$arr['position']=$rw['position'];
		$arr['daily_rate']=$rw['daily_rate'];
		$arr['hourly_rate']=floatval($rw['hourly_rate']);
		$arr['name']=$rw['name'];
		$arr['address']=$rw['address'];
		$arr['contactno']=$rw['contactno'];
		$arr['hours_worked']=floatval($rw['hours_worked']);
		$arr['cash_advance']=floatval($rw['cash_advance']);
		$arr['sss']=floatval($rw['sss']);
		$arr['pagibig']=floatval($rw['pagibig']);
		$arr['philhealth']=floatval($rw['philhealth']);
		$date_hired=date_create($rw['date_hired']);
    	$date_hired=date_format($date_hired,'M d, Y');
		$arr['date_hired']=$date_hired;
		$arr['total_rate'] = floatval($rw['total_rate']);
		array_push($myArr['data'], $arr);
	}
	exit(json_encode($myArr));
?>