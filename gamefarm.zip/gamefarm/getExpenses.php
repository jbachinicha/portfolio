<?php
	include 'session.php';
	include 'getDate.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());
	$a=json_decode(file_get_contents('php://input'),true);
	$filter=$a['filter'];
	$sql;
	switch ($filter) {
		case 'History':
			$sql="SELECT * FROM expenses ORDER BY date DESC";
			break;
		case "Today's":
			$sql="SELECT * FROM (SELECT name,type,SUM(price) as total,DAY(date) AS day, MONTH(date) as month, YEAR(date) as year FROM expenses GROUP BY name, type, day, month, year) a WHERE a.day=DAY(CURDATE()) AND a.month=MONTH(CURDATE()) AND a.year=YEAR(CURDATE())";
			break;
		case "This Week's":
			$myArr['message']='weekly';
			$sql="SELECT * FROM (SELECT WEEK(date) AS week, YEAR(date) AS year,name,type,SUM(price) as total FROM expenses GROUP BY name, type, week, year) a WHERE a.week=WEEK(CURDATE()) AND a.year=YEAR(CURDATE())";
			break;
		case "This Month's":
			$myArr['message']='monthly';
			$sql="SELECT * FROM (SELECT name,type,SUM(price) as total,MONTH(date) as month, YEAR(date) as year FROM expenses GROUP BY name, type, month, year) a WHERE a.month=MONTH(CURDATE()) AND a.year=YEAR(CURDATE())";
			break;
		default:
			$myArr['message']='default';
			$sql="SELECT * FROM (SELECT YEAR(date) AS year,name,type,SUM(price) as total FROM expenses GROUP BY name, type, year) a WHERE a.year=YEAR(CURDATE())";
			break;
	}
	
	$r=mysqli_query($con,$sql);
	while($rw=mysqli_fetch_assoc($r)){
		$arr['name']=$rw['name'];
		$arr['type']=$rw['type'];
		if($filter==='History'){
			$arr['code']=intval($rw['id']);
			$arr['amount']=floatval($rw['price']);
			$date=gd($rw['date']);
			$arr['date']=fd($date,'M d, Y');
		}else{
			$arr['amount']=floatval($rw['total']);
		}
		array_push($myArr['data'], $arr);
	}

	exit(json_encode($myArr));
?>