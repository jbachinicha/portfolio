<?php
  echo "<div class='modal' style='display: none;'>
    <form name='addForm' action='' method='post' style='display: none;'>
      <header>
        <label>Add New Expense</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form'>
          <div class='form-header'>Expense Information</div>
          <div class='form-content'>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Type</label>
              <input type='text' name='type' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Amount</label>
              <input type='number' name='amount' step='0.01' min='0' required autocomplete>
            </div>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='add' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
    <form name='updateForm' action='' method='post' style='display: none;'>
      <header>
        <label>Update Expense Information</label>
        <span class='close-btn'>&times</span>
      </header>
      <content>
        <div class='form' style='width:100%;'>
          <div class='form-content'>
            <div class='input mb10'>
              <label>Name</label>
              <input type='text' name='name' required autocomplete autofocus>
            </div>
            <div class='input mb10'>
              <label>Type</label>
              <input type='text' name='type' required autocomplete>
            </div>
            <div class='input mb10' title='Enter a valid numerical value'>
              <label>Amount</label>
              <input type='number' name='amount' step='0.01' min='0' required autocomplete>
            </div>
            <input type='hidden' name='code'>
          </div>
        </div>
      </content>
      <div class='btn-holder'>
        <button name='update' style='width: 100%; padding: 10px 20px;font-size: 16px;'>Save</button>
      </div>
    </form>
  </div>";
?>