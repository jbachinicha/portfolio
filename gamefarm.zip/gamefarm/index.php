<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script>window.history.forward();</script>
	<style type="text/css">
		html,body{width: 100%;height: 100%;margin:0;padding:0;font-size: 12px;font-family: Arial;}
		body{
			display: block;
			background-color: white;
			overflow-x: hidden;
		}

		.text h1, .text h4 {
			color: #1a4758;
		}

		section {
			height: 90vh;
			display: grid;
			justify-content: center;
			align-content: center;
		}
		.icon {
			height: 500px;
			width: 500px;
			background-image:url('indexbg.jpg');
			background-size: 100% 100%;
			background-repeat: no-repeat;
		}
		form{

			height: auto;
			width: 500px;
			margin: 15px auto;
			display: none;
			flex-direction: column;
			border: none;
		}
		form .content{
			justify-content: center;
			background-color: white;
			width: -webkit-min-content;
			padding: 10px;
			width: 450px;
		}
		.err{text-align: center;color: red;}
		.input{display: flex;flex-direction: row;align-items: center;background-color: white;height: 25px;}
		.input label{font-weight: bold;background-color: transparent;color:black;padding:5.5px;white-space: nowrap;}
		.input input{
			border: none;
			border-bottom: 1px solid gray;
			background-color: transparent;
			outline: none;
			font-size: 12px;
			flex-grow: 1;
			flex-shrink: 1;
			min-width: 50px;
		}
		.input input[type=text],
		.input input[type=password],
		.input input[type=number]{
			padding: 5px;
		}
		.input input[type=date]{
			padding: 2.5px;
		}
		.input select{
			border: none;
			padding: 5px;
			font-size: 12px;
			outline: none;
			background-color: transparent;
			flex-grow: 1;
		}
		.bbtn{
			border: none;
			padding: 8px 16px;
			background-color: #41afa1;
			font-weight: bold;
			color: black;
			font-size: 12px;
		}
		.bbtn:hover{
			color: black;
			cursor: pointer;
		}
		.col{display: flex;flex-direction: row;}
		.row{display: flex;flex-direction: column;}
		.jc-fe{justify-content: flex-end;}
		.jc-fs{justify-content: flex-start;}
		.jc-sb{justify-content: space-between;}
		.mb10{margin-bottom: 10px;}
		.text {
			text-align: center;
		}
		button {
			border: none;
			padding: 10px;
			border-radius: 5px;
			background-color: #41afa1;
			font-size: medium;
		}
		@media(min-width: 1200px) {
			.container {
				width: 470px !important;
			}
		}
		@media(max-height: 640px) {
			h1 {
				margin-top: 0 !important;
			}
			.icon {
				height: 400px;
				width: 400px;
			}
		}
	</style>
	
</head>
<body>
	<section>
		<div class="icon"></div>
		<div class="text">
			<h1>ATAN GAMEFARM</h1>
			<h4>Sales and Inventory System</h4>
		</div>
		<button id="login">Login</button>
		<form action="" method="POST" id="form">
			<div class="container">
				<div class="content">
					<div class="input mb10">
						<input type="text" name="uname" placeholder="Enter username" required autofocus>
					</div>
					<div class="input mb10">
						<input type="password" name="pass" placeholder="Enter password" required>
					</div>
				</div>
				<?php
								if(isset($_POST['login'])){
									include 'connection.php';
									$uname=$_POST['uname'];
									$pass=$_POST['pass'];
									$r=mysqli_query($con,"SELECT * FROM login WHERE uname='$uname' AND pass='$pass'");echo mysqli_error($con);
									$nr=mysqli_num_rows($r);
									if($nr===1){
										session_start();
										$_SESSION['uname']= true;
										header('Location: pointofsales.php');
										exit();
									}else{
										echo "<div class='mb10 err'>Wrong Username or Password!</div>";
									}
								}
						?>
				<div class="col jc-fe">
					<button class="bbtn" name="login">Login</button>
				</div>
			</div>
		</form>
	</section>
	<script>
	document.getElementById('login').addEventListener("click", function() {
		document.getElementById('form').style.display = "grid";
		document.getElementById('login').style.display = "none";
	});
	</script>
</body>
</html>
<?php
  include 'getDate.php';
  include 'connection.php';
  date_default_timezone_set('Asia/Manila');
  $day=intval(date('d'));
  $today=date_create();
  $today=date_format($today,'Y-m-d');
  $startDate=date_create();
  $endDate=date_create();
  $cut_off_date=date_create();
  $new=false;

  $myArr=array();
  if($day>15){
    date_modify($startDate,'first day of this month');
    $startDate=date_format($startDate,'Y-m-d');
    date_modify($endDate,'first day of this month');
    date_modify($endDate,'+14 days');
    $endDate=date_format($endDate,'Y-m-d');
    date_modify($cut_off_date,'first day of this month');
    date_modify($cut_off_date,'+1 month');
    $cut_off_date=date_format($cut_off_date,'Y-m-d');
  }else{
    date_modify($startDate,'first day of this month');
    date_modify($startDate,'-1 month');
    date_modify($startDate,'+15 days');
    $startDate=date_format($startDate,'Y-m-d');
    date_modify($endDate,'first day of this month');
    date_modify($endDate,'+14 days');
    date_modify($endDate,'-1 month');
    date_modify($endDate,'last day of this month');
    $endDate=date_format($endDate,'Y-m-d');
    date_modify($cut_off_date,'first day of this month');
    date_modify($cut_off_date,'+15 days');
    $cut_off_date=date_format($cut_off_date,'Y-m-d');
  }
  $r=mysqli_query($con,"SELECT MAX(payroll_id) as pid FROM payroll");
  $rw=mysqli_fetch_assoc($r);
  $payroll_id=$rw['pid']===NULL?1:intval($rw['pid'])+1;

  $temp_arr=array();
  $temp_total=0;
  $r=mysqli_query($con,"SELECT * FROM employees WHERE hours_worked>0 AND payroll_cut_off <= '$today'");
  while($rw=mysqli_fetch_assoc($r)){
    $arr['id_num']=floatval($rw['id_num']);
    $arr['position']=$rw['position'];
    $arr['name']=$rw['name'];
    $arr['hourly_rate']=floatval($rw['hourly_rate']);
    $arr['hours_worked']=floatval($rw['hours_worked']);
    $arr['cash_advance']=floatval($rw['cash_advance']);
    $arr['sss']=(floatval($rw['sss'])/2);
    $arr['pagibig']=(floatval($rw['pagibig'])/2);
    $arr['philhealth']=(floatval($rw['philhealth'])/2);
    $arr['gross_salary']=$arr['hourly_rate']*$arr['hours_worked'];
    $arr['deductions']=$arr['cash_advance']+$arr['sss']+$arr['philhealth']+$arr['pagibig'];
    $arr['net_salary']=$arr['gross_salary']-$arr['deductions'];
    $temp_total+=$arr['net_salary'];
    array_push($temp_arr, $arr);
  }
  if(count($temp_arr)>0){
    mysqli_query($con,"BEGIN");//start transaction
    $flag=false;
    for($x=0;$x<count($temp_arr);$x++){
      $id_num=$temp_arr[$x]['id_num'];
      $position=$temp_arr[$x]['position'];
      $name=$temp_arr[$x]['name'];
      $hourly_rate=$temp_arr[$x]['hourly_rate'];
      $hours_worked=$temp_arr[$x]['hours_worked'];
      $cash_advance=$temp_arr[$x]['cash_advance'];
      $sss=$temp_arr[$x]['sss'];
      $pagibig=$temp_arr[$x]['pagibig'];
      $philhealth=$temp_arr[$x]['philhealth'];
      $gross_salary=$temp_arr[$x]['gross_salary'];
      $deductions=$temp_arr[$x]['deductions'];
      $net_salary=$temp_arr[$x]['net_salary'];

      $r=mysqli_query($con,"INSERT INTO payroll VALUES('','$payroll_id','$position','$name','$hourly_rate','$hours_worked','$gross_salary','$cash_advance','$sss','$pagibig','$philhealth','$deductions','$net_salary','$temp_total','$startDate','$endDate')");
      if($r===false){$flag=true;}
    }
    ae('Employee Salaries','Payroll',$temp_total);
    if($flag){
      mysqli_query($con,"ROLLBACK");
      echo mysqli_error($con);
    }else{
      $r=mysqli_query($con,"UPDATE employees SET hours_worked='0', cash_advance='0',payroll_cut_off='$cut_off_date'");
      if($r){
        mysqli_query($con,"COMMIT");
      }else{
        mysqli_query($con,"ROLLBACK");
        echo mysqli_error($con);
      }
    }
  }
?>