<?php
	include 'session.php';
	include 'getDate.php';
	include 'connection.php';

	$myArr=array('status'=>'','message'=>'','data'=>array());
	$a=json_decode(file_get_contents('php://input'),true);
	$filter=$a['filter'];
	$sql;
	switch ($filter) {
		case 'daily':
			$sql="SELECT * FROM (SELECT p.name,s.price,SUM(s.quantity) AS qty,SUM(s.subtotal) AS total, DAY(date) AS day, MONTH(date) as month, YEAR(date) as year FROM sales s INNER JOIN products p ON s.product_code=p.code GROUP BY s.product_code, p.name, day, month, year) a WHERE a.day=DAY(CURDATE()) AND a.month=MONTH(CURDATE()) AND a.year=YEAR(CURDATE())";
			break;
		case 'weekly':
			$sql="SELECT * FROM (SELECT p.name,s.price,SUM(s.quantity) AS qty,SUM(s.subtotal) AS total, WEEK(date) AS week FROM sales s INNER JOIN products p ON s.product_code=p.code GROUP BY s.product_code, p.name, week) a WHERE a.week=WEEK(CURDATE())";
			break;
		case 'monthly':
			$sql="SELECT * FROM (SELECT p.name,s.price,SUM(s.quantity) AS qty,SUM(s.subtotal) AS total, MONTH(date) AS month FROM sales s INNER JOIN products p ON s.product_code=p.code GROUP BY s.product_code, p.name, month) a WHERE a.month=MONTH(CURDATE())";
			break;
		default:
			$sql="SELECT * FROM (SELECT p.name,s.price,SUM(s.quantity) AS qty,SUM(s.subtotal) AS total, YEAR(date) AS year FROM sales s INNER JOIN products p ON s.product_code=p.code GROUP BY s.product_code, p.name, year) a WHERE a.year=YEAR(CURDATE())";
			break;
	}
	
	$r=mysqli_query($con,$sql);
	while($rw=mysqli_fetch_assoc($r)){
		$arr['name']=$rw['name'];
		$arr['price']=floatval($rw['price']);
		$arr['qty']=intval($rw['qty']);
		$arr['total']=floatval($rw['total']);
		array_push($myArr['data'], $arr);
	}

	exit(json_encode($myArr));
?>