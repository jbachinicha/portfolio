<?php
	include 'session.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sales</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="app">
		<?php include 'pagemenus.php' ?>
		<div class="pagebody">
			<div class="search jc-sb no-print">
				<div class="col ai-c">
					<button class='mr10' id="latestBtn">Daily</button>
					<button class='mr10' id="weeklyBtn">Weekly</button>
					<button class='mr10' id="monthlyBtn">Monthly</button>
					<button class='mr10' id="yearlyBtn">Yearly</button>
					<button class='mr10' id="printpage">Print</button>
				</div>
				<div class="input">
					<label>Search Sales</label>
					<input type="text" id="searchTxt" style="width: 300px;">
				</div>
			</div>
			<div class="table-wrapper">
				<div id="myTable1"></div>
				<div id="myTable2"></div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src='js/jquery3-3-1.js'></script>
	<script type="text/javascript" src='js/jqueryDataTable.js'></script>
	<script type="text/javascript">
		var activeTab='Sales';
		$('.nav-title p').html('Sales');
		$('.nav-links a').each(function(){
			$(this).removeClass('active');
			if($(this).html().indexOf(activeTab)>=0){$(this).addClass('active');}
		});
		$('#printpage').on('click',function(){window.print();});
		$('#openDialogNew').on('click',function(){m.show('addForm');});
		var data;
		function get(a){
			data=$('#myTable1').DataTable({
				tableLabel:
					`<div style='margin-bottom:10px'>`+a.substr(0,1).toUpperCase()+a.substr(1).toLowerCase()+` Sales Report</div>
					<div style='margin-bottom:10px'>Total Sales: <span id='wetwew'></span></div>
				`,
				filterSelector:'#searchTxt',
				getLink:'getSales.php',
				requestData:{filter:a},
				dataProperties:[
					{label:'Name',name:'name'},
					{label:'Price',name:'price',format:'cur'},
					{label:'Quantity',name:'qty',format:'wnum'},
					{label:'Total',name:'total',format:'cur',sumID:'wetwew'},
				],
				sumColumns:[
					{name:'total',id:'wetwew'}
				],
			});
		}

		$('#latestBtn').on('click',function(){
			get('daily');
			$('.search button').removeClass('active');
			$(this).addClass('active');
		});

		$("#weeklyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get('weekly');
		});
		$("#monthlyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get('monthly');
		});
		$("#yearlyBtn").on('click',function(){
			$('.search button').removeClass('active');
			$(this).addClass('active');
			get('yearly');
		});
		$('#latestBtn').trigger('click');
	</script>
</body>
</html>