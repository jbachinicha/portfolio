<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<script type="application/x-javascript"> 
	addEventListener("load", function() { 
		setTimeout(hideURLbar, 0); 
	}, false); 

	function hideURLbar(){ 
		window.scrollTo(0,1); 
	} 
</script>
<script type="text/javascript">
function idleTimer() {
    var t;
    window.onload = resetTimer;
    window.onmousemove = resetTimer; // catches mouse movements
    window.onmousedown = resetTimer; // catches mouse movements
    window.onclick = resetTimer;     // catches mouse clicks
    window.onscroll = resetTimer;    // catches scrolling
    window.onkeypress = resetTimer;  //catches keyboard actions

    function logout() {
        window.location.href = 'lock_screen.php';  //Adapt to actual logout script
    }

   function reload() {
          window.location = self.location.href;  //Reloads the current page
   }

   function resetTimer() {
        clearTimeout(t);
        t = setTimeout(logout, 1800000);  // time is in milliseconds (1000 is 1 second)
        t= setTimeout(reload, 300000);  // time is in milliseconds (1000 is 1 second)
    }
}
idleTimer();
</script>

<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-2.1.4.min.js"></script>
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<link href="assets/css/style.css" rel="stylesheet">

<script src="js/Chart.bundle.js"></script>
<script src="js/utils.js"></script>
</head> 
<body>

   <div class="page-container">
   	<header class="logo1 col-lg-12" style="position: fixed; z-index: 99999999999; border-bottom:3px solid #09b1a1">
						<div class="row">
							<div style="float: left; position: fixed; padding: 20px;">
								<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span></a> <span class="web-name">Jinska Water</span>
							</div>

							<div class="profile_details w3l" style="float: right;">
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/randz.jpg" alt=""> </span>
												<div class="user-name">
													<p><?php require'account.php'; echo $name;?></p>
													<span><?php require'account.php'; echo $type;?></span>
												</div>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="profile.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-sign-out"></i> Logout</a> </li>
											<li> <a href="lock_screen.php"><i class="fa fa-lock"></i> Lock</a> </li>
										</ul>
									</li>
								</ul>
							</div>
						</div>
					</header>
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 999999999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Logout</h4>
                  </div>
                  <div class="modal-body">
                    Are you sure you want to Logout?
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <a href="logout.php"><button type="button" class="btn btn-primary">Logout</button></a>
                  </div>
                </div>
              </div>
            </div> 

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Profile</li>
    </ol>
	

</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
                           	<br><br><br><br><br>
									<ul id="menu" >
										<li>
											<a href="home.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a>
										</li>
										
										
										<li id="menu-academico" >
										 	<a href="daily.php"><i class="fa fa-bar-chart-o nav_icon"></i><span>Sales</span><div class="clearfix"></div></a>
										</li>

										<li>
											<a href="inventory.php"><i class="fa fa-table" aria-hidden="true"></i><span>Inventory</span><div class="clearfix"></div></a>
										</li>

										<li id="menu-academico" >
											<a href="#"><i class="fa fa-car"></i><span>Delivery</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul id="menu-academico-sub" >
										   		<li id="menu-academico-avaliacoes" ><a href="records.php">Records</a></li>
												<li id="menu-academico-avaliacoes" ><a href="pending.php">Pending</a></li>
										  	</ul>
										</li>

										<li id="menu-academico" >
											<a href="#"><i class="fa fa-money" aria-hidden="true"></i><span> Payments</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   	<ul id="menu-academico-sub" >
										   		<li id="menu-academico-avaliacoes" ><a href="collection.php">Collection Reports</a></li>
												<li id="menu-academico-avaliacoes" ><a href="recievable.php">Accounts Recievable</a></li>
										  	</ul>
										</li>

										<li id="menu-academico" >
											<a href="#"><i class="fa fa-book" aria-hidden="true"></i><span>Customer</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul id="menu-academico-sub" >
										   		<li id="menu-academico-avaliacoes" ><a href="manage_customer.php">Manage Customer</a></li>
												<li id="menu-academico-avaliacoes" ><a href="add_customer.php">Add Customer</a></li>
										  	</ul>
										</li>

									  	<li id="menu-academico">
									  		<a href="#"><i class="fa fa-group" aria-hidden="true"></i><span> Employee</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   	<ul id="menu-academico-sub" >
										   		<li id="menu-academico-avaliacoes" ><a href="manage_employee.php">Manage Employee</a></li>
												<li id="menu-academico-avaliacoes" ><a href="add_employee.php">Add Employee</a></li>
										  	</ul>
										</li>

									 	<li>
									 		<a href="calendar.php"><i class="fa fa-calendar"></i>  <span>Calendar</span><div class="clearfix"></div></a>
									 	</li>

										<li>
											<a href="gallery.php"><i class="fa fa-picture-o" aria-hidden="true"></i>  <span>Gallery</span><div class="clearfix"></div></a>
										</li>
										<li>
											<a href="log.php"><i class="fa fa-external-link" aria-hidden="true"></i>  <span>Logs</span><div class="clearfix"></div></a>
										</li>

										<li>
											<a href="settings.php"><i class="fa fa-cogs" aria-hidden="true"></i>  <span>Settings</span><div class="clearfix"></div></a>
										</li>
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>	
							  <footer class="site-footer">
          <div class="text-right">
              &#169; Copyright 2017 SCCPub, Inc. | Powered by <a>Randz PC</a> &nbsp;&nbsp;
          </div>
      </footer>	
							</div>

							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/raphael-min.js"></script>


</body>
</html>