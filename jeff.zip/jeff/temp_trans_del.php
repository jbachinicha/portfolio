<?php
	require_once 'connect.php';
$id=$_GET['id'];
$result=mysqli_query($conn,"DELETE FROM temp_trans WHERE temp_trans_id ='$id'")
	or die(mysqli_error());

?>