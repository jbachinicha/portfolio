<?php

include 'config.php';

	
try
{
	$cat = $_POST['get_prices'];
	
	//connect to database
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	//select data from db
	$stmt = $conn->prepare("SELECT DISTINCT market_price FROM inventory WHERE prod_id = '$cat' ");
	
	//execute the sql query
	$stmt->execute();
	//use php function fetch() to get the db column data
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
	{
        //use the fetched data to store into variable
		$price = number_format($row['market_price'],2);
		
		echo "
			<input type='number' name='gallprice' value='$price' class='form-control' required>
		";
	}
	
	exit;
	
	
}	
catch (PDOException $e)
{
	echo "Connection failed: " . $e->getMessage();
}

//close conection
$conn = null;


?>