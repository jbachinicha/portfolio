<?php
	require_once 'connect.php';
$id = $_REQUEST['id'];
$cid = $_POST['cid'];
$result=mysqli_query($conn,"DELETE FROM temp_trans WHERE temp_trans_id ='$id'")
	or die(mysqli_error());
	
echo "<script>document.location='cash_transaction.php?cid=$cid'</script>";  
?>