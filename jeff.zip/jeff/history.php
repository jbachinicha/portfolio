<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('logs').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> User Logs <i class="fa fa-angle-right"></i> History Logs</li>
    </ol>

    <div class = "col-lg-12 well breadcrumb" style = "margin-top:20px;">
    				<a class="btn btn-danger" href="log.php" style="color:#fff;"><i class="fa fa-arrow-left" style="color: #fff"></i> Back</a>
					<h3>History Logs</h3>
					<br />
					<br />
					<div id = "admin_table">
						<table id="table2" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Log</th>
                      </tr>
                    </thead>
                    <tbody>
							<?php
								$query=mysqli_query($conn,"SELECT * FROM history_log natural join admin WHERE user_id = admin_id ORDER BY date")or die(mysqli_error());
								while($row=mysqli_fetch_array($query)){
		
						?>
                      <tr>
                      <td>	<?php echo $row['firstname']." ".$row['lastname']." ".$row['action']." last ".$row['date'];?></td>
                       
                      </tr>
				   	  		<?php }?>					  
                    </tbody>
                  </table>
<?php include('modal/log_modal.php'); ?>
					</div>

			</div>

</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#table1").DataTable();
        $("#table2").DataTable();
        $("#table3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>


</body>
</html>