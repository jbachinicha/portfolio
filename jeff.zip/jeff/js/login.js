$(document).ready(function(){
	$error = $('<center><label class = "text-danger">Please fill up the form</label></center>');
	$error1 = $('<center><label class = "text-danger">Invalid username or password</label></center>');
	$loading = $('<center><div id="animationProgress" class="progress progress-striped active" style="width: 87%"><div class="progress-bar"  role="progressbar" aria-valuenow="100" aria-valuemin="100" aria-valuemax="100" style="width: 100%"></div></div></center>');
	$('#login').click(function(){
		$error.remove();
		$error1.remove();
		$('#username').focus(function(){	
			$('#username_warning').each(function(){
				$(this).removeClass('has-error has-feedback');
				$(this).find('span').remove();
			});
		});	
		$('#password').focus(function(){	
			$('#password_warning').each(function(){
				$(this).removeClass('has-error has-feedback');
				$(this).find('span').remove();
			});
		});	
		$username = $('#username').val();
		$password = $('#password').val();
		if($username == "" && $password == ""){
			$error.appendTo('#result');
			$('#username_warning').addClass('has-error has-feedback');
			$('<span class = "glyphicon glyphicon-remove form-control-feedback x"></span>').appendTo('#username_warning');
			$('#password_warning').addClass('has-error has-feedback');
			$('<span class = "glyphicon glyphicon-remove form-control-feedback x"></span>').appendTo('#password_warning');
		}else{
			$loading.appendTo('#result');
			setTimeout(function(){	
				$.post('check_admin.php', {username: $username, password: $password},
					function(result){
						if(result == 'Success'){
							window.location  = 'check.php';
						}else{
							$loading.remove();
							$error1.appendTo('#result');
						}
					}
				)
			}, 3000);	
		}
	});
});