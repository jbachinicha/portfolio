<?php
	require_once 'connect.php';
	include('valid.php');

	$name = $_REQUEST['name'];
	$query = mysqli_query($conn,"SELECT * FROM customer where cust_first = '$name' ");
	while ($row = mysqli_fetch_array($query)) {
		$cid = $row['cust_id'];
		$t='0';
		header("location: cash_transaction_deliver.php?cid=$cid&trans_id=$t");
	}

?>