<?php
 include 'connect.php';
 include('valid.php');
 $pos = $_POST['pos'];
 $rate = $_POST['rate'];
 $id = $_SESSION['admin_id'];
 $date = date("Y-m-d H:i:s");
 $remarks="added $pos as new position";

 if (isset($_POST['add'])) {

 	mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));
 	mysqli_query($conn, "INSERT INTO position VALUES('','$pos','$rate')")or die(mysqli_error($conn));
 	header("location: manage_employee.php"); 
 }


?>