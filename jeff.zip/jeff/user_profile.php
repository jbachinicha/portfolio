<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<style>
	td{
		padding: 15px;
	}
</style>
</head> 
<body>

   <div class="page-container">
    <?php include('include/cashier_header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="daily.php">Home</a> <i class="fa fa-angle-right"></i> Profile</li>
    </ol>


    <?php
    include('connect.php');
    $q = mysqli_query($conn, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]' ");
    while ($row = mysqli_fetch_assoc($q)) { 
    	$first = $row['firstname'];
    	$last = $row['lastname'];
    	$middle = $row['middlename'];
    	$gender = $row['gender'];
    	$address = $row['address'];
    	$phone = $row['phone'];
    	$username = $row['username'];
    	$password = $row['password'];
    	$pict = $row['pict'];
    	$type = $row['type'];
    	?>

          <section class="content breadcrumb well">
          	<h1 class="page-header">Profile</h1>
            <a href="cash_transaction.php" class="btn btn-danger">BACK</a>
            <div class="row">
	      <div class="col-md-3">
              <div class="box box-primary">
                <div class="box-body bord">
                  <center>
				    <img class = "profile_pic" src = "dist/uploads/<?php echo $row['pict'];?>"><br><br>
          </center>
				    <span><?php echo $type ?></span>
                </div>
              </div>
            </div>
            
            <div class="col-xs-9">
            	<div class='table-responsive'>
	                	<center>
		                	<table class="table table-bordered table-hover table-striped" style="padding: 10px;">
		                		<tr>
		                			<td>First Name:</td>
		                			<td><?php echo $first ?></td>
		                		</tr>
		                		<tr>
		                			<td>Middle Name:</td>
		                			<td><?php echo $middle ?></td>
		                		</tr>
		                		<tr>
		                			<td>Last Name:</td>
		                			<td><?php echo $last ?></td>
		                		</tr>
		                		<tr>
		                			<td>Gender:</td>
		                			<td><?php echo $gender ?></td>
		                		</tr>
		                		<tr>
		                			<td>Address:</td>
		                			<td><?php echo $address ?></td>
		                		</tr>
		                		<tr>
		                			<td>Phone Number:</td>
		                			<td><?php echo $phone ?></td>
		                		</tr>
		                		<tr>
		                			<td>Username:</td>
		                			<td><?php echo $username ?></td>
		                		</tr>
		                		<tr>
		                			<td>Password:</td>
		                			<td>************</td>
		                		</tr>
		                	</table>
	                	</center>
	                </div>
            </div>

            <center>
            	<a class="btn btn-theme" href="#add" data-toggle="modal" data-target="#stock" style="color:#fff; margin-top: 50px;"><i class="glyphicon glyphicon-edit text-blue" style="color: #fff"></i> Update</a>
        	</center>

        	<div class="modal fade" id="stock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999; margin-top: 100px;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Update Profile</h4>
                  </div>
                  <div class="modal-body">
                   	<form method="post" action="profile_update.php" enctype='multipart/form-data' name="add_stock" novalidate="">
                   		<div class="form-group">
                  <label>First Name:</label>
                    <input type="text" class = "form-control" name="firstname" value="<?php echo $first ?>" required>
                </div>

                <div class="form-group">
                  <label>Middle Name:</label>
                  <input type = "text" name = "middlename" value="<?php echo $middle ?>" class = "form-control" />
                </div>

                <div class="form-group">
                  <label>Last Name:</label>
                    <input type="text" class = "form-control" name="lastname" value="<?php echo $last ?>" required>
                </div>

                <div class="form-group">
                  <label>Gender:</label>
                  <select class="form-control" name="gender">
                  	<option>Male</option>
                  	<option>Female</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Address:</label>
                  <input type="text" class = "form-control" name="address" value="<?php echo $address ?>" required>
                </div>

                <div class="form-group">
                  <label>Phone Number:</label>
                  <input type="number" class = "form-control" name="phone" value="<?php echo $phone ?>">
                </div>

                <div class="form-group">
                  <label>Username:</label>
                  <input type="text" class = "form-control" name="username" value="<?php echo $username ?>">
                </div>

                <div class="form-group">
                  <label>Password:</label>
                  <input type="password" class = "form-control" name="password" value="<?php echo $password ?>">
                </div>


					<div class="form-group col-xs-3">
						<label>Picture:</label>
						<img src="dist/uploads/<?php echo $pict?>" height="100px" width="100px" id="pic" style="border: solid white 2px;">
					</div>
					<div class="form-group col-xs-9">
					  <input type="hidden" class="form-control" id="price" name="image1" value="<?php echo $pict ?>">
					  <input type ="file" class="form-control" name="image" onchange="document.getElementById('pic').src=window.URL.createObjectURL(this.files[0])" /> 
						
					</div>

        				<div class="form-group modal-footer">
                   			 <button type="submit" name="submit" class="btn btn-theme">Update</button>
                		</div>
                   	</form>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- /.row -->
	  
            
          </section>




  	<?php
    }


    ?>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/cashier_footer.php');?></div>
</body>
</html>