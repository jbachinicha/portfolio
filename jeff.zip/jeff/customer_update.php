<?php
include('connect.php');
include('valid.php');

	$aid = $_SESSION['admin_id'];
	$date = date("Y-m-d H:i:s");

	$query=mysqli_query($conn,"SELECT * FROM customer WHERE `cust_id` = '$id'")or die(mysqli_error());
  
    $row=mysqli_fetch_array($query);
	$name=$row['cust_first'];
	$remarks="updated $name information";  

	$id =$_POST['id'];
	$last =$_POST['last'];
	$first =$_POST['first'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$status = $_POST['status'];
	
	$pic = $_FILES["image"]["name"];
			if ($pic=="")
			{	
				if ($_POST['image1']<>""){
					$pic=$_POST['image1'];
				}
				else
					$pic="default.gif";
			}
			else
			{
				$pic = $_FILES["image"]["name"];
				$type = $_FILES["image"]["type"];
				$size = $_FILES["image"]["size"];
				$temp = $_FILES["image"]["tmp_name"];
				$error = $_FILES["image"]["error"];
			
				if ($error > 0){
					die("Error uploading file! Code $error.");
					}
				else{
					if($size > 100000000000) //conditions for the file
						{
						die("Format is not allowed or file size is too big!");
						}
				else
				      {
					move_uploaded_file($temp, "dist/uploads/".$pic);
				      }
					}
			
			}
	mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$aid','$remarks','$date')")or die(mysqli_error($conn));
	mysqli_query($conn,"update customer set cust_last='$last',cust_first='$first',cust_address='$address',cust_contact='$contact',cust_pic='$pic',credit_status='$status' where cust_id='$id'")or die(mysqli_error($conn));
	
	header("location: manage_customer.php"); 

	
?>
