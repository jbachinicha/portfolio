<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app">
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('cashAdvance').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
<script src="js/angular.min.js"></script>
<style type="text/css">
      .errortext{
        color:red;
      }
    </style>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Cash Advance </li>
    </ol>


			<div class = "col-lg-12 well breadcrumb" style = "margin-top:60px;">
					
          <button type="button" data-toggle="modal" data-target="#cash" class="btn btn-theme"><span class="fa fa-plus"></span> New</button>
					<!--a class="btn btn-theme" href="#deduc" data-toggle="modal" data-target="#deduc" style="color:#fff;"><i class="glyphicon glyphicon-minus text-blue" style="color: #fff"></i> Deductions</a-->
					
					<div id = "admin_table">
						<div class="alert">
							
						</div>
						<table id = "example1" class = "table table-bordered">
							<thead class = "alert">
								<tr>
									<th>Employee Id</th>
									<th>Firstname</th>
									<th>Lastname</th>
									<th>Date</th>
									<th>Amount</th>
                  <th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php
								$q_admin = $conn->query("SELECT * FROM employee e JOIN cashadvance c WHERE e.status='Hired' AND e.id=c.emp_id ") or die(mysqli_error());
								while($f_admin = $q_admin->fetch_array()){
                  $stat=$f_admin['cash_status'];
                  if ($stat=='Not Paid') { 
                    $cstatus='<label style="color: red;">Not Paid</label>';
                  }
                  else{ 
                    $cstatus='<label style="color: #000;">Paid</label>';
                  }
									
							?>	
								<tr class = "target table-row">
									<td value = "<?php echo $f_admin['emp_id']?>"><?php echo $f_admin['employee_id']?></td>
									<td value = "<?php echo $f_admin['emp_id']?>"><?php echo ($f_admin['first_name'])?></td>
									<td value = "<?php echo $f_admin['emp_id']?>"><?php echo $f_admin['last_name']?></td>
									<td value = "<?php echo $f_admin['emp_id']?>"><?php echo $f_admin['date_advance']?></td>
									<td value = "<?php echo $f_admin['emp_id']?>"><?php echo $f_admin['amount']?></td>
                  <td value = "<?php echo $f_admin['emp_id']?>"><?php echo $cstatus?></td>
									<td width="10%">
										<center>
                    <a href = "#" class = "btn btn-success eadmin_id " value = "<?php echo $f_admin['emp_id']?>"><span class = "fa fa-edit" style="width: 36px;"></span>Update</a>
										<a href = "#" class = "btn btn-danger deladmin_id " value = "<?php echo $f_admin['emp_id']?>"><span class = "fa fa-close" style="width: 36px;"></span>Remove</a>
									</center>
										
									</td>
								</tr>
							<?php
								}
							?>	
							</tbody>
						</table>
					</div>
          <div id="edit_form">
              
            </div>
          <div id="account_form">
              
            </div>
              <div id="cash" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center" style="color: white;"><b>Cash Advance</b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">

              <form class="form-horizontal" action="cashadvance_add.php" name="form" method="post">
                <div class="form-group">
                  <label class="col-sm-4 control-label">Employee ID</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" id="employee" name="employee" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">Amount</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" id="amount" name="amount" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-8">
                    <input type="submit" name="add" class="btn btn-theme" value="Submit">
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
			</div>
</div>
<script>
  var app = angular.module('app', []);
app.controller('myController', function($scope){
  $scope.valid = false;
  $scope.submit = function(){
    $scope.valid = true;
  }
  $scope.close = function(){
    $scope.valid = false;
  }
});
</script>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $("#example5").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    <!--script type = "text/javascript">
    $(document).ready(function(){
      $result = $('<center><label>Deleting...</label></center>');
      $('.deladmin_id').click(function(){
        $admin_id = $(this).attr('value');
        $(this).parents('td').empty().append($result);
        $('.deladmin_id').attr('disabled', 'disabled');
        $('.eadmin_id').attr('disabled', 'disabled');
        setTimeout(function(){
          window.location = 'delete_employee.php?employee_id=' + $admin_id;
        }, 1000);
      });
      $('.eadmin_id').click(function(){
        $admin_id = $(this).attr('value');
        $('#show_admin').show();
        $('#show_admin').click(function(){
          $(this).hide();
          $('#edit_form').empty();
          $('#admin_table').show();
          $('#add_admin').show();
        });
        $('#admin_table').fadeOut();
        $('#add_admin').hide();
        $('#edit_form').load('load_employee.php?employee_id=' + $admin_id);
      });
      $('.aadmin_id').click(function(){
        $admin_id = $(this).attr('value');
        $('#show_admin').show();
        $('#show_admin').click(function(){
          $(this).hide();
          $('#edit_form').empty();
          $('#admin_table').show();
          $('#add_admin').show();
        });
        $('#admin_table').fadeOut();
        $('#add_admin').hide();
        $('#account_form').load('load_account.php?employee_id=' + $admin_id);
      });
    });
  </script-->

</body>
</html>