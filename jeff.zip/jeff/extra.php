<?php

include 'connect.php';

$query = mysqli_query($conn, "SELECT * FROM sales s JOIN sales_details sd JOIN inventory i JOIN customer c JOIN admin a WHERE s.date_added=CURDATE() AND s.sales_id=sd.sales_id AND sd.prod_id=i.prod_id AND s.cust_id=c.cust_id AND s.admin_id=a.admin_id ");
while ($row = mysqli_fetch_assoc($query)) { 
		$name = $row['cust_first']." ".$row['cust_last'];
		$product_name = $row['product'];
		$item = $row['prod_name'];
		$price = $row['price'];
		$ct = $row['cash_tendered'];
		$cc = $row['cash_change'];
		$ad = $row['amount_due'];
		$mop = $row['modeofpayment'];
		$cashier = $row['firstname']." ".$row['lastname'];
		$qty = $row['qty'];
		$total = $row['total']; 
		$i=1;

	echo "<table class='table table-bordered table-hover table-striped'>
		<tr>
			<th>No.</th>
			<th>Customer Name</th>
			<th>Product</th>
			<th>Item</th>
			<th>Price</th>
			<th>Cash Tendered</th>
			<th>Cash Change</th>
			<th>Amount Due</th>
			<th>Mode of Payment</th>
			<th>Cashier</th>
			<th>Quantity</th>
			<th>Total</th>
		</tr>
		<tr>
			<td><?php echo $i++; ?></td>
			<td><?php echo '$name'; ?></td>
			<td><?php echo '$product_name'; ?></td>
			<td><?php echo '$item'; ?></td>
			<td><?php echo '$price'; ?></td>
			<td><?php echo '$ct'; ?></td>
			<td><?php echo '$cc'; ?></td>
			<td><?php echo '$ad'; ?></td>
			<td><?php echo '$mop'; ?></td>
			<td><?php echo '$cashier'; ?></td>
			<td><?php echo '$qty'; ?></td>
			<td><?php echo '$total'; ?></td>
		</tr>";
} 

$q = mysqli_query($conn, "SELECT SUM(total) AS TOTALSALES, SUM(qty) AS TOTALQUANTITY FROM SALES WHERE date_added=CURDATE()");
$row = mysqli_fetch_assoc($q);
	$totalprice = $row['TOTALSALES'];
	$totalquantity = $row['TOTALQUANTITY'];

	echo "<tr>
	<td  colspan='8'></td>
	<th>Total</th>
	<th>$totalquantity</th>
	<th>$totalprice</th>
	</tr>
	
	</table>";

?>

var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                      var color = Chart.helpers.color;
                      var horizontalBarChartData = {
                        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        datasets: [{
                          label: 'Sales',
                          backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                          borderColor: window.chartColors.blue,
                          borderWidth: 1,
                          data: [$jan,$feb,$mar,$apr,$may,$jun,$jul,$aug,$sep,$oct,$nov,$dec]
                        }]
                      };

                      window.onload = function() {
                        var ctx = document.getElementById("canvas").getContext("2d");
                        window.myHorizontalBar = new Chart(ctx, {
                          type: 'horizontalBar',
                          data: horizontalBarChartData,
                          options: {
                              elements: {
                                  rectangle: {
                                      borderWidth: 2,
                                  }
                              },
                              responsive: true,
                              legend: {
                                  position: 'top',
                              },
                              title: {
                                  display: false,
                                  text: 'Chart.js Horizontal Bar Chart'
                              }
                          }
                        });
                      };