<?php
	include 'connect.php';


		$employee = $_POST['employee'];
		$amount = $_POST['amount'];

		include('valid.php');
$ids = $_SESSION['admin_id'];
 $date = date("Y-m-d H:i:s");

		
		$query = mysqli_query($conn, "SELECT * FROM employee WHERE employee_id = '$employee'")or die(mysqli_error($conn));
		$row = mysqli_fetch_array($query);
		$employee_id = $row['id'];
		$name = $row['first_name'];
		 $remarks="permit $name for cash advance";
		$r = mysqli_num_rows($query);
		if ($r == 0) {
			echo "<script>alert('Employee Not Found!');window.location.href='cash_advance.php'</script>";
		}
		else{

			mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$ids','$remarks','$date')")or die(mysqli_error($conn));
			mysqli_query($conn, "INSERT INTO cashadvance (emp_id, date_advance, amount, cash_status) VALUES ('$employee_id', NOW(), '$amount','Not Paid')")or die(mysqli_error($conn));
			header("location: cash_advance.php");
		}
?>