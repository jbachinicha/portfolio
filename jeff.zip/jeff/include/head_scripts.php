<script type="text/javascript">
  function idleTimer() {
    var t;
    window.onload = resetTimer;
    window.onmousemove = resetTimer; 
    window.onmousedown = resetTimer; 
    window.onclick = resetTimer;
    window.onscroll = resetTimer;  
    window.onkeypress = resetTimer;

    function logout() {
        window.location.href = 'lock_screen.php';
    }

   function reload() {
          window.location = self.location.href;
   }

   function resetTimer() {
        clearTimeout(t);
        t = setTimeout(logout, 600000);
        t = setTimeout(reload, 300000);
    }
  }
  idleTimer();
</script>

<link rel="stylesheet" type="text/css" href="css/notes.css">

<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />

<link href="css/style.css" rel='stylesheet' type='text/css' />

<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-2.1.4.min.js"></script>

<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<link href="css/style1.css" rel="stylesheet">

<script src="js/Chart.bundle.js"></script>
<script src="js/utils.js"></script>

<link rel="stylesheet" type="text/css" href="datatables/dataTables.bootstrap.css">
    <style>
      .low{
        color: red;
      }
    </style>
