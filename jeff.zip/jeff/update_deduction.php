<?php
 include 'connect.php';
 $pos = $_POST['pos'];
 $id = $_POST['id'];
 $rate = $_POST['amount'];

   include('valid.php');
$ids = $_SESSION['admin_id'];
 $date = date("Y-m-d H:i:s");
 $remarks="updated $pos info";

 if (isset($_POST['up'])) {

 	mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$ids','$remarks','$date')")or die(mysqli_error($conn));
 	mysqli_query($conn, "UPDATE deductions SET description='$pos', amount='$rate' WHERE id='$id'")or die(mysqli_error($conn));
 	header("location: manage_employee_payroll.php"); 
 }


?>