<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app" id="html">
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('attend').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
<script src="js/angular.min.js"></script>
<style type="text/css">
      .errortext{
        color:red;
      }
    </style>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Employee <i class="fa fa-angle-right"></i> Attendance </li>
    </ol>
    <div class="alert alert-success alert-dismissible" style="display:none;">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <span class="result"><i class="icon fa fa-check"></i> <span class="message"></span></span>
    </div>
    <div class="alert alert-danger alert-dismissible" style="display:none;">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <span class="result"><i class="icon fa fa-warning"></i> <span class="message"></span></span>
    </div>


			<div class = "col-lg-12 well breadcrumb">
					<div id = "admin_table">
						<div>

							<div class="row" >
                <div class="col-xs-4">
    <div class="login-logo">
      <p id="date"></p>
      <p id="time" class="bold"></p>
    </div>
  

    <div class="login-box-body">
      <h4 class="login-box-msg">Enter Employee ID</h4>

      <form id="attendance" >
          <div class="form-group">
            <select class="form-control" name="status">
              <option value="in">Time In</option>
              <option value="out">Time Out</option>
            </select>
          </div>
          <div class="form-group has-feedback">
            <input type="text" class="form-control input-lg" name="employee" style="background-color: #fff;" required autocomplete="off">
            <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
          </div>
          <div class="row">
          <div class="col-xs-4">
                <button type="submit" class="btn btn-theme" name="signin"><i class="fa fa-sign-in"></i> Time</button>
            </div>
          </div>
      </form>
    </div>
      
</div>
<div class="col-xs-8">
  <h2>Attendance List</h2>
  <table id="example1" class="table table-bordered">
                <thead>
                  <th class="hidden"></th>
                  <th>Date</th>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Time In</th>
                  <th>Time Out</th>
                  <th>Remarks</th>
                </thead>
                <tbody>
                  <?php
                    $sql = "SELECT *, employee.employee_id AS empid, attendance.id AS attid, attendance.status AS st FROM attendance LEFT JOIN employee ON employee.id=attendance.employee_id WHERE employee.status='Hired' ORDER BY attendance.date DESC, attendance.time_in DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
                      if ($row['st'] == 1) {
                        $status = '<span class="btn btn-success">ontime</span>';
                      }
                      else{
                        $status = '<span class="btn btn-danger">late</span>';
                      }
                      
                      echo "
                        <tr>
                          <td class='hidden'></td>
                          <td>".date('M d, Y', strtotime($row['date']))."</td>
                          <td>".$row['empid']."</td>
                          <td>".$row['first_name'].' '.$row['last_name']."</td>
                          <td>".date('h:i A', strtotime($row['time_in']))."</td>
                          <td>".date('h:i A', strtotime($row['time_out']))."</td>
                          <td>".$status."</td>
                        </tr>
                      ";
                    }
                  ?>
                </tbody>
              </table>
</div>
</div>
						</div>
						
					</div>

			</div>
</div>
<script>
  var app = angular.module('app', []);
app.controller('myController', function($scope){
  $scope.valid = false;
  $scope.submit = function(){
    $scope.valid = true;
  }
  $scope.close = function(){
    $scope.valid = false;
  }
});
</script>

  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
   <script type="text/javascript">
$(function() {

  $('#attendance').submit(function(e){
    e.preventDefault();
    var attendance = $(this).serialize();
    $.ajax({
      type: 'POST',
      url: 'attendance_save.php',
      data: attendance,
      dataType: 'json',
      success: function(response){
        if(response.error){
          $('.alert').hide();
          $('.alert-danger').show();
          $('.message').html(response.message);
        }
        else{
          $('.alert').hide();
          $('.alert-success').show();
          $('.message').html(response.message);
          $('#employee').val('');
        }
      }
    });
  });
    
});
</script>
</body>
</html>