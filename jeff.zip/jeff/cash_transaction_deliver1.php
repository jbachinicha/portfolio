<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php 
  include('include/head_scripts.php');
$trans = $_REQUEST['trans_id'];
if ($trans=='0') {
  $letters = '';
    $numbers = '';
    foreach (range('A', 'Z') as $char) {
        $letters .= $char;
    }
    for($i = 0; $i < 10; $i++){
      $numbers .= $i;
    }
    $trans_id = substr(str_shuffle($letters), 0, 3).substr(str_shuffle($numbers), 0, 9);
}
else{
  $trans_id=$trans;
}
?>
<script type="text/javascript">
function fetch_name(val)
{
   $.ajax({
     type: 'post',
     url: 'fetch_status.php',
     data: {
       get_status:val
     },
     success: function (response) {
       document.getElementById("select_status").innerHTML=response; 
     }
   });

   $.ajax({
     type: 'post',
     url: 'fetch_price2.php',
     data: {
       get_prices:val
     },
     success: function (response) {
       document.getElementById("price").innerHTML=response; 
     }
   });
}
function showPrice(val)
{
   $.ajax({
     type: 'post',
     url: 'fetch_price.php',
     data: {
       get_price:val
     },
     success: function (response) {
       document.getElementById("price").innerHTML=response; 
     }
   });
}
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/cashier_header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="cash_transaction.php">Home</a> <i class="fa fa-angle-right"></i> Sales <i class="fa fa-angle-right"></i> Transaction</li>
  </ol>

          <section class="content breadcrumb well">
            <div class="row">
        <div class="col-md-9">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">Sales Transaction</h3>
                </div>
                <div class="box-body">
                  <!-- Date range -->
                  <form method="post" action="transaction_add.php">
          <div class="row" style="min-height:400px">
          
           <div class="col-md-6">
              <div class="form-group">
              <label for="date">Container: </label>
               <input type="hidden" name="trans_id" value="<?php echo $trans_id; ?>">
                <select class="form-control select2" name="prod_name" tabindex="1" onchange="fetch_name(this.value);" autofocus required>
                  <option value="">-- Select Container --</option>
                <?php
                  $cid=$_REQUEST['cid'];
                  $cate = 'Container';
                   $query2=mysqli_query($conn,"SELECT * FROM inventory WHERE category = '$cate' ")or die(mysqli_error());
                      while($row=mysqli_fetch_array($query2)){
                ?>
                    <option value="<?php echo $row['prod_id'];?>"><?php echo $row['prod_name']." Available(".$row['prod_qty'].")";?></option>
                  <?php }?>
                </select>
                <input type="hidden" class="form-control" name="cid" value="<?php echo $cid;?>" required>   
              </div><!-- /.form group -->

              <div class="form-group">
              <label for="date">Product Name: </label>
               
                <select class="form-control select2" name="prod" tabindex="1" autofocus required>
                  <option value="">-- Select Product --</option>
                <?php
                   $query2=mysqli_query($conn,"SELECT * FROM product")or die(mysqli_error());
                      while($row=mysqli_fetch_array($query2)){
                ?>
                    <option value="<?php echo $row['prod_name'];?>"><?php echo $row['prod_name'];?></option>
                  <?php }?>
                </select> 
              </div>

          </div>

          <div class=" col-md-4">
            <div class="form-group">
              <label for="date">Quantity: </label>
              <div class="input-group">
                <input type="number" class="form-control pull-right" id="date" name="qty" placeholder="Quantity" tabindex="2" value="1"  required>
              </div>
              <label>Status: </label>
                <div class="input-group">
                <div id="select_status" class="input-group">
                
                </div> 
              </div><!-- /.input group -->
            </div><!-- /.form group -->
           </div>
          <div class="col-md-2">
            <div class="form-group">
              <label for="date"></label>
              <div class="input-group">
                <button class="btn btn-theme" type="submit" tabindex="3" name="addtocart"><span class="fa fa-plus"></span> Add</button>
              </div>
              <label>Price: </label>
                <div id="price" class="input-group">
                
                </div> 
            </div>  
          </form> 
          </div>
          <div class="col-md-12">
<?php 
$queryb=mysqli_query($conn,"select * from customer where cust_id='$cid'")or die(mysqli_error());
     $rowb=mysqli_fetch_array($queryb);
     $first = $rowb['cust_first'];
  $last = $rowb['cust_last'];
  $add = $rowb['cust_address'];

        $balance=$rowb['balance'];

        if ($balance>0) $disabled="disabled=true";else{$disabled="";}
?>
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Transaction Code</th>
                        <th>Qty</th>
                        <th>Product Name</th>
                        <th>Container</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
    
    $query=mysqli_query($conn,"select * from temp_trans natural join inventory")or die(mysqli_error());
      $grand=0;
    while($row=mysqli_fetch_array($query)){
        $id=$row['temp_trans_id'];
        $total= $row['qty']*$row['price'];
        $grand=$grand+$total;
    
?>
                      <tr >
            <td><?php echo $row['temp_trans_id'] ?></td>
            <td><?php echo $row['qty'];?></td>
            <td class="record"><?php echo $row['product'];?></td>
            <td class="record"><?php echo $row['prod_name'];?></td>
            <td><?php echo number_format($row['price'],2);?></td>
            <td><?php echo number_format($total,2);?></td>
                        <td>
              
              <a href="#updateordinance<?php echo $row['temp_trans_id'];?>" data-target="#updateordinance<?php echo $row['temp_trans_id'];?>" data-toggle="modal" style="color:#fff;" class="btn btn-success"><i class="glyphicon glyphicon-edit text-white"></i></a>

              <a href="#delete<?php echo $row['temp_trans_id'];?>" data-target="#delete<?php echo $row['temp_trans_id'];?>" data-toggle="modal" style="color:#fff;" class="btn btn-danger"><i class="glyphicon glyphicon-trash text-white"></i></a>
              
            </td>
                      </tr>
            <div id="updateordinance<?php echo $row['temp_trans_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content" style="height:auto">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update Sales Details</h4>
              </div>
              <div class="modal-body">
        <form class="form-horizontal" method="post" action="transaction_update.php" enctype='multipart/form-data'>
          <input type="hidden" class="form-control" name="cid" value="<?php echo $cid;?>" required>   
          <input type="hidden" class="form-control" id="price" name="id" value="<?php echo $row['temp_trans_id'];?>" required>  
        <div class="form-group">
          <label class="control-label col-lg-3" for="price">Qty</label>
          <div class="col-lg-9">
            <input type="text" class="form-control" id="price" name="qty" value="<?php echo $row['qty'];?>" required>  
          </div>
        </div>
        
              </div><br>
              <div class="modal-footer">
                <button type="submit" class="btn btn-theme">Save changes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
        </form>
            </div>
      
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->  
<div id="delete<?php echo $row['temp_trans_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content" style="height:auto">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Delete Item</h4>
              </div>
              <div class="modal-body">
        <form class="form-horizontal" method="post" action="transaction_del.php" enctype='multipart/form-data'>
          <input type="hidden" class="form-control" name="cid" value="<?php echo $cid;?>" required>   
          <input type="hidden" class="form-control" id="price" name="id" value="<?php echo $row['temp_trans_id'];?>" required>  
        <p>Are you sure you want to remove <?php echo $row['prod_name'];?>?</p>
        
              </div><br>
              <div class="modal-footer">
                <button type="submit" class="btn btn-danger">Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
        </form>
            </div>
      
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->  
<?php }?>           
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->

        </div>  
               
                  
                  
        </form> 
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
            
            <div class="col-md-3">
              <div class="box box-primary">
               
                <div class="box-body">
                  <!-- Date range -->
          <form method="post" name="autoSumForm" action="sales_add.php">
          <div class="row">
           <div class="col-md-12">
              
              <div class="form-group">
              <label for="date">Total</label>
                <input type="hidden" name="trans" value="<?php echo $trans_id;?>">
                <input type="text" style="text-align:right" class="form-control disabled" id="total" name="total" placeholder="Total" 
                value="<?php echo $grand;?>" onFocus="startCalc();" onBlur="stopCalc();"  tabindex="5"  readonly>
              
              </div><!-- /.form group -->
              <div class="form-group">
              <label for="date">Discount</label>
              
                <input type="text" class="form-control text-right" id="discount" name="discount" value="0" tabindex="6" placeholder="Discount (Php)" onFocus="startCalc();" onBlur="stopCalc();">
              <input type="hidden" class="form-control text-right" id="cid" name="cid" value="<?php echo $cid;?>">
              </div><!-- /.form group -->
              <div class="form-group">
              <label for="date">Amount Due</label>
              
                <input type="text" style="text-align:right" class="form-control disabled" id="amount_due" name="amount_due" placeholder="Amount Due" value="<?php echo number_format($grand,2);?>" readonly>
              
              </div><!-- /.form group -->
              
             
              <div class="form-group" id="tendered">
                <label for="date">Cash Tendered</label><br>
                <input type="text" style="text-align:right" class="form-control" onFocus="startCalc();" onBlur="stopCalc();"  id="cash" name="tendered" placeholder="Cash Tendered" value="0">
              </div><!-- /.form group -->
              <div class="form-group" id="change">
                <label for="date">Change</label><br>
                <input type="text" style="text-align:right" class="form-control" id="changed" name="change" placeholder="Change">
              </div><!-- /.form group -->
          </div>
          
          

        </div>  
               
                  

              <a class="btn btn-theme col-xs-12" id="daterange-btn" href="#deduc" data-toggle="modal" data-target="#deduc"><i class="fa fa-submit text-blue" style="color: #fff"></i> Complete Sales</a>
            <button class="btn btn-danger col-xs-12" id="daterange-btn" type="reset"  tabindex="8">
              <a href="cancel.php">Cancel Sale</a></button>
<div class="modal fade" id="deduc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999; margin-top: 100px;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Do you want to Deliver the items?</h4>
                  </div>
        <div class="modal-footer">
                <div class="form-group">
                  <input type="submit" name="yes" class="btn btn-theme" value="YES">
                  <input type="submit" name="no" class="btn btn-danger" value="NO">
                </div>
              </div>
                  </div>
                </div>
              </div>

            </div>
        </form> 
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
      
      
          </div><!-- /.row -->
    
            
          </section>



</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/cashier_footer.php');?></div>
  <script type="text/javascript" src="js/autosum.js"></script>
  <script>
  
    
      $("#cash").click(function(){
          $("#tendered").show('slow');
          $("#change").show('slow');
      });

    $(function() {

      $(".btn_delete").click(function(){
      var element = $(this);
      var id = element.attr("id");
      var dataString = 'id=' + id;
      if(confirm("Sure you want to delete this item?"))
      {
  $.ajax({
  type: "GET",
  url: "temp_trans_del.php",
  data: dataString,
  success: function(){
    
        }
    });
    
    $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
    .animate({ opacity: "hide" }, "slow");
      }
      return false;
      });

      });
    </script>
</body>
</html>