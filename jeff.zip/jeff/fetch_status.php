<?php

include 'config.php';

	
try
{
	$cat = $_POST['get_status'];
	
	//connect to database
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	//select data from db
	$stmt = $conn->prepare("SELECT DISTINCT gstatus FROM 5g_price WHERE prod_id = '$cat' ");
	
	//execute the sql query
	$stmt->execute();
	//use php function fetch() to get the db column data
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
	{
        //use the fetched data to store into variable
		$status = $row['gstatus'];
		
		echo "
		<div class='row'>
			<input type='button' name='stat' class='form-control btn btn-block btn-theme' style='margin: 3px;' value='$status' onclick='showPrice(this.value);'></div>
		";
	}
	
	exit;
	
	
}	
catch (PDOException $e)
{
	echo "Connection failed: " . $e->getMessage();
}

//close conection
$conn = null;


?>