<?php
include('connect.php');
include('valid.php');

$id =$_POST['id'];
$aid = $_SESSION['admin_id'];
		$date = date("Y-m-d H:i:s");

		$query=mysqli_query($conn,"SELECT * FROM customer WHERE `cust_id` = '$id'")or die(mysqli_error());
  
        $row=mysqli_fetch_array($query);
		$name=$row['cust_first'];
		$remarks="remove $name as a customer";  
	
		mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$aid','$remarks','$date')")or die(mysqli_error($conn));

mysqli_query($conn, "UPDATE customer SET status='Deactivated' WHERE cust_id = $id")or die(mysqli_error($conn));
header("location: manage_customer.php");


?>