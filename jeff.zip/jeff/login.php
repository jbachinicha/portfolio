<?php
include('connect.php');

$username = $_POST['username'];
$password = $_POST['password'];


$query = mysqli_query($conn, "SELECT * FROM `admin` WHERE `username` = '$username' && `password` = '$password'");
while ($row = mysqli_num_rows($query)) {
	$res = mysqli_fetch_assoc($query);

	if ($res['type'] == "Cashier") {

	$v_admin = $q_admin->num_rows;
	if($v_admin > 0){
		$mysqli = new mysqli('localhost','root','','jeff');	
		$ip = $_SERVER['REMOTE_ADDR'];
		echo 'Success';
		session_start();
		$_SESSION['admin_id'] = $f_admin['admin_id'];
		$type = $f_admin['type'];
		$mysqli->query("INSERT INTO log_records (ip_address,date,username_used,password_used,type) VALUES ('$ip', NOW(),'$username','$password','$type')");
		}else{

	$mysqli = new mysqli('localhost','root','','jeff');	
	$ip = $_SERVER['REMOTE_ADDR'];
	$result = $mysqli->query("SELECT count(ip_address) AS failed_login_attempt FROM failed_login WHERE ip_address = '$ip'  AND date ");
	$row  = $result->fetch_assoc();
	$failed_login_attempt = $row['failed_login_attempt'];
	$result->free();

	if(count($_POST)>0) {
		$result = $mysqli->query("SELECT * FROM admin WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
		$row  = $result->fetch_assoc();
		$result->free();
		if(is_array($row)) {
			$_SESSION["admin_id"] = $row["admin_id"];
			$type = $f_admin['type'];
			$mysqli->query("DELETE FROM failed_login WHERE ip_address = '$ip'");
		} else {
				$mysqli->query("INSERT INTO failed_login (ip_address,date,username_used,password_used,type) VALUES ('$ip', NOW(),'$username','$password','$type')");
		}
	}
		}
		header("location: cashier/home.php");





	}
	else{

	

$v_admin = $q_admin->num_rows;
	if($v_admin > 0){
		$mysqli = new mysqli('localhost','root','','jeff');	
		$ip = $_SERVER['REMOTE_ADDR'];
		echo 'Success';
		session_start();
		$_SESSION['admin_id'] = $f_admin['admin_id'];
		$type = $f_admin['type'];
		$mysqli->query("INSERT INTO log_records (ip_address,date,username_used,password_used,type) VALUES ('$ip', NOW(),'$username','$password','$type')");
		}else{

	$mysqli = new mysqli('localhost','root','','jeff');	
	$ip = $_SERVER['REMOTE_ADDR'];
	$result = $mysqli->query("SELECT count(ip_address) AS failed_login_attempt FROM failed_login WHERE ip_address = '$ip'  AND date ");
	$row  = $result->fetch_assoc();
	$failed_login_attempt = $row['failed_login_attempt'];
	$result->free();

	if(count($_POST)>0) {
		$result = $mysqli->query("SELECT * FROM admin WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
		$row  = $result->fetch_assoc();
		$result->free();
		if(is_array($row)) {
			$_SESSION["admin_id"] = $row["admin_id"];
			$type = $f_admin['type'];
			$mysqli->query("DELETE FROM failed_login WHERE ip_address = '$ip'");
		} else {
				$mysqli->query("INSERT INTO failed_login (ip_address,date,username_used,password_used,type) VALUES ('$ip', NOW(),'$username','$password','$type')");
		}
	}
		}
		header("location: cashier/home.php");


	}




}


?>