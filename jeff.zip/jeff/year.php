<?php
	require_once('valid.php');
?>
<html>
<head>
<title>Yearly Sales</title>
</head>
<body>
<center>

                <div id="chartjs">
                  <div class="row mt">
                    <div>
                      <?php
                        include 'config.php';
              
                        try {
                          $c = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                          $c->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                          $graph = $c->prepare("SELECT MONTH(date_added) AS MONTHZ, SUM(qty) AS TQ FROM SALES WHERE YEAR(date_added)=YEAR(CURDATE()) GROUP BY MONTH(date_added)");
  
                          $graph->execute();

                          $jan = 0;
                          $feb = 0;
                          $mar = 0;
                          $apr = 0;
                          $may = 0;
                          $jun = 0;
                          $jul = 0;
                          $aug = 0;
                          $sep = 0;
                          $oct = 0;
                          $nov = 0;
                          $dec = 0;
              
                          while($result = $graph->fetch(PDO::FETCH_ASSOC))
                          {
                            $month = $result['MONTHZ'];
                            $totalquantity = $result['TQ'];
                
                            if($month == 1)
                          {
                            $jan = $totalquantity;
                          }
                            if($month == 2)
                          {
                            $feb = $totalquantity;
                          }
                            if($month == 3)
                          {
                            $mar = $totalquantity;
                          }
                            if($month == 4)
                          {
                            $apr = $totalquantity;
                          }
                            if($month == 5)
                          {
                            $may = $totalquantity;
                          }
                            if($month == 6)
                          {
                            $jun = $totalquantity;
                          }
                            if($month == 7)
                          {
                            $jul = $totalquantity;
                          }
                            if($month == 8)
                          {
                            $aug = $totalquantity;
                          }
                            if($month == 9)
                          {
                            $sep = $totalquantity;
                          }
                            if($month == 10)
                          {
                            $oct = $totalquantity;
                          }
                            if($month == 11)
                          {
                            $nov = $totalquantity;
                          }
                            if($month == 12)
                          {
                            $dec = $totalquantity;
                          }
                          }

                          echo '<div  style="height: auto" class="col-xs-12">
                          <canvas id="canvas"></canvas>
                          </div>';

                          
                        } 

                        catch (Exception $e) {
                          echo "Connection failed: " . $e->getMessage();
                        }
                        $conn = null;
                      ?>
                    <script>
                      $jan = <?php echo $jan; ?>;
                      $feb = <?php echo $feb; ?>;
                      $mar = <?php echo $mar; ?>;
                      $apr = <?php echo $apr; ?>;
                      $may = <?php echo $may; ?>;
                      $jun = <?php echo $jun; ?>;
                      $jul = <?php echo $jul; ?>;
                      $aug = <?php echo $aug; ?>;
                      $sep = <?php echo $sep; ?>;
                      $oct = <?php echo $oct; ?>;
                      $nov = <?php echo $nov; ?>;
                      $dec = <?php echo $dec; ?>;
                      $year = <?php echo date("Y"); ?>;

                      	var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
				        var color = Chart.helpers.color;
				        var barChartData = {
				            labels: ["January", "February", "March", "April", "May", "June", "July","August", "September", "October", "November", "December"],
				            datasets: [{
				                label: 'Sales',
				                backgroundColor: color(window.chartColors.blue).alpha(0.7).rgbString(),
				                borderColor: window.chartColors.blue,
				                borderWidth: 1,
				                data: [$jan,$feb,$mar,$apr,$may,$jun,$jul,$aug,$sep,$oct,$nov,$dec]
				            }]

				        };

				        window.onload = function() {
				            var ctx = document.getElementById("canvas").getContext("2d");
				            window.myBar = new Chart(ctx, {
				                type: 'bar',
				                data: barChartData,
				                options: {
				                    responsive: true,
				                    legend: {
				                        position: 'top',
				                    },
				                    title: {
				                        display: true,
				                    }
				                }
				            });

				        };
                    </script>
                  </div>
                </div>
              </div>

<!-- <?php

include 'config.php';

	
try
{
	
	//connect to database
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	//select data from db
	$stmt = $conn->prepare("SELECT EMPID,PRODUCTID,NAME,COLORS,SIZE,SLEEVE,
										FLOWERSEMB,QUANTITY,
										PRICE,REVENUE,DATE_FORMAT(DATE(DATE_TIME),'%d-%m-%Y') AS DISDATE, 
										YEAR(DATE_TIME) 
										FROM SALES 
										WHERE YEAR(DATE_TIME)=YEAR(CURDATE())");
	
	//execute the sql query
	$stmt->execute();
	
	echo "
	<div class='table-responsive'>
		<table class='table table-bordered table-hover table-striped'>
		<tr>
		<th>No.</th>
		<th>Emp. ID</th>
		<th>Date</th>
		<th>Product ID</th>
		<th>Product</th>
		<th>Colors</th>
		<th>Size</th>
		<th>Sleeve</th>
		<th>Flowers</th>
		<th>Quantity</th>
		<th>Price (RM)</th>
		<th>Profits (RM)</th>
		</tr>
	
	
	";
	
	$i=0;	
	//use php function fetch() to get the db column data
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
	{
        //use the fetched data to store into variable
		$name = $row['NAME'];
		$colors = $row['COLORS'];
		$size = $row['SIZE'];
		$sleeve = $row['SLEEVE'];
		$flowers = $row['FLOWERSEMB'];
		$quantity = $row['QUANTITY'];
		$price = $row['PRICE'];
		$revenue = $row['REVENUE'];
		$datetime = $row['DISDATE'];
		$empid = $row['EMPID'];
		$prodid = $row['PRODUCTID'];
		
		$no = $i+1;
		
			echo " 
			<tr>
		<td>$no</td>
		<td>$empid</td>
		<td>$datetime</td>
		<td>$prodid</td>
		<td>$name</td>
		<td>$colors</td>
		<td>$size</td>
		<td>$sleeve</td>
		<td>$flowers</td>
		<td>$quantity</td>
		<td>$price</td>
		<td>$revenue</td>
		</tr>
			
		
	
		";
		
		$i++;
	}
	
	$total = $conn->prepare("SELECT SUM(PRICE) AS TOTALSALES, 
												SUM(REVENUE) AS TOTALREV,
												SUM(QUANTITY) AS TOTALQUANTITY 												
												FROM SALES 
												WHERE YEAR(DATE_TIME)=YEAR(CURDATE())");
	
	$total->execute();
	
	$result = $total->fetch(PDO::FETCH_ASSOC);
	$totalprice = $result['TOTALSALES'];
	$totalrevenue = $result['TOTALREV'];
	$totalquantity = $result['TOTALQUANTITY'];
	
	//total
	echo "
	<tr>
	<td  colspan='8'></td>
	<th>Total</th>
	<th>$totalquantity</th>
	<th>$totalprice</th>
	<th>$totalrevenue</th>
	</tr>
	
	</table>
	</div>
	<br><br><br>
	";
	
	
	//generate bar graph function
	
	$graph = $conn->prepare("SELECT MONTH(DATE_TIME) AS MONTHZ, SUM(QUANTITY) AS TQ FROM SALES WHERE YEAR(DATE_TIME)=YEAR(CURDATE()) GROUP BY MONTH(DATE_TIME)");
	
	$graph->execute();
	
	
	$jan = 0;
	$feb = 0;
	$mar = 0;
	$apr = 0;
	$may = 0;
	$jun = 0;
	$jul = 0;
	$aug = 0;
	$sep = 0;
	$oct = 0;
	$nov = 0;
	$dec = 0;
	
	while($result = $graph->fetch(PDO::FETCH_ASSOC))
	{
		$month = $result['MONTHZ'];
		$totalquantity = $result['TQ'];
		
		if($month == 1)
		{
			$jan = $totalquantity;
		}
		if($month == 2)
		{
			$feb = $totalquantity;
		}
		if($month == 3)
		{
			$mar = $totalquantity;
		}
		if($month == 4)
		{
			$apr = $totalquantity;
		}
		if($month == 5)
		{
			$may = $totalquantity;
		}
		if($month == 6)
		{
			$jun = $totalquantity;
		}
		if($month == 7)
		{
			$jul = $totalquantity;
		}
		if($month == 8)
		{
			$aug = $totalquantity;
		}
		if($month == 9)
		{
			$sep = $totalquantity;
		}
		if($month == 10)
		{
			$oct = $totalquantity;
		}
		if($month == 11)
		{
			$nov = $totalquantity;
		}
		if($month == 12)
		{
			$dec = $totalquantity;
		}
	}
	
	echo "
	
	
	<h2>Bar Graph of Quantity Sold</h2>
 
	 <div id='graph' style='height: 400px;width: 100%;'></div>
	 
	 <script>
	 Morris.Bar({
	  element: 'graph',
	  data: [
		{x: 'January', y: $jan},
		{x: 'February', y: $feb},
		{x: 'March', y: $mar},
		{x: 'April', y: $apr},
		{x: 'May', y: $may},
		{x: 'Jun', y: $jun},
		{x: 'July', y: $jul},
		{x: 'August', y: $aug},
		{x: 'September', y: $sep},
		{x: 'October', y: $oct},
		{x: 'November', y: $nov},
		{x: 'December', y: $dec}
	  ],
	  xkey: 'x',
	  ykeys: ['y'],
	  labels: ['Quantity Sold'],
	  
	});
	 </script>
	
	
	
	";
	

	
	
	
}	
catch (PDOException $e)
{
	echo "Connection failed: " . $e->getMessage();
}

//close conection
$conn = null;


?> -->

</form>
</center>
</body>
</html>