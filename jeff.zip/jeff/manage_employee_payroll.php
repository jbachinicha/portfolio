<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('payroll').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Payroll</li>
    </ol>

			<div class = "col-lg-12 well" style = "margin-top:20px;">
					<form method="POST" class="form-inline" id="payForm">
                <button type="button" data-toggle="modal" data-target="#deduc" class="btn btn-theme">Deductions</button>
                
              </form>
                <br>
                <br><p align="center"><big><b>Employee Account</b></big></p>
                    <table class="table table-bordered table-hover table-condensed" id="table">
                      <thead>
                        <tr class="info">
                          <th>Employee Name</th>
                          <th>Employee ID</th>
                          <th>Position</th>
                          <th>Hours Work</th>
                          <th>Rate</th>
                          <th>Gross</th>
                          <th>Deductions</th>
                          <th>Cash Advance</th>
                          <th>Net Pay</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php
                            include 'connect.php';

                            $deduc_sql = mysqli_query($conn, "SELECT *, SUM(amount) as total_amount FROM deductions")or die(mysqli_error($conn));
                            $r = mysqli_fetch_array($deduc_sql);
                            $deduction = $r['total_amount'];

                            $sql = mysqli_query($conn, "SELECT *, SUM(num_hr) AS total_hr, a.employee_id AS empid FROM attendance a JOIN employee e ON e.id=a.employee_id JOIN position p ON p.id=e.position_id WHERE e.status='Hired' GROUP BY a.employee_id ORDER BY e.last_name ASC, e.first_name ASC")or die(mysqli_error($conn));
                            $total = 0;
                            while ($row = mysqli_fetch_array($sql)) {
                              $empid = $row['empid'];
                              $casql = mysqli_query($conn, "SELECT *, SUM(amount) AS cashamount FROM cashadvance WHERE emp_id='$empid'")or die(mysqli_error($conn));
                              $carow = mysqli_fetch_array($casql);
                              $cashadvance = $carow['cashamount'];

                              $gross = $row['rate'] * $row['total_hr'];
                              $total_deduction = $deduction + $cashadvance;
                              $net = $gross - $total_deduction;
                              echo "
                        <tr>
                          <td>".$row['last_name'].", ".$row['first_name']."</td>
                          <td>".$row['employee_id']."</td>
                          <td>".$row['description']."</td>
                          <td>".$row['total_hr']." hrs </td>
                          <td>".$row['rate']."</td>
                          <td>".number_format($gross, 2)."</td>
                          <td>".number_format($deduction, 2)."</td>
                          <td>".number_format($cashadvance, 2)."</td>
                          <td>".number_format($net, 2)."</td>
                          <td><a href='payslip.php?employee_id=".$row['employee_id']."' class='btn btn-primary'> <span style='color: #fff;' class='glyphicon glyphicon-print'></span> Payslip</td>
                        </tr>
                      ";
                            }

                          ?>
                      </tbody>
                    </table>

			</div>

			 <div class="modal fade" id="deduc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 align="center" style="color: white;"><b>Deduction</b></h3>
                  </div>
                  <div class="modal-body">
                    <a href="#add" data-target="#add" data-toggle="modal" data-dismiss="modal" class="btn btn-theme"><span class = "fa fa-plus"></span>Add Deduction</a> <br>
      <form class="form-horizontal" action="#" name="form">
            <table id = "example5" class = "table table-bordered">
              <thead class = "alert">
                <tr>
                  <th>Deduction</th>
                  <th>Amount</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $q_admin = $conn->query("SELECT * FROM deductions ") or die(mysqli_error());
                while($f_admin = $q_admin->fetch_array()){
                  $pos = $f_admin['description'];
                  $amount = $f_admin['amount'];
                  $id = $f_admin['id'];
              ?>  
                <tr class = "target table-row">
                  <td><?php echo $f_admin['description']?></td>
                  <td><?php echo $f_admin['amount']?></td>
                  <td width="10%">
                    <center>
                    <a href="#deductions<?php echo $f_admin['id'];?>" data-target="#deductions<?php echo $f_admin['id'];?>" data-toggle="modal"  class="btn btn-theme"><span class = "fa fa-edit"></span>Update</a>
                  </center>
                    
                  </td>
                </tr>
                <div id="deductions<?php echo $f_admin['id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center" style="color: white;"><b>Deduction</b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">

              <form class="form-horizontal" action="update_deduction.php" name="form" method="post">
                <div class="form-group">
                  <label class="col-sm-4 control-label">Deduction</label>
                  <div class="col-sm-8">
                    <input type="hidden" name="id" class="form-control" required="required" value="<?php echo $f_admin['id'] ?>">
                    <input type="text" name="pos" class="form-control" required="required" value="<?php echo $f_admin['description'] ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">Amount</label>
                  <div class="col-sm-8">
                    <input type="text" name="amount" class="form-control" value="<?php echo $f_admin['amount'] ?>" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-8">
                    <input type="submit" name="up" class="btn btn-theme" value="Submit">
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
               <?php
                }
              ?>  
              </tbody>
            </table>
            <br>
            <br><br><br><br>
              </form>
                  </div>
                </div>
              </div>
            </div>

              <div id="add" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center" style="color: white;"><b>Deduction</b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">

              <form class="form-horizontal" action="add_deduction.php" name="form" method="post">
                <div class="form-group">
                  <label class="col-sm-4 control-label">Deduction</label>
                  <div class="col-sm-8">
                    <input type="text" name="pos" class="form-control" required="required" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">Amount</label>
                  <div class="col-sm-8">
                    <input type="text" name="rate" class="form-control" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-8">
                    <input type="submit" name="add" class="btn btn-theme" value="Submit">
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>


</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#table").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    <script type = "text/javascript">
		$(document).ready(function(){
			$result = $('<center><label>Deleting...</label></center>');
			$('.deladmin_id').click(function(){
				$admin_id = $(this).attr('value');
				$(this).parents('td').empty().append($result);
				$('.deladmin_id').attr('disabled', 'disabled');
				$('.eadmin_id').attr('disabled', 'disabled');
				setTimeout(function(){
					window.location = 'delete_product.php?prod_id=' + $admin_id;
				}, 1000);
			});

		});
	</script>
</body>
</html>