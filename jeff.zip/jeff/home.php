<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
  <head>
    <title><?php require'account.php'; echo $name;?></title>
    <?php include('include/head_scripts.php');?>

    <link rel="stylesheet" type="text/css" href="js/gritter/css/jquery.gritter.css" />

    <script type="text/javascript">
      $(document).ready(function () {
        var unique_id = $.gritter.add({
          title: 'Welcome to Jinska Admin Panel!',
          text: '<h5><?php require'account.php'; echo $name;?></h5>',
          image: 'images/users.png',
          sticky: false,
          time: '',
          class_name: 'my-sticky-class'
        });

        var active = document.getElementById('dashboard').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
    </script>

    <style>
      .low{
        color: red;
      }
    </style>
  </head> 
  <body>
    <div class="page-container">
      <?php include('include/home_header.php');?>
      <?php include('include/logout_modal.php');?>

        <div class="left-content">
          <div class="mother-grid-inner" style="padding-top: 80px;">
<!--heder end here-->
            <ol class="breadcrumb noprint well">
              <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i></li>
            </ol>

          <div id="poduct_details" class = "col-lg-12 well breadcrumb" style = "margin-top:-20px;">
                    <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="icon">
              <i class="fa fa-group"></i>
            </div>
            <div class="inner">
              <?php
                $sql = "SELECT * FROM employee WHERE status='Hired'";
                $query = $conn->query($sql);

                echo "<h3>".$query->num_rows."</h3>";
              ?>

              <p>Total Employees</p>
            </div>
            <a href="manage_employee.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <div class="inner">
              <?php
                $conn = mysqli_connect("localhost","root","","jeff");
                $q = mysqli_query($conn, "SELECT COUNT(*) AS TOTAL,SUM(qty) AS TQ, SUM(total) AS TA FROM SALES WHERE DAY(date_added)=DAY(CURDATE()) AND MONTH(date_added)=MONTH(CURDATE())");
                while ($row = mysqli_fetch_assoc($q)) { 
                $total_sales = $row['TOTAL']; ?>
                        <h3><?php echo $total_sales; ?></h3>
                                    <?php
                                        }
                                    ?>
          
              <p>Total Daily Sales</p>
            </div>
            <a href="reports.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="icon">
              <i class="fa fa-truck"></i>
            </div>
            <div class="inner">
                        <h3>0</h3>
          
              <p>Total Pending Delivery</p>
            </div>
            <a href="calendar.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="icon">
              <i class="fa fa-refresh"></i>
            </div>
            <div class="inner">
                        <?php
                                        $conn = mysqli_connect("localhost","root","","jeff");
                                        $q = mysqli_query($conn, " SELECT COUNT(*) AS COUNTLOW FROM INVENTORY WHERE prod_qty < 50");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $countlow = $row['COUNTLOW'];
                                            ?>
                                            <h3><?php echo "$countlow"; ?></h3>
                                    <?php
                                        }
                                    ?>
          
              <p>Total Reorders</p>
            </div>
            <a href="inventory.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

            <div class="row  col-xs-12">
        <div class="col-xs-10">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Sales Chart(<?php echo date("Y") ?>)</h3>
              <div class="box-tools">
                <?php include 'year.php'; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
          </div>
    
          </div>
        </div>
    </div>
<div class="text-right" style="color: #000; position: bottom;">&#169; Copyright 2017 JinskaION, Inc. | Powered by <a>Randz PC</a> &nbsp;&nbsp;</div>

    <div><?php include('include/footer.php');?></div>
    <script src="js/gritter/js/jquery.gritter.js"></script>
    <script src="js/gritter-conf.js"></script>
    <script type="text/javascript" src="js/jquery.backstretch.min.js"></script>
          <script>
          $.backstretch("images/2.png", {speed: 500});
      </script>


  </body>
</html>