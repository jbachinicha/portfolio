var xmlHttp = createXmlHttpRequestObject();

function createXmlHttpRequestObject(){
	var xmlHttp;

	if (window.ActiveXObject){
		try{
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(e){
			alert("Can't create IE object");
			xmlHttp = false;
		}
	}
	else{
		try{
			xmlHttp = new XMLHttpRequest();
		}
		catch(e){
			xmlHttp = false;
		}
	}

	if (!xmlHttp){
		alert("Can't create that object!");
	}
	else{
		return xmlHttp;
	}
}

function process(){
	if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0) {
		document.getElementById('filter').style.display="block";

		xmlHttp.open("GET", "searchDB.php?userInput="+encodeURIComponent(document.getElementById("userInput").value),true);
		xmlHttp.onreadystatechange = handleResponse;
		xmlHttp.send(null);
	}
	else{

	}
}

function handleResponse(){
	if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0){
		if (xmlHttp.status == 200){
			document.getElementById("filter").innerHTML = xmlHttp.responseText;
		}
		else{
			alert("Something went wrong");
		}
	}
}