<?php
        include('connect.php');
        $query = "SELECT * FROM `employee` WHERE `employee_id` = '$_REQUEST[employee_id]'";
        $result = mysqli_query($conn,$query) or die ( mysql_error());


        while ($row = $result->fetch_array())
        {
          ?>

              <form class="form-horizontal" action="update_account.php?employee_id=<?php echo $row['employee_id']?>" method="post" name="form">
                <input type="hidden" name="new" value="1" />
                <input name="id" type="hidden" value="<?php echo $row['employee_id'];?>" />
                  <div class="form-group">
                    <label class="col-sm-5 control-label"></label>
                    <div class="col-sm-4">
                      <h2><span name="firstname"><?php echo $row['last_name']; ?></span>, <?php echo $row['first_name']; ?></h2>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Deduction/s  :</label>
                    <div class="col-sm-4">
                    <select name="deduction" class="form-control" required>
                    </select>
                  </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Overtime  :</label>
                    <div class="col-sm-4">
                      <input type="text" name="overtime" class="form-control" value="" required="required">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Bonus  :</label>
                    <div class="col-sm-4">
                      <input type="text" name="bonus" class="form-control" value="" required="required">
                    </div>
                  </div><br><br>

                  <div class="form-group">
                    <label class="col-sm-5 control-label">Netpay  :</label>
                    <div class="col-sm-4">
                    </div>
                  </div><br><br>
                  <div class="form-group">
                    <label class="col-sm-5 control-label"></label>
                    <div class="col-sm-4">
                      <input type="submit" name="submit" value="Update" class="btn btn-danger">
                      <a href="manage_employee.php" class="btn btn-primary">Cancel</a>
                    </div>
                  </div>
              </form>
            <?php
          }
        ?>



