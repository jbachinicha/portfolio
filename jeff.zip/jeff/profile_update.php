<?php
include('connect.php');
include('valid.php');

$id = $_SESSION['admin_id'];
$first = $_POST['firstname'];
$last = $_POST['lastname'];
$middle = $_POST['middlename'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$username = $_POST['username'];
$password = $_POST['password'];

$pic = $_FILES["image"]["name"];
			if ($pic=="")
			{	
				if ($_POST['image1']<>""){
					$pic=$_POST['image1'];
				}
				else
					$pic="default.gif";
			}
			else
			{
				$pic = $_FILES["image"]["name"];
				$type = $_FILES["image"]["type"];
				$size = $_FILES["image"]["size"];
				$temp = $_FILES["image"]["tmp_name"];
				$error = $_FILES["image"]["error"];
			
				if ($error > 0){
					die("Error uploading file! Code $error.");
					}
				else{
					if($size > 100000000000) //conditions for the file
						{
						die("Format is not allowed or file size is too big!");
						}
				else
				      {
					move_uploaded_file($temp, "dist/uploads/".$pic);
				      }
					}
			
			}

$query=mysqli_query($conn,"SELECT * FROM admin WHERE `admin_id` = '$id'")or die(mysqli_error());
$row=mysqli_fetch_array($query);
$name=$row['firstname'];

$remarks="updated his/her information";


mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$aid','$remarks','$date')")or die(mysqli_error($conn));
mysqli_query($conn,"UPDATE admin SET lastname='$last',firstname='$first',address='$address',phone='$phone',pict='$pic',gender='$gender',username='$username',password='$password',middlename='$middle' WHERE admin_id='$id'")or die(mysqli_error($conn));
if ($id == 1) {
	header("location: admin_profile.php"); 
}
else{
	header("location: user_profile.php"); 
}
  

?>