<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app" ng-controller="myController">
  <head>
    <title><?php require'account.php'; echo $name;?></title>
    <?php include('include/head_scripts.php');?>
    <link rel="stylesheet" type="text/css" href="js/gritter/css/jquery.gritter.css" />
    <script type="text/javascript" src="searchScript.js"></script>
  </head> 
  <body>

    <div class="page-container">
      <?php include('include/cashier_header.php');?>
      <?php include('include/logout_modal.php');?>

      <div class="content">
        <div class="mother-grid-inner" style="padding-top: 80px;">
	        <ol class="breadcrumb well">
            <li class="breadcrumb-item">
              <a href="daily.php">Home</a> <i class="fa fa-angle-right"></i> Sales
            </li>
          </ol>

          <section class="content breadcrumb well">
            <div class="row">
              <div class="col-md-2"><button class="btn btn-danger"><a href="daily.php"><i class="fa fa-arrow-left"></i> Back</a></button></div>
              <div class="col-md-4">
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Add New Customer</h3>
                  </div>
                  <div class="box-body">
                    <form method="post" action="customer_add.php" enctype="multipart/form-data" class="form-horizontal" name="myForm" novalidate>
                      <div class="">
                        <div class="form-group">
                          <label for="date" class="col-sm-3 control-label">Last Name</label>
                          <div class="input-group col-sm-8">
                            <input type="text" class="form-control pull-right" id="date" name="last" title="Lastname" placeholder="Customer Last Name" ng-model="customer.lastname" required>
                          </div>
                        </div>
                      </div>
                      
                      <div class="">  
                        <div class="form-group">
                          <label for="date" class="col-sm-3 control-label">First Name</label>
                          <div class="input-group col-md-8">
                            <input type="text" class="form-control pull-right" id="date" name="first" title="Firstname" placeholder="Customer First Name" ng-model="customer.firstname" required>
                          </div>
                        </div>
                      </div>

                      <div class="">
                        <div class="form-group">
                          <label for="date" class="col-sm-5 control-label">Contact #</label>
                          <div class="input-group col-md-8">  
                            <input type="text" class="form-control pull-right" id="date" name="contact" title="Contact Number" placeholder="Contact Number" ng-model="customer.contact" required>
                          </div>
                        </div>  
                      </div>
                            
                      <div class="">
                        <div class="form-group">
                          <label for="date" class="col-sm-3 control-label">Address</label>   
                          <div class="input-group col-md-8">
                            <input type="text" class="form-control pull-right" id="date" name="address" title="Address" placeholder="Complete Address" ng-model="customer.address" required>
                          </div>
                        </div>
                      </div>     

                      <div class="col-md-12">
                        <div class="col-md-12">
                          <button class="btn btn-lg btn-theme pull-right" id="daterange-btn" name="" title="Next" ng-disabled="myForm.$invalid" ng-click="submit()">Next</button>
                        </div>  
                      </div>  
                    </form> 
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Find Existing Customer</h3>
                  </div>
                  <div class="box-body">
                    <form method="post" action="search.php" enctype="multipart/form-data" name="searchForm" novalidate>
                      <!--div class="form-group">
                        <label>Search Customer</label>
                        <div class="input-group col-md-12">
                          <input type="text" name="cid" class="form-control" title="Customer Name" ng-model="customer.search" required/>
                        </div>
                      </div-->
                      <div class="form-group">
                        <label for="date">Choose Customer Name</label>
                        <div class="input-group col-md-12">
                          <input type="text" id="userInput" placeholder="Search" onkeyup="process()" class="form-control" title="Customer Name" ng-model="customer.search" required><br>
                          <div id="filter"></div>

                          <!--select class="form-control select2" style="width: 100%;" name="cid" title="Customer Name" ng-model="customer.search" required>
                            <?php
                              $query2=mysqli_query($conn,"SELECT * FROM customer")or die(mysqli_error());
                              while($row2=mysqli_fetch_array($query2)){
                            ?>
                            <option value="<?php echo $row2['cust_id'];?>">
                              <?php echo $row2['cust_last'].", ".$row2['cust_first'];?>
                            </option>
                            <?php }?>
                          </select-->
                        </div>
                      </div>
      
                      <div class="form-group">
                        <div class="input-group col-md-12">
                        </div>
                      </div>
                    </form> 
                  </div>
                </div>
              </div>
              <div class="col-md-2"></div>
            </div>
          </section>

            
        </div>
      </div>
    <div class="noprint"><?php include('include/cashier_footer.php');?></div>
    <script src="js/angular.min.js"></script>
    <script>
      var app = angular.module('app', []);
      app.controller('myController', function($scope){
        $scope.valid = false;
        $scope.submit = function(){
          $scope.valid = true;
        }
        $scope.close = function(){
          $scope.valid = false;
        }
      });
    </script>

    <script src="js/gritter/js/jquery.gritter.js"></script>
    <script src="js/gritter-conf.js"></script>
    <script language="javascript">
            var popupWindow = null;
            function centeredPopup(url,winName,w,h,scroll){
              LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
              TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
              settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
              popupWindow = window.open(url,winName,settings)}
          </script>
  </body>
</html>