<?php
require_once 'valid.php';
 if ($_SESSION['admin_id'] == 1) {
 	header('location: home.php');
 }
 else{
 	header('location: daily.php');
 }



?>