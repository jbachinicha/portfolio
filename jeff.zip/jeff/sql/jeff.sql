-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2019 at 03:02 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jeff`
--

-- --------------------------------------------------------

--
-- Table structure for table `5g_price`
--

CREATE TABLE `5g_price` (
  `gid` int(11) NOT NULL,
  `gstatus` varchar(50) NOT NULL,
  `gprice` double(10,2) NOT NULL,
  `category` varchar(100) NOT NULL,
  `prod_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `5g_price`
--

INSERT INTO `5g_price` (`gid`, `gstatus`, `gprice`, `category`, `prod_id`) VALUES
(1, 'New', 150.00, '5Galloon', 4),
(2, 'Refill', 30.00, '5Galloon', 4);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(24) NOT NULL,
  `password` varchar(12) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `type` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `pict` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `firstname`, `middlename`, `lastname`, `type`, `address`, `gender`, `phone`, `pict`) VALUES
(1, 'jinskawater_io', 'jinskawater', 'Jean', 'Marco', 'Apuda', 'Administrator', 'Sabang, Sibonga, Cebu', 'Male', '09353993218', 0x61342e6a7067),
(2, 'clarion_jx', 'clarionrandy', 'Randy', 'DIaz', 'Clarion', 'Cashier', 'Sabang, Sibonga, Cebu', 'Male', '09353993218', 0x72616e647a2e6a7067),
(3, 'admin12345', 'admin12345', 'Berto', 'Diaz', 'Makautot', 'Administrator', 'Sabang, Sibonga, Cebu', 'Male', '09353993218', '');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  `status` int(1) NOT NULL,
  `time_out` time NOT NULL,
  `num_hr` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `employee_id`, `date`, `time_in`, `status`, `time_out`, `num_hr`) VALUES
(1, 2, '2018-07-16', '07:07:39', 1, '14:26:33', 5.4333333333333),
(2, 4, '2018-07-16', '09:10:17', 0, '14:26:18', 4.2666666666667),
(3, 2, '2018-07-17', '14:27:50', 0, '17:00:07', 2.5333333333333);

-- --------------------------------------------------------

--
-- Table structure for table `cashadvance`
--

CREATE TABLE `cashadvance` (
  `id` int(11) NOT NULL,
  `date_advance` date NOT NULL,
  `emp_id` varchar(15) NOT NULL,
  `amount` double NOT NULL,
  `cash_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashadvance`
--

INSERT INTO `cashadvance` (`id`, `date_advance`, `emp_id`, `amount`, `cash_status`) VALUES
(1, '2018-07-16', '2', 100, 'Not Paid'),
(2, '2018-07-22', '4', 500, 'Not Paid');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL,
  `cust_first` varchar(50) NOT NULL,
  `cust_last` varchar(30) NOT NULL,
  `cust_address` varchar(100) NOT NULL,
  `cust_contact` varchar(30) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `cust_pic` varchar(300) NOT NULL,
  `credit_status` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_first`, `cust_last`, `cust_address`, `cust_contact`, `balance`, `cust_pic`, `credit_status`, `status`) VALUES
(1, 'Randy', 'Clarion', 'Sabang, Sibonga, Cebu\r\n', '09353993218', '0.00', 'smile.png', 'Active', 'Active'),
(2, 'Ajlyn', 'Canadalla', 'Bolinawan, Carcar City, Cebu', '09051914073', '303.20', 'smile.png', 'Active', 'Active'),
(5, 'Celine', 'Abella', 'Canf=daguit, Sibonga, Cebu', '09567485645', '0.00', 'smile.png', 'Active', 'Active'),
(6, 'Bruce', 'Bacalso', 'Mangyan, Sibonga, Cebu', '0957684374', '0.00', 'smile.png', 'Active', 'Active'),
(7, 'Jochelle Mae', 'Lopez', 'Candaguit, Sibonga, cebu', '0956487474', '0.00', 'smile.png', 'Active', 'Active'),
(8, 'Berto', 'Makabale', 'Bahay, Bagakay', '09875866463', '0.00', 'smile.png', 'Active', 'Deactivated');

-- --------------------------------------------------------

--
-- Table structure for table `deductions`
--

CREATE TABLE `deductions` (
  `id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deductions`
--

INSERT INTO `deductions` (`id`, `description`, `amount`) VALUES
(1, 'SSS', 100),
(2, 'Pagibig', 120),
(3, 'PhilHealth', 100),
(4, 'Bir', 200);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text,
  `last_name` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `date_employed` date NOT NULL,
  `status` text NOT NULL,
  `pic` varchar(300) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `position_id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `employee_id`, `first_name`, `middle_name`, `last_name`, `address`, `phone`, `date_employed`, `status`, `pic`, `gender`, `position_id`, `schedule_id`) VALUES
(2, 'NRI706328915', 'Randy', 'Diaz', 'Clarion', 'Sabang, Sibonga, Cebu', '09353993218', '2018-07-15', 'Hired', 'a6.jpg', 'Male', 1, 1),
(3, 'RLY345976182', 'asdsad', 'awdasd', 'wadsa', 'wdasdad', '34343434343', '2018-07-15', 'Fired', '4.jpg', 'Female', 2, 3),
(4, 'XWY394781560', 'awds', 'awdwad', 'sdawa', '3sdasdwads', '345345345345', '2018-07-15', 'Hired', 'a5.jpg', 'Male', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `events_details_id` int(11) NOT NULL,
  `events_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `product` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`events_details_id`, `events_id`, `prod_id`, `price`, `qty`, `product`, `date`, `status`) VALUES
(1, 1, 4, 150.00, 10, 'Alkaline Drinking Water', '2018-07-20', 0),
(2, 2, 3, 20.00, 1, 'Mineral Drinking Water', '2018-07-27', 0);

-- --------------------------------------------------------

--
-- Table structure for table `events_details`
--

CREATE TABLE `events_details` (
  `events_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `cash_tendered` double(10,2) NOT NULL,
  `discount` double(10,2) NOT NULL,
  `amount_due` double(10,2) NOT NULL,
  `cash_change` double(10,2) NOT NULL,
  `date_added` datetime NOT NULL,
  `total` double(10,2) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events_details`
--

INSERT INTO `events_details` (`events_id`, `cust_id`, `cash_tendered`, `discount`, `amount_due`, `cash_change`, `date_added`, `total`, `qty`) VALUES
(1, 1, 0.00, 0.00, 1500.00, -1500.00, '2018-07-17 11:43:08', 1500.00, 10),
(2, 5, 20.00, 0.00, 20.00, 0.00, '2018-07-23 23:50:45', 20.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `failed_login`
--

CREATE TABLE `failed_login` (
  `ip_address` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `username_used` varchar(50) NOT NULL,
  `password_used` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `failed_login`
--

INSERT INTO `failed_login` (`ip_address`, `date`, `username_used`, `password_used`, `type`) VALUES
('127.0.0.1', '2018-06-10', 'clarion_jx', 'clarinrandy', ''),
('127.0.0.1', '2018-06-10', 'jinskawater_io', 'jinskawter', ''),
('127.0.0.1', '2018-06-16', 'jinskawater_io', 'jinskwater', '');

-- --------------------------------------------------------

--
-- Table structure for table `history_log`
--

CREATE TABLE `history_log` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_log`
--

INSERT INTO `history_log` (`log_id`, `user_id`, `action`, `date`) VALUES
(1, 1, 'added 10 of Seal', '2018-01-30 10:51:59'),
(2, 6, 'added Celine as new employee', '2018-02-04 06:27:47'),
(3, 6, 'added asdasdasdasd as new employee', '2018-02-04 06:30:25'),
(4, 6, 'remove asdasdasdasd as an employee', '2018-02-04 06:30:29'),
(5, 6, 'added 100 of Alkaline Drinking Water', '2018-02-04 07:30:32'),
(6, 6, 'added 100 of Alkaline Drinking Water', '2018-02-04 07:31:57'),
(7, 6, 'added 100 of Mineral Drinking Water', '2018-02-04 07:32:05'),
(8, 6, 'added 100 of Purified Drinking Water', '2018-02-04 07:32:16'),
(9, 6, 'added 100 of ', '2018-02-04 07:32:47'),
(10, 6, 'added 100 of ', '2018-02-04 07:32:57'),
(11, 6, 'added 100 of ', '2018-02-04 07:33:05'),
(12, 1, 'updated the overtime rate to 15', '2018-02-14 07:34:23'),
(13, 1, 'updated the overtime rate to 1000', '2018-02-14 07:34:37'),
(14, 1, 'updated Celine account', '2018-02-16 15:13:46'),
(15, 1, 'added 90 of 5Galloon', '2018-02-16 21:34:07'),
(16, 1, 'updated the overtime rate to 500', '2018-02-16 21:36:27'),
(17, 1, 'added 10 of 350ml Bottle', '2018-02-16 21:37:13'),
(18, 1, 'added 10 of 5Galloon', '2018-02-24 07:26:50'),
(19, 1, 'added -1 of 5G Umbrella Seal', '2018-02-25 21:53:03'),
(20, 1, 'updated Ajlyn info', '2018-03-01 06:01:49'),
(21, 1, 'remove Celine as an employee', '2018-03-15 06:04:42'),
(22, 1, 'added asdawdawd as new employee', '2018-03-15 06:05:41'),
(23, 1, 'remove Randy as an employee', '2018-03-15 06:18:44'),
(24, 1, 'added Randy as new employee', '2018-03-15 06:19:26'),
(25, 1, 'remove asdawdawd as an employee', '2018-03-15 06:22:58'),
(26, 0, 'updated her information', '0000-00-00 00:00:00'),
(27, 0, 'updated her information', '0000-00-00 00:00:00'),
(28, 0, 'updated her information', '0000-00-00 00:00:00'),
(29, 0, 'updated her information', '0000-00-00 00:00:00'),
(30, 0, 'updated her information', '0000-00-00 00:00:00'),
(31, 0, 'updated her information', '0000-00-00 00:00:00'),
(32, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(33, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(34, 1, 'added 100 of 350ml Bottle', '2018-03-20 16:46:55'),
(35, 1, 'added 100 of 1L Bottle', '2018-03-20 16:47:23'),
(36, 1, 'added 100 of 5Galloon', '2018-03-20 16:47:40'),
(37, 1, 'added 100 of 5G Plastic Caps', '2018-03-20 16:47:49'),
(38, 1, 'added 100 of 5G Umbrella Seal', '2018-03-20 16:47:58'),
(39, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(40, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(41, 1, 'added Berto as new employee', '2018-06-23 21:57:30'),
(42, 1, 'remove Randy as an employee', '2018-06-23 22:02:21'),
(43, 1, 'added Randy as new employee', '2018-06-23 22:03:51'),
(44, 1, 'Fired Randy as an employee', '2018-06-23 22:03:56'),
(45, 1, 'updated  information', '2018-06-23 22:35:20'),
(46, 1, 'added 34 of 6L Bottle', '2018-07-08 00:54:05'),
(47, 1, 'added 1 of 1L Bottle', '2018-07-08 01:06:10'),
(48, 1, 'added 1 of 1L Bottle', '2018-07-08 01:06:20'),
(49, 1, 'added 1 of 1L Bottle', '2018-07-08 01:07:17'),
(50, 1, 'added 1 of 350ml Bottle', '2018-07-08 01:08:25'),
(51, 1, 'added 1 of 350ml Bottle', '2018-07-08 01:08:38'),
(52, 1, 'added 1 of 350ml Bottle', '2018-07-08 01:10:01'),
(53, 1, 'added 2 of 1L Bottle', '2018-07-08 01:13:36'),
(54, 1, 'added 2 of 1L Bottle', '2018-07-08 01:13:54'),
(55, 1, 'added 4 of 1L Bottle', '2018-07-08 01:15:40'),
(56, 1, 'remove Berto as a customer', '2018-07-08 01:20:50'),
(57, 1, 'updated  information', '2018-07-08 01:28:11'),
(58, 1, 'updated  information', '2018-07-08 01:38:31'),
(59, 1, 'updated  information', '2018-07-08 01:38:48'),
(60, 1, 'updated  information', '2018-07-08 01:39:10'),
(61, 1, 'added sadasd as new employee', '2018-07-08 01:46:26'),
(62, 1, 'added asdadas as new employee', '2018-07-08 01:47:28'),
(63, 1, 'added asdadas as new employee', '2018-07-08 01:48:19'),
(64, 1, 'added asdadas as new employee', '2018-07-08 01:49:14'),
(65, 1, 'added asdadas as new employee', '2018-07-08 01:49:44'),
(66, 1, 'added asdadas as new employee', '2018-07-08 01:49:58'),
(67, 1, 'added asd as new employee', '2018-07-08 02:52:28'),
(68, 1, 'updated Ajlyn info', '2018-07-08 02:56:20'),
(69, 1, 'updated Ajlyn info', '2018-07-08 03:00:05'),
(70, 1, 'Fired asd as an employee', '2018-07-08 03:01:05'),
(71, 1, 'updated Ajlyn account', '2018-07-09 04:42:42'),
(72, 1, 'added Ajlyn as new employee', '2018-07-15 04:27:00'),
(73, 1, 'added Randy as new employee', '2018-07-15 04:38:31'),
(74, 1, 'added Randy as new employee', '2018-07-15 04:40:37'),
(75, 1, 'updated Randy info', '2018-07-15 04:41:10'),
(76, 1, 'updated Randy info', '2018-07-15 04:46:08'),
(77, 1, 'updated Randy info', '2018-07-15 04:48:27'),
(78, 1, 'updated Randy info', '2018-07-15 04:48:52'),
(79, 1, 'updated Randy info', '2018-07-15 04:49:12'),
(80, 1, 'updated Randy info', '2018-07-15 04:49:21'),
(81, 1, 'added asdsad as new employee', '2018-07-15 04:49:53'),
(82, 1, 'updated asdsad info', '2018-07-15 04:50:01'),
(83, 1, 'Fired asdsad as an employee', '2018-07-15 04:50:06'),
(84, 1, 'updated Randy info', '2018-07-15 05:04:03'),
(85, 1, 'updated Randy info', '2018-07-15 06:07:44'),
(86, 1, 'added awds as new employee', '2018-07-15 06:11:02'),
(87, 1, 'updated awds info', '2018-07-15 06:12:55'),
(88, 1, 'updated awds info', '2018-07-15 09:42:19'),
(89, 1, 'added asd as new position', '2018-07-16 01:16:50'),
(90, 1, 'permit Randy for cash advance', '2018-07-16 06:27:28'),
(91, 1, 'permit awds for cash advance', '2018-07-22 08:27:11'),
(92, 1, 'permit awds for cash advance', '2018-07-22 08:27:50'),
(93, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(94, 0, 'updated his/her information', '0000-00-00 00:00:00'),
(95, 1, 'updated Randy info', '2018-07-22 13:07:03'),
(96, 1, 'updated awds info', '2018-07-22 13:07:20'),
(97, 1, 'updated awds info', '2018-07-22 13:07:29');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `prod_price` decimal(10,2) NOT NULL,
  `prod_pic` varchar(300) NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `reorder` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `market_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`prod_id`, `prod_name`, `prod_price`, `prod_pic`, `prod_qty`, `reorder`, `serial`, `category`, `market_price`) VALUES
(1, '350ml Bottle', '190.00', 'smile.png', 47, 50, 'IJ001', 'Container', 10),
(2, '1L Bottle', '240.00', 'smile.png', 39, 50, 'IJ002', 'Container', 15),
(3, '6L Bottle', '270.00', 'smile.png', 42, 50, 'IJ003', 'Container', 20),
(4, '5Galloon', '180.00', 'smile.png', 79, 50, 'IJ004', 'Container', 0),
(5, '5G Plastic Caps', '110.00', 'smile.png', 124, 50, 'IJ005', 'Cap', 0),
(6, '5G Umbrella Seal', '130.00', 'smile.png', 124, 50, 'IJ006', 'Seal', 0);

-- --------------------------------------------------------

--
-- Table structure for table `log_records`
--

CREATE TABLE `log_records` (
  `ip_address` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `username_used` varchar(50) NOT NULL,
  `password_used` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_records`
--

INSERT INTO `log_records` (`ip_address`, `date`, `username_used`, `password_used`, `type`, `Status`) VALUES
('127.0.0.1', '2018-06-23', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-06-23', 'asdsadssssss', 'sssdsadawdwr', '', 'failed'),
('127.0.0.1', '2018-06-23', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-06-24', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-06-24', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-06-24', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-06-25', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-03', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-05', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-07', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-07', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-08', 'jinskawater_io', 'jisnkawater', '', 'failed'),
('127.0.0.1', '2018-07-08', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-08', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-08', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-08', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-09', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-09', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-15', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-15', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-15', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-15', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-16', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-16', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-16', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-17', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-18', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-17', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-18', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-18', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-22', 'admin12345', 'admin12345', 'Administrator', 'success'),
('127.0.0.1', '2018-07-22', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-22', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-22', 'jinskawater_io', 'jinskawtaer', '', 'failed'),
('127.0.0.1', '2018-07-22', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-22', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-24', 'jinskawater_io', 'jinskawater', 'Administrator', 'success'),
('127.0.0.1', '2018-07-24', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('127.0.0.1', '2018-07-24', 'clarion_jx', 'clarionrandy', 'Cashier', 'success'),
('::1', '2019-02-03', 'admin12345', 'admin12345', 'Administrator', 'success'),
('::1', '2019-02-03', 'jinskawater_io', 'jinskawater', 'Administrator', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(100) NOT NULL,
  `TEXT` varchar(200) NOT NULL,
  `EMPID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`ID`, `TITLE`, `TEXT`, `EMPID`) VALUES
(1, 'Super Most UGLIEST PERSON IN THE WORLD', '1.Xander Bruce Jethro Bacalso Ford', 'E001'),
(2, 'No Trolls Left Behind', '1.Brucyang \r\n2.Aprilyang\r\n3.Makyang\r\n4.Celineyang\r\n5.Randyang\r\n6.Ajlynyang\r\n7.Jochelleyang \r\n8.Esrelyang', ''),
(3, 'Most HANDSOME BOYS', '1.Mark Neil Ocaña Reid Padilla Ortiz\r\n2.Randy Diaz Pascual Aguas Clarion', ''),
(4, 'Most UGLIEST GIRLS', '1.Celine Doniasa Abella\r\n2.April Kiray Gabijan\r\n3.Jochelle Mae Kitkat Lopez\r\n4.Ajlyn Zyrus Canadalla', '');

-- --------------------------------------------------------

--
-- Table structure for table `overtime`
--

CREATE TABLE `overtime` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `hours` double NOT NULL,
  `rate` double NOT NULL,
  `date_overtime` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL,
  `payment` decimal(10,2) NOT NULL,
  `payment_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_for` date NOT NULL,
  `due` decimal(10,2) NOT NULL,
  `interest` decimal(10,2) NOT NULL,
  `remaining` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL,
  `rebate` decimal(10,2) NOT NULL,
  `or_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `cust_id`, `sales_id`, `payment`, `payment_date`, `user_id`, `payment_for`, `due`, `interest`, `remaining`, `status`, `rebate`, `or_no`) VALUES
(3156, 1, 6, '550.00', '2017-02-21 19:57:12', 1, '2017-02-21', '550.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3157, 2, 7, '550.00', '2017-02-21 19:57:29', 1, '2017-02-21', '550.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3167, 2, 9, '113.30', '2017-02-21 00:00:00', 1, '2017-02-21', '113.30', '0.00', '0.00', 'paid', '0.00', 3151),
(3168, 3, 11, '6000.00', '2018-01-11 11:46:11', 1, '2018-01-11', '6000.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3169, 1, 15, '30.00', '2018-01-23 16:40:32', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1904),
(3170, 3, 16, '30.00', '2018-01-23 16:52:37', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1905),
(3171, 2, 17, '30.00', '2018-01-23 16:53:09', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1906),
(3172, 2, 18, '30.00', '2018-01-23 16:54:46', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1907),
(3173, 2, 19, '30.00', '2018-01-23 16:55:34', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1908),
(3174, 2, 20, '30.00', '2018-01-23 16:56:10', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1909),
(3175, 2, 21, '30.00', '2018-01-23 16:56:44', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1910),
(3176, 2, 22, '30.00', '2018-01-23 16:56:54', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1911),
(3177, 1, 23, '30.00', '2018-01-23 16:57:18', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1912),
(3178, 4, 24, '120.00', '2018-01-23 16:59:08', 1, '2018-01-23', '120.00', '0.00', '0.00', 'paid', '0.00', 1913),
(3179, 1, 25, '30.00', '2018-01-23 17:00:04', 1, '2018-01-23', '30.00', '0.00', '0.00', 'paid', '0.00', 1914),
(3180, 4, 26, '30.00', '2018-01-26 03:58:13', 1, '2018-01-26', '30.00', '0.00', '0.00', 'paid', '0.00', 1915),
(3181, 1, 27, '30.00', '2018-01-26 04:20:10', 1, '2018-01-26', '30.00', '0.00', '0.00', 'paid', '0.00', 1916),
(3182, 1, 28, '120.00', '2018-01-26 04:23:46', 1, '2018-01-26', '120.00', '0.00', '0.00', 'paid', '0.00', 1917),
(3183, 1, 29, '120.00', '2018-01-26 04:24:22', 1, '2018-01-26', '120.00', '0.00', '0.00', 'paid', '0.00', 1918),
(3184, 1, 30, '120.00', '2018-01-26 04:27:17', 1, '2018-01-26', '120.00', '0.00', '0.00', 'paid', '0.00', 1919),
(3185, 1, 31, '120.00', '2018-01-26 04:27:29', 1, '2018-01-26', '120.00', '0.00', '0.00', 'paid', '0.00', 1920),
(3186, 1, 1, '300.00', '2018-01-26 04:28:15', 1, '2018-01-26', '300.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3187, 1, 2, '120.00', '2018-01-26 06:15:17', 1, '2018-01-26', '120.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3188, 1, 3, '0.00', '2018-01-27 06:19:50', 1, '2018-01-27', '0.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3189, 1, 4, '0.00', '2018-01-25 22:22:55', 1, '2018-01-25', '0.00', '0.00', '0.00', 'paid', '0.00', 1904),
(3190, 5, 1, '600.00', '2018-01-25 22:31:18', 1, '2018-01-25', '600.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3191, 6, 2, '150.00', '2018-01-25 22:32:03', 1, '2018-01-25', '150.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3192, 7, 3, '900.00', '2018-01-25 22:33:45', 1, '2018-01-25', '900.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3193, 1, 4, '30.00', '2018-01-27 01:05:11', 1, '2018-01-27', '30.00', '0.00', '0.00', 'paid', '0.00', 1904),
(3194, 0, 3, '390.00', '2018-02-04 12:23:18', 6, '2018-02-04', '390.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3195, 6, 4, '10.00', '2018-02-04 12:25:15', 6, '2018-02-04', '10.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3196, 1, 5, '300.00', '2018-02-04 12:26:04', 6, '2018-02-04', '300.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3197, 1, 1, '300.00', '2018-02-04 12:24:27', 6, '2018-02-04', '300.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3198, 1, 1, '300.00', '2018-02-04 12:26:33', 6, '2018-02-04', '300.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3199, 1, 2, '150.00', '2018-02-04 12:28:06', 6, '2018-02-04', '150.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3200, 1, 1, '150.00', '2018-02-04 12:29:05', 6, '2018-02-04', '150.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3201, 1, 2, '150.00', '2018-02-04 12:35:16', 6, '2018-02-04', '150.00', '0.00', '0.00', 'paid', '0.00', 1904),
(3202, 2, 3, '1200.00', '2018-02-04 12:40:48', 6, '2018-02-04', '1200.00', '0.00', '0.00', 'paid', '0.00', 1905),
(3203, 5, 4, '500.00', '2018-01-23 12:41:30', 6, '2018-01-23', '500.00', '0.00', '0.00', 'paid', '0.00', 1906),
(3204, 5, 5, '200.00', '2018-01-23 12:42:16', 6, '2018-01-23', '200.00', '0.00', '0.00', 'paid', '0.00', 1906),
(3205, 6, 6, '30.00', '2018-02-13 00:57:56', 1, '2018-02-13', '30.00', '0.00', '0.00', 'paid', '0.00', 1907),
(3206, 1, 7, '1.00', '2018-02-13 00:59:12', 1, '2018-02-13', '1.00', '0.00', '0.00', 'paid', '0.00', 1908),
(3207, 5, 8, '200.00', '2018-01-02 01:07:00', 1, '2018-01-02', '200.00', '0.00', '0.00', 'paid', '0.00', 1909),
(3208, 5, 9, '200.00', '2018-02-16 15:16:27', 1, '2018-02-16', '200.00', '0.00', '0.00', 'paid', '0.00', 1910),
(3209, 8, 10, '200.00', '2018-02-16 21:30:09', 1, '2018-02-16', '200.00', '0.00', '0.00', 'paid', '0.00', 1911),
(3210, 8, 11, '280.00', '2018-02-16 21:40:06', 1, '2018-02-16', '280.00', '0.00', '0.00', 'paid', '0.00', 1912),
(3211, 1, 12, '10.00', '2018-03-02 00:07:37', 1, '2018-03-02', '10.00', '0.00', '0.00', 'paid', '0.00', 1913),
(3212, 1, 12, '150.00', '2018-02-24 07:25:34', 1, '2018-02-24', '150.00', '0.00', '0.00', 'paid', '0.00', 1914),
(3213, 1, 13, '380.00', '2018-02-24 07:27:48', 1, '2018-02-24', '380.00', '0.00', '0.00', 'paid', '0.00', 1915),
(3214, 1, 14, '10.00', '2018-02-24 23:10:14', 1, '2018-02-24', '10.00', '0.00', '0.00', 'paid', '0.00', 1916),
(3215, 8, 15, '10.00', '2018-02-24 23:10:43', 1, '2018-02-24', '10.00', '0.00', '0.00', 'paid', '0.00', 1917),
(3216, 1, 16, '45.00', '2018-02-25 21:52:33', 1, '2018-02-25', '45.00', '0.00', '0.00', 'paid', '0.00', 1918),
(3217, 7, 17, '30.00', '2018-02-27 05:07:20', 1, '2018-02-27', '30.00', '0.00', '0.00', 'paid', '0.00', 1919),
(3218, 7, 18, '20.00', '2018-03-02 15:40:07', 1, '2018-03-02', '20.00', '0.00', '0.00', 'paid', '0.00', 1920),
(3219, 6, 19, '300.00', '2018-03-02 15:40:33', 1, '2018-03-02', '300.00', '0.00', '0.00', 'paid', '0.00', 1921),
(3220, 7, 20, '20.00', '2018-03-10 20:15:23', 1, '2018-03-10', '20.00', '0.00', '0.00', 'paid', '0.00', 1922),
(3221, 5, 21, '10.00', '2018-03-11 18:19:26', 2, '2018-03-11', '10.00', '0.00', '0.00', 'paid', '0.00', 1923),
(3222, 0, 22, '20.00', '2018-03-20 16:13:54', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1924),
(3223, 2, 23, '30.00', '2018-03-20 16:23:58', 2, '2018-03-20', '30.00', '0.00', '0.00', 'paid', '0.00', 1925),
(3224, 1, 24, '20.00', '2018-03-20 16:25:43', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1926),
(3225, 5, 25, '0.00', '2018-03-20 16:26:35', 2, '2018-03-20', '0.00', '0.00', '0.00', 'paid', '0.00', 1927),
(3226, 5, 26, '20.00', '2018-03-20 16:26:58', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1928),
(3227, 7, 27, '50.00', '2018-03-20 16:27:23', 2, '2018-03-20', '50.00', '0.00', '0.00', 'paid', '0.00', 1929),
(3228, 2, 28, '20.00', '2018-03-20 16:29:34', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1930),
(3229, 5, 29, '20.00', '2018-03-20 16:32:25', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1931),
(3230, 6, 30, '10.00', '2018-03-20 16:33:40', 2, '2018-03-20', '10.00', '0.00', '0.00', 'paid', '0.00', 1932),
(3231, 5, 31, '20.00', '2018-03-20 16:34:53', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1933),
(3232, 6, 32, '20.00', '2018-03-20 16:39:11', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1934),
(3233, 6, 33, '20.00', '2018-03-20 16:40:19', 2, '2018-03-20', '20.00', '0.00', '0.00', 'paid', '0.00', 1935),
(3234, 6, 0, '10.00', '2018-06-16 18:21:53', 2, '2018-06-16', '10.00', '0.00', '0.00', 'paid', '0.00', 1936),
(3235, 2, 0, '120.00', '2018-06-16 18:27:41', 2, '2018-06-16', '120.00', '0.00', '0.00', 'paid', '0.00', 1937),
(3236, 5, 0, '15.00', '2018-06-16 18:37:54', 2, '2018-06-16', '15.00', '0.00', '0.00', 'paid', '0.00', 1938),
(3237, 1, 1, '60.00', '2018-06-16 18:47:20', 2, '2018-06-16', '60.00', '0.00', '0.00', 'paid', '0.00', 1901),
(3238, 2, 2, '150.00', '2018-06-16 18:52:38', 2, '2018-06-16', '150.00', '0.00', '0.00', 'paid', '0.00', 1902),
(3239, 7, 3, '1500.00', '2018-06-16 18:57:37', 2, '2018-06-16', '1500.00', '0.00', '0.00', 'paid', '0.00', 1903),
(3240, 8, 4, '400.00', '2018-06-16 19:10:06', 2, '2018-06-16', '400.00', '0.00', '0.00', 'paid', '0.00', 1904),
(3241, 0, 5, '500.00', '2018-06-24 21:26:12', 2, '2018-06-24', '500.00', '0.00', '0.00', 'paid', '0.00', 1905),
(3242, 0, 6, '100.00', '2018-06-24 21:29:47', 2, '2018-06-24', '100.00', '0.00', '0.00', 'paid', '0.00', 1906),
(3243, 0, 7, '10.00', '2018-06-24 21:32:40', 2, '2018-06-24', '10.00', '0.00', '0.00', 'paid', '0.00', 1907),
(3244, 0, 8, '30.00', '2018-06-24 21:33:59', 2, '2018-06-24', '30.00', '0.00', '0.00', 'paid', '0.00', 1908),
(3245, 1, 9, '10.00', '2018-06-24 21:51:50', 2, '2018-06-24', '10.00', '0.00', '0.00', 'paid', '0.00', 1909),
(3246, 2, 10, '300.00', '2018-06-25 13:13:43', 2, '2018-06-25', '300.00', '0.00', '0.00', 'paid', '0.00', 1910),
(3247, 1, 11, '150.00', '2018-07-07 23:59:29', 2, '2018-07-07', '150.00', '0.00', '0.00', 'paid', '0.00', 1911),
(3248, 2, 12, '30.00', '2018-07-08 00:06:14', 2, '2018-07-08', '30.00', '0.00', '0.00', 'paid', '0.00', 1912),
(3249, 2, 13, '300.00', '2018-07-08 00:07:05', 2, '2018-07-08', '300.00', '0.00', '0.00', 'paid', '0.00', 1913),
(3250, 5, 14, '1500.00', '2018-07-08 00:08:56', 2, '2018-07-08', '1500.00', '0.00', '0.00', 'paid', '0.00', 1914),
(3251, 1, 15, '150.00', '2018-07-08 00:10:18', 2, '2018-07-08', '150.00', '0.00', '0.00', 'paid', '0.00', 1915),
(3252, 8, 16, '20.00', '2018-07-08 08:12:07', 2, '2018-07-08', '20.00', '0.00', '0.00', 'paid', '0.00', 1916),
(3253, 1, 17, '10.00', '2018-07-08 08:16:14', 2, '2018-07-08', '10.00', '0.00', '0.00', 'paid', '0.00', 1917),
(3254, 6, 18, '20.00', '2018-07-08 11:37:03', 2, '2018-07-08', '20.00', '0.00', '0.00', 'paid', '0.00', 1918),
(3255, 0, 19, '15.00', '2018-07-18 06:57:04', 2, '2018-07-18', '15.00', '0.00', '0.00', 'paid', '0.00', 1919),
(3256, 6, 20, '100.00', '2018-07-17 10:34:33', 2, '2018-07-17', '100.00', '0.00', '0.00', 'paid', '0.00', 1920),
(3257, 1, 21, '150.00', '2018-07-17 11:05:40', 2, '2018-07-17', '150.00', '0.00', '0.00', 'paid', '0.00', 1921),
(3258, 0, 22, '30.00', '2018-07-17 11:45:15', 2, '2018-07-17', '30.00', '0.00', '0.00', 'paid', '0.00', 1922),
(3259, 0, 23, '0.00', '2018-07-17 23:41:36', 2, '2018-07-17', '0.00', '0.00', '0.00', 'paid', '0.00', 1923),
(3260, 0, 24, '0.00', '2018-07-17 23:46:00', 2, '2018-07-17', '0.00', '0.00', '0.00', 'paid', '0.00', 1924),
(3261, 0, 25, '30.00', '2018-07-17 23:46:38', 2, '2018-07-17', '30.00', '0.00', '0.00', 'paid', '0.00', 1925),
(3262, 0, 26, '1500.00', '2018-07-17 23:57:13', 2, '2018-07-17', '1500.00', '0.00', '0.00', 'paid', '0.00', 1926),
(3263, 0, 27, '165.00', '2018-07-18 00:31:41', 2, '2018-07-18', '165.00', '0.00', '0.00', 'paid', '0.00', 1927),
(3264, 0, 28, '130.00', '2018-07-18 00:35:44', 2, '2018-07-18', '130.00', '0.00', '0.00', 'paid', '0.00', 1928),
(3265, 0, 29, '120.00', '2018-07-23 23:36:29', 2, '2018-07-23', '120.00', '0.00', '0.00', 'paid', '0.00', 1929);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` int(11) NOT NULL,
  `description` varchar(150) NOT NULL,
  `rate` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `description`, `rate`) VALUES
(1, 'Manager', 30),
(2, 'Cashier', 20),
(3, 'Refiller', 16),
(4, 'Janitor', 14),
(5, 'Delivery Man', 15),
(6, 'asd', 5);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `serial` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_name`, `serial`) VALUES
(1, 'Alkaline Drinking Water', 'JIN364701'),
(2, 'Mineral Drinking Water', 'JIN364702'),
(3, 'Purified Drinking Water', 'JIN364703');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_tendered` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `amount_due` decimal(10,2) NOT NULL,
  `cash_change` decimal(10,2) NOT NULL,
  `date_added` datetime NOT NULL,
  `modeofpayment` varchar(15) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `cust_id`, `user_id`, `cash_tendered`, `discount`, `amount_due`, `cash_change`, `date_added`, `modeofpayment`, `admin_id`, `total`, `qty`) VALUES
(1, 1, 2, '60.00', '0.00', '60.00', '0.00', '2018-06-16 18:47:20', 'cash', 2, '60.00', 1),
(2, 2, 2, '200.00', '0.00', '150.00', '50.00', '2018-06-16 18:52:38', 'cash', 2, '150.00', 10),
(3, 7, 2, '2000.00', '0.00', '1500.00', '500.00', '2018-06-16 18:57:37', 'cash', 2, '1500.00', 10),
(4, 8, 2, '400.00', '0.00', '400.00', '0.00', '2018-06-16 19:10:06', 'cash', 2, '400.00', 20),
(5, 0, 2, '1000.00', '0.00', '500.00', '500.00', '2018-06-24 21:26:12', 'cash', 2, '500.00', 50),
(6, 0, 2, '200.00', '0.00', '100.00', '100.00', '2018-06-24 21:29:47', 'cash', 2, '100.00', 10),
(7, 0, 2, '10.00', '0.00', '10.00', '0.00', '2018-06-24 21:32:40', 'cash', 2, '10.00', 1),
(8, 0, 2, '30.00', '0.00', '30.00', '0.00', '2018-06-24 21:33:59', 'cash', 2, '30.00', 1),
(9, 1, 2, '10.00', '0.00', '10.00', '0.00', '2018-06-24 21:51:50', 'cash', 2, '10.00', 1),
(10, 2, 2, '300.00', '0.00', '300.00', '0.00', '2018-06-25 13:13:43', 'cash', 2, '300.00', 10),
(12, 2, 2, '30.00', '0.00', '30.00', '0.00', '2018-07-08 00:06:14', 'cash', 2, '30.00', 1),
(13, 2, 2, '300.00', '0.00', '300.00', '0.00', '2018-07-08 00:07:05', 'cash', 2, '300.00', 10),
(14, 5, 2, '2000.00', '0.00', '1500.00', '500.00', '2018-07-08 00:08:56', 'cash', 2, '1500.00', 10),
(15, 1, 2, '200.00', '0.00', '150.00', '50.00', '2018-07-08 00:10:18', 'cash', 2, '150.00', 1),
(16, 8, 2, '20.00', '0.00', '20.00', '0.00', '2018-07-08 08:12:07', 'cash', 2, '20.00', 1),
(17, 1, 2, '10.00', '0.00', '10.00', '0.00', '2018-07-08 08:16:14', 'cash', 2, '10.00', 1),
(18, 6, 2, '20.00', '0.00', '20.00', '0.00', '2018-07-08 11:37:03', 'cash', 2, '20.00', 1),
(19, 0, 2, '0.00', '0.00', '15.00', '0.00', '2018-07-18 06:57:04', 'cash', 2, '15.00', 1),
(20, 6, 2, '100.00', '0.00', '100.00', '0.00', '2018-07-17 10:34:33', 'cash', 2, '100.00', 5),
(21, 1, 2, '0.00', '0.00', '150.00', '0.00', '2018-07-17 11:05:40', 'cash', 2, '150.00', 0),
(22, 0, 2, '30.00', '0.00', '30.00', '0.00', '2018-07-17 11:45:15', 'cash', 2, '30.00', 1),
(23, 0, 2, '0.00', '0.00', '0.00', '0.00', '2018-07-17 23:41:36', 'cash', 2, '0.00', 0),
(24, 0, 2, '0.00', '0.00', '0.00', '0.00', '2018-07-17 23:46:00', 'cash', 2, '0.00', 0),
(25, 0, 2, '30.00', '0.00', '30.00', '0.00', '2018-07-17 23:46:38', 'cash', 2, '30.00', 1),
(26, 0, 2, '2000.00', '0.00', '1500.00', '500.00', '2018-07-17 23:57:13', 'cash', 2, '1500.00', 10),
(27, 0, 2, '165.00', '0.00', '165.00', '0.00', '2018-07-18 00:31:41', 'cash', 2, '165.00', 1),
(28, 0, 2, '200.00', '0.00', '130.00', '70.00', '2018-07-18 00:35:44', 'cash', 2, '130.00', 1),
(29, 0, 2, '120.00', '0.00', '120.00', '0.00', '2018-07-23 23:36:29', 'cash', 2, '120.00', 4);

-- --------------------------------------------------------

--
-- Table structure for table `sales_details`
--

CREATE TABLE `sales_details` (
  `sales_details_id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `transaction_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_details`
--

INSERT INTO `sales_details` (`sales_details_id`, `sales_id`, `prod_id`, `price`, `qty`, `product`, `transaction_code`) VALUES
(1, 1, 4, '30.00', 1, 'Alkaline Drinking Water', ''),
(2, 1, 4, '30.00', 1, 'Mineral Drinking Water', ''),
(3, 2, 2, '15.00', 10, 'Alkaline Drinking Water', ''),
(4, 3, 4, '150.00', 10, 'Alkaline Drinking Water', ''),
(5, 4, 3, '20.00', 20, 'Mineral Drinking Water', ''),
(6, 5, 1, '10.00', 50, 'Alkaline Drinking Water', ''),
(7, 6, 1, '10.00', 10, 'Alkaline Drinking Water', ''),
(8, 7, 1, '10.00', 1, 'Alkaline Drinking Water', ''),
(9, 8, 4, '30.00', 1, 'Alkaline Drinking Water', ''),
(10, 9, 1, '10.00', 1, 'Alkaline Drinking Water', ''),
(11, 10, 4, '30.00', 10, 'Alkaline Drinking Water', ''),
(12, 11, 4, '150.00', 1, 'Alkaline Drinking Water', ''),
(13, 14, 4, '150.00', 10, 'Mineral Drinking Water', ''),
(14, 15, 4, '150.00', 1, 'Mineral Drinking Water', ''),
(15, 16, 3, '20.00', 1, 'Mineral Drinking Water', ''),
(16, 17, 1, '10.00', 1, 'Alkaline Drinking Water', ''),
(17, 18, 3, '20.00', 1, 'Mineral Drinking Water', ''),
(18, 19, 2, '15.00', 1, 'Alkaline Drinking Water', ''),
(19, 20, 3, '20.00', 5, 'Alkaline Drinking Water', ''),
(20, 22, 4, '30.00', 1, 'Alkaline Drinking Water', ''),
(21, 25, 4, '30.00', 1, 'Alkaline Drinking Water', ''),
(22, 26, 4, '150.00', 10, 'Mineral Drinking Water', ''),
(23, 27, 4, '150.00', 1, 'Mineral Drinking Water', ''),
(24, 27, 2, '15.00', 1, 'Mineral Drinking Water', ''),
(25, 28, 4, '30.00', 1, 'Mineral Drinking Water', 'GJO798326401'),
(26, 28, 3, '20.00', 5, 'Mineral Drinking Water', 'GJO798326401'),
(27, 29, 4, '30.00', 4, 'Mineral Drinking Water', 'ZTY487326109');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `time_in`, `time_out`) VALUES
(1, '08:00:00', '17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `stockin`
--

CREATE TABLE `stockin` (
  `stockin_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `qty` int(6) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stockin`
--

INSERT INTO `stockin` (`stockin_id`, `prod_id`, `qty`, `date`) VALUES
(1, 3, 34, '2018-07-08 00:54:05'),
(2, 1, 100, '2018-02-04 07:31:57'),
(3, 2, 100, '2018-02-04 07:32:05'),
(4, 3, 100, '2018-02-04 07:32:16'),
(5, 4, 100, '2018-02-04 07:32:47'),
(6, 5, 100, '2018-02-04 07:32:57'),
(7, 6, 100, '2018-02-04 07:33:05'),
(8, 4, 90, '2018-02-16 21:34:07'),
(9, 1, 10, '2018-02-16 21:37:13'),
(10, 4, 10, '2018-02-24 07:26:50'),
(11, 6, -1, '2018-02-25 21:53:03'),
(12, 1, 100, '2018-03-20 16:46:55'),
(13, 2, 100, '2018-03-20 16:47:23'),
(14, 4, 100, '2018-03-20 16:47:40'),
(15, 5, 100, '2018-03-20 16:47:49'),
(16, 6, 100, '2018-03-20 16:47:58'),
(17, 2, 4, '2018-07-08 01:15:40');

-- --------------------------------------------------------

--
-- Table structure for table `temp_trans`
--

CREATE TABLE `temp_trans` (
  `temp_trans_id` varchar(20) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `product` varchar(100) NOT NULL,
  `stat` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `term`
--

CREATE TABLE `term` (
  `term_id` int(11) NOT NULL,
  `sales_id` int(11) DEFAULT NULL,
  `payable_for` varchar(10) NOT NULL,
  `term` varchar(11) NOT NULL,
  `due` decimal(10,2) NOT NULL,
  `payment_start` date NOT NULL,
  `down` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `interest` decimal(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `term`
--

INSERT INTO `term` (`term_id`, `sales_id`, `payable_for`, `term`, `due`, `payment_start`, `down`, `due_date`, `interest`, `status`) VALUES
(1, 8, '4', 'monthly', '113.30', '2017-02-21', '113.30', '2017-06-21', '16.50', ''),
(2, 9, '4', 'monthly', '113.30', '2017-02-21', '113.30', '2017-06-21', '16.50', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `5g_price`
--
ALTER TABLE `5g_price`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashadvance`
--
ALTER TABLE `cashadvance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `deductions`
--
ALTER TABLE `deductions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`events_details_id`);

--
-- Indexes for table `events_details`
--
ALTER TABLE `events_details`
  ADD PRIMARY KEY (`events_id`);

--
-- Indexes for table `history_log`
--
ALTER TABLE `history_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `overtime`
--
ALTER TABLE `overtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `sales_details`
--
ALTER TABLE `sales_details`
  ADD PRIMARY KEY (`sales_details_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockin`
--
ALTER TABLE `stockin`
  ADD PRIMARY KEY (`stockin_id`);

--
-- Indexes for table `term`
--
ALTER TABLE `term`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `5g_price`
--
ALTER TABLE `5g_price`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cashadvance`
--
ALTER TABLE `cashadvance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `deductions`
--
ALTER TABLE `deductions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `events_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `events_details`
--
ALTER TABLE `events_details`
  MODIFY `events_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `history_log`
--
ALTER TABLE `history_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `overtime`
--
ALTER TABLE `overtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3266;
--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `sales_details`
--
ALTER TABLE `sales_details`
  MODIFY `sales_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stockin`
--
ALTER TABLE `stockin`
  MODIFY `stockin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `term`
--
ALTER TABLE `term`
  MODIFY `term_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
