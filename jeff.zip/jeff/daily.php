<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app" ng-controller="myController">
  <head>
    <title><?php require'account.php'; echo $name;?></title>
    <?php include('include/head_scripts.php');?>
    <link rel="stylesheet" type="text/css" href="js/gritter/css/jquery.gritter.css" />
    <script type="text/javascript" src="searchScript.js"></script>

    <script type="text/javascript">
      $(document).ready(function () {
        var unique_id = $.gritter.add({
          title: 'Welcome',
          text: '<h5><?php require'account.php'; echo $name;?> !</h5>',
          image: 'images/users.png',
          sticky: false,
          time: '',
          class_name: 'my-sticky-class'
        });

        return false;
      });
    </script>
  </head> 
  <body>

    <div class="page-container">
      <?php include('include/cashier_header.php');?>
      <?php include('include/logout_modal.php');?>

      <div class="content">
        <div class="mother-grid-inner" style="padding-top: 80px;">
	        <ol class="breadcrumb well">
            <li class="breadcrumb-item">
              <a href="daily.php">Home</a> <i class="fa fa-angle-right"></i> Sales
            </li>
          </ol>

          <section class="content breadcrumb well">
            <div class="row">
        <div class="col-lg-3 col-xs-6">

        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
                        <h3>Deliver</h3>
                        <br>
            </div>
            <div class="icon">
              <i class="fa fa-truck"></i>
            </div>
            <a href="deliver_form.php" class="small-box-footer" style="padding-top: 10px; padding-bottom: 10px;">Get Started <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
                        <h3>Direct</h3>
                        <br>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="cash_transaction.php?cust_id=<?php echo '0'; ?>&trans_id=<?php echo '0';?>" class="small-box-footer" style="padding-top: 10px; padding-bottom: 10px;">Get Started <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          
        </div>
      </div>
      <div class="row">
        <div class="col-xs-6">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Sales Chart (<?php echo date("Y") ?>)</h3>
              <div class="box-tools">
                <?php include 'year.php'; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xs-6">
          <section>
              <?php
                include 'config.php';
                try{
                  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                  echo "
                        <div style='background: transparent !important'>
                        <div class='panel-heading'>"; 
              ?>
                        <a href="./notes/" onclick="centeredPopup(this.href,'Add Notes','470','540','no');return false"><button class="myButton btn btn-theme pull-right"><i class='fa fa-edit fa-fw'></i> Add Notes</button></a>
              <?php
                echo "</div>";
                echo '<div class="notes"><ul style="float: left;">';
                $getnotes = $conn->prepare(" SELECT * FROM NOTES ORDER BY ID DESC");
                $getnotes->execute();
                while ($row = $getnotes->fetch(PDO::FETCH_ASSOC)){
                  $id = $row['ID'];
                  $title = $row['TITLE'];
                  $texts = $row['TEXT'];
                  echo "<li>";
              ?>
              <a href="./notes/edit.php?notesid=<?php echo $id ?>" onclick="centeredPopup(this.href,'Add Notes','470','590','no');return false">
              <?php
                echo "<h2>".htmlentities($title)."</h2><p>".htmlentities($texts)."</p></a></li>";}} 
                catch (PDOException $e){echo "Connection failed: " . $e->getMessage();}
                $conn = null;
              ?>
            </section>
        </div>
      </div>
          </section>
        </div>
      </div>
    <div class="noprint"><?php include('include/cashier_footer.php');?></div>
    <script src="js/angular.min.js"></script>

    <script src="js/gritter/js/jquery.gritter.js"></script>
    <script src="js/gritter-conf.js"></script>
    <script language="javascript">
            var popupWindow = null;
            function centeredPopup(url,winName,w,h,scroll){
              LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
              TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
              settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
              popupWindow = window.open(url,winName,settings)}
          </script>
  </body>
</html>