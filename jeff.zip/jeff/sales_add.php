<?php 
	require_once 'connect.php';
	include('valid.php');
	$id=$_SESSION['admin_id'];
	$discount = $_POST['discount'];
	$amount_due = $_POST['amount_due'];
	$trans = $_POST['trans'];
	
	$date = date("Y-m-d H:i:s");
	$cid='0';
	
	$total=$amount_due-$discount;
	$cid='0';

		$tendered = $_POST['tendered'];
		$change = $_POST['change'];

	if (isset($_POST['complete'])) {
		$quan=mysqli_query($conn,"SELECT * FROM temp_trans")or die(mysqli_error($conn));
		$row=mysqli_fetch_array($quan);
		$qty=$row['qty'];

		mysqli_query($conn,"INSERT INTO sales(cust_id,user_id,discount,amount_due,total,date_added,modeofpayment,cash_tendered,cash_change,admin_id,qty) 
	VALUES('$cid','$id','$discount','$amount_due','$total','$date','cash','$tendered','$change','$id','$qty')")or die(mysqli_error($conn));
		
	$sales_id=mysqli_insert_id($conn);
	$_SESSION['sid']=$sales_id;
	$query=mysqli_query($conn,"SELECT * FROM temp_trans")or die(mysqli_error($conn));
		while ($row=mysqli_fetch_array($query))
		{
			$pid=$row['prod_id'];	
 			$qty=$row['qty'];
			$price=$row['price'];
			$prod=$row['product'];
			
			
			
			mysqli_query($conn,"INSERT INTO sales_details(prod_id,qty,price,sales_id,product,transaction_code) VALUES('$pid','$qty','$price','$sales_id','$prod','$trans')")or die(mysqli_error($conn));
			mysqli_query($conn,"UPDATE inventory SET prod_qty=prod_qty-'$qty' where prod_id='$pid'") or die(mysqli_error($conn)); 
		
		}
		
		$query1=mysqli_query($conn,"SELECT or_no FROM payment NATURAL JOIN sales WHERE modeofpayment =  'cash' ORDER BY payment_id DESC LIMIT 0 , 1")or die(mysqli_error($conn));

			$row1=mysqli_fetch_array($query1);
				$or=$row1['or_no'];	

				if ($or==0)
				{
					$or=1901;
				}
				else
				{
					$or=$or+1;
				}

				mysqli_query($conn,"INSERT INTO payment(cust_id,user_id,payment,payment_date,payment_for,due,status,sales_id,or_no) 
	VALUES('$cid','$id','$total','$date','$date','$total','paid','$sales_id','$or')")or die(mysqli_error($con));
				//echo "<script>document.location='receipt.php?cid=$cid'</script>";  	
		
		$result=mysqli_query($conn,"DELETE FROM temp_trans where temp_trans_id='$trans'")	or die(mysqli_error($conn));
		echo "<script>document.location='receipt.php?cid=$cid'</script>";  	

	}	
	
?>