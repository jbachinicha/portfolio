<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app">
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('employee').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
<script src="js/angular.min.js"></script>
<style type="text/css">
      .errortext{
        color:red;
      }
    </style>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Employee <i class="fa fa-angle-right"></i> Employee List </li>
    </ol>


			<div class = "col-lg-12 well breadcrumb" style = "margin-top:60px;">
					<a class="btn btn-danger" href="manage_employee.php" style="color:#fff;"><i class="fa fa-arrow-left text-blue" style="color: #fff"></i> Back</a>
          <h3>Employee List</h3>
					<div id = "admin_table">
						<table id = "example1" class = "table table-bordered">
							<thead class = "alert">
								<tr>
                  <th>Image</th>
									<th>Employee Id</th>
									<th>Firstname</th>
									<th>Lastname</th>
									<th>Address</th>
									<th>Phone</th>
									<th>Date Emloyed</th>
									<th>Position</th>
                  <th>Schedule</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
							<?php
								$q_admin = $conn->query("SELECT * FROM employee e JOIN position p JOIN schedules s WHERE e.position_id=p.id AND e.schedule_id=s.id") or die(mysqli_error());
								while($f_admin = $q_admin->fetch_array()){
									
							?>	
								<tr class = "target table-row">
                  <td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><img style="width:80px;height:60px" src="dist/uploads/<?php echo $f_admin['pic'];?>"></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['employee_id']?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo ($f_admin['first_name'])?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['last_name']?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['address']?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['phone']?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['date_employed']?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo $f_admin['description']?></td>
                  <td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>"><?php echo date('h:i A', strtotime($f_admin['time_in'])).' - '.date('h:i A', strtotime($f_admin['time_out'])); ?></td>
									<td class="eadmin_id" value = "<?php echo $f_admin['employee_id']?>">
                    <?php 
                      if ($f_admin['status']=='Hired') {
                        echo "<a href = '#'' class = 
                        'btn btn-success'><span class = 'fa fa-check'></span>Hired</a>";
                      }
                      else{
                        echo "<a href = '#'' class = 
                        'btn btn-danger'><span class = 'fa fa-close'></span>Fired</a>";
                      }
?>
                    
                  </td>
								</tr>
							<?php
								}
							?>	
							</tbody>
						</table>
					</div>
          <div id="edit_form">
              
            </div>
          <div id="account_form">
              
            </div>

			</div>
</div>
<script>
  var app = angular.module('app', []);
app.controller('myController', function($scope){
  $scope.valid = false;
  $scope.submit = function(){
    $scope.valid = true;
  }
  $scope.close = function(){
    $scope.valid = false;
  }
});
</script>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>

</body>
</html>