	<div class="modal fade" id="stock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Add New Stock</h4>
                  </div>
                  <div class="modal-body">
                   	<form method="post" action="add_stock.php" enctype='multipart/form-data' name="add_stock" novalidate="">
                   		<div class="form-group">
          					<div class="col-lg-12">
          						<label>Item Name:</label>
              				<select class="form-control" name="prod_name"  required>
                        <option>-- Select item Name --</option>
                					<?php
              					$query2=mysqli_query($conn,"SELECT * from inventory")or die(mysqli_error());
               					 while($row2=mysqli_fetch_array($query2)){
                				?>
                  				<option value="<?php echo $row2['prod_id'];?>"><?php echo $row2['prod_name'];?></option>
                				<?php }?>
              				</select>
          				</div>
          			</div>
          				<div class="form-group">
          					<div class="col-lg-12">
          				<label>Quantity:</label>
            				<input type="number" class="form-control" id="qty" name="qty" placeholder="Quantity" ng-model="item.qty" required>
          				</div>
        				</div>
        				<div class="form-group modal-footer">
                   			 <button type="submit" name="submit" class="btn btn-theme" ng-disabled="add_stock.$invalid" ng-click="submit()">Order</button>
                		</div>
                   	</form>
                  </div>
                </div>
              </div>
            </div>

            <div class="modal fade" id="stockin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Stock in List</h4>
                  </div>
                  <div class="modal-body">
                  	<section class="content breadcrumb">
            <div class="row">
            
            <div class="col-xs-12">
              <div class="box box-primary"><!-- /.box-header -->
                <div class="box-body">
                  <table id="example3" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Product Name</th>
                        <th>Qty</th>
				        <th>Date Delivered</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
		$query=mysqli_query($conn,"select * from stockin natural join inventory order by date desc")or die(mysqli_error());
		while($row=mysqli_fetch_array($query)){
		
?>
                      <tr>
                        <td><?php echo $row['prod_name'];?></td>
                        <td><?php echo $row['qty'];?></td>
            						<td><?php echo $row['date'];?></td>
                      
                      </tr>
                   
<?php }?>					  
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	  
            
          </section>
                  </div>
                </div>
              </div>
            </div>