						<div class="modal fade" id="history" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">History Log</h4>
                  </div>
                  <div class="modal-body">
                  	<table id="table2" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Log</th>
                      </tr>
                    </thead>
                    <tbody>
							<?php
								$query=mysqli_query($conn,"SELECT * FROM history_log natural join admin WHERE user_id = admin_id ORDER BY date")or die(mysqli_error());
								while($row=mysqli_fetch_array($query)){
		
						?>
                      <tr>
                      <td>	<?php echo $row['firstname']." ".$row['lastname']." ".$row['action']." last ".$row['date'];?></td>
                       
                      </tr>
				   	  		<?php }?>					  
                    </tbody>
                  </table>
                  </div>
                </div>
              </div>
            </div>