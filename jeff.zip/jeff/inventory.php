<!DOCTYPE HTML>
<?php
	require_once 'valid.php';
?>	
<html ng-app="app" ng-controller="myController">
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('inventory').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 

<body>
   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
	   <div class="mother-grid-inner" style="padding-top: 80px;">
<!--heder end here-->
		<ol class="breadcrumb noprint well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Inventory</li>
    </ol>

	<div id="poduct_details" class = "col-lg-12 well breadcrumb" style = "margin-top:-20px;">
              <a class="btn btn-theme" href="#add" data-toggle="modal" data-target="#stock" style="color:#fff;"><i class="glyphicon glyphicon-plus text-blue" style="color: #fff"></i> Add Stock</a>
              <!-- <a class="btn btn-theme" href="stock_in.php" style="color:#fff;"><i class="fa fa-wrench" style="color: #fff"></i> Equipment List</a> -->

        <table id="example1" class="table table-bordered table-striped">
                    <thead class="alert">
                      <tr>
                      	<th>Picture</th>
                        <th>Item Code</th>
                        <th>Item Name</th>
                        <th>Qty</th>
            			<th>Price</th>
            			<th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
		
		$query=mysqli_query($conn,"SELECT * FROM inventory")or die(mysqli_error());
		while($row=mysqli_fetch_array($query)){
		$qty=$row['prod_qty'];
    $re=$row['reorder'];
?>
                      <tr class="table-row">
                      	<td><img style="width:80px;height:60px" src="dist/uploads/<?php echo $row['prod_pic'];?>"></td>
                        <td><?php echo $row['serial'];?></td>
                        <td><?php echo $row['prod_name'];?></td>
                        <td><?php echo $row['prod_qty'];?></td>
            			<td><?php echo number_format($row['prod_price'],2);?></td>
            			<td width="10%">
                    <?php 
                      if ($row['prod_qty']<=$row['reorder']){ ?>

                        <a href="#reorder<?php echo $row['prod_id'];?>" data-target="#reorder<?php echo $row['prod_id'];?>" data-toggle="modal" class="btn btn-danger eadmin_id"><span class = "fa fa-refresh"></span>Reorder</a>

                     <?php }?></td>
                        <td width="10%">
				<a href="#updateordinance<?php echo $row['prod_id'];?>" data-target="#updateordinance<?php echo $row['prod_id'];?>" data-toggle="modal" class="btn btn-theme eadmin_id"><span class = "fa fa-edit"></span>Update</a>
			
						</td>
                      </tr>
<?php include('modal/update_product_modal.php'); ?>                   
<?php }?>					  
                    </tbody>
                  </table>

	</div>
<?php include('modal/inventory_modal.php'); ?>
    
</div>
</div>
  <!--//content-inner-->
		<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    <script type = "text/javascript">
		$(document).ready(function(){
			$result = $('<center><label>Deleting...</label></center>');
			$('.deladmin_id').click(function(){
				$admin_id = $(this).attr('value');
				$(this).parents('td').empty().append($result);
				$('.deladmin_id').attr('disabled', 'disabled');
				$('.eadmin_id').attr('disabled', 'disabled');
				setTimeout(function(){
					window.location = 'delete_product.php?prod_id=' + $admin_id;
				}, 1000);
			});
		});
	</script>
    <script src="js/angular.min.js"></script>
    <script>
      var app = angular.module('app', []);
      app.controller('myController', function($scope){
        $scope.valid = false;
        $scope.submit = function(){
          $scope.valid = true;
        }
        $scope.close = function(){
          $scope.valid = false;
        }
      });
    </script>
</body>
</html>