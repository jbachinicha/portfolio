<?php
include('valid.php');

if ($_SESSION['admin_id'] == 1) {
 	header('location: admin_profile.php');
 }
 else{
 	header('location: user_profile.php');
 }

?>