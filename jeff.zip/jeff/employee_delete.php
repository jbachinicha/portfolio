<?php
	require_once 'connect.php';
	include('valid.php');
		$id = $_SESSION['admin_id'];
		$date = date("Y-m-d H:i:s");

		$query=mysqli_query($conn,"SELECT * FROM employee WHERE `employee_id` = '$_REQUEST[employee_id]'")or die(mysqli_error());
  
        $row=mysqli_fetch_array($query);
		$name=$row['first_name'];
		$remarks="Fired $name as an employee";  
	
		mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));
			
		mysqli_query($conn,"UPDATE `employee` SET status='Fired' WHERE `employee_id` = '$_REQUEST[employee_id]'")or die(mysqli_error($conn));

		echo "<script>alert('Fired!!');
	      window.location.href='manage_employee.php'</script>";
	?>