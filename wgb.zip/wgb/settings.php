<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb well">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Settings</li>
    </ol>

</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>
</body>
</html>