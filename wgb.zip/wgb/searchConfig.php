<?php
	$conn = new mysqli('localhost', 'root', '', 'wgb') or die(mysqli_error($conn));
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}

	?> 