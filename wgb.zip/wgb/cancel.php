<?php
	require_once 'connect.php';
	include('valid.php');
	$id=$_SESSION['admin_id'];
	
	$result=mysqli_query($conn,"DELETE FROM temp_trans where admin_id='$id'")	or die(mysqli_error());
	 echo "<script>document.location='daily.php'</script>";  
?>