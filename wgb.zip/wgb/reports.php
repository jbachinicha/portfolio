<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('reports').style;
        active.backgroundColor = "#be9b7b";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">

          <section class="content breadcrumb well">
            <div class="row">
              <div class="col-md-12">
                <div class="box box-primary">
                  <div class="box-header with-border noprint">
                    <h3 class="box-title">Reports</h3>
                  </div>
                  <div class="box-body">
                  	<br>

                  		<div class="btn-group noprint">
						    <button type="button" class="btn btn-theme"><a href="reports.php" aria-expanded="true"><i class="fa fa-bar-chart" style="color: #fff"></i> Sales Reports</a></button>
						</div>
						<div class="btn-group noprint">
						   	<button type="button" class="btn btn-theme"><a href="report_stock.php" ><i class="fa fa-inbox" style="color: #fff"></i> Stock In Reports</a></button>
						</div>
						<br><br>

						<div class="tab-content">
							<div class="tab-pane active" id="sales">
								<form action="reports.php#sales" method="get">

				                  <input type="submit" name="today" value="Daily Sales" class="myButton btn btn-theme">&nbsp;
				                  <input type="submit" name="month" value="Monthly Sales" class="myButton btn btn-theme">&nbsp;
				                  <input type="submit" name="year" value="Yearly Sales" class="myButton btn btn-theme">&nbsp;

				                  From <input type="date" size='5' name="from" id="datepicker-start">&nbsp;
				                  To <input type="date" size='5' name="to" id="datepicker-end">&nbsp; 

				                  <input type="submit" name="range" value="Show" class="myButton btn btn-theme">

				                </form>
				                <?php

									if(isset($_GET['today']))
									{
									  include 'today.php';
									}
									if(isset($_GET['month']))
									{
									  include 'month.php';
									}
									if(isset($_GET['year']))
									{
									  include 'year.php';
									}
									if(isset($_GET['from']) && isset($_GET['to']) && isset($_GET['range']))
									{
									  $from = $_GET['from'];
									  $to = $_GET['to'];
									  
									  //echo "from : $from <br> to : $to";
									  include 'range.php';
									}

									?> 
							</div>
						</div>
                  </div>
                </div>
              </div>
            </div>
          </section>

</div>
<div class="noprint"><?php include('include/footer.php');?></div>
</body>
</html>