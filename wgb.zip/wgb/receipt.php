<!DOCTYPE html>
<?php
  require_once 'valid.php';
?>  
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
</head> 
<body>

   <div class="page-container">
    <?php include('include/cashier_header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="content">
<div class="mother-grid-inner" style="padding-top: 80px;">
  <ol class="breadcrumb noprint">
        <li class="breadcrumb-item"><a href="daily.php">Home</a> <i class="fa fa-angle-right"></i> Sales <i class="fa fa-angle-right"></i> Reciept</li>
    </ol>
          <section class="content breadcrumb">
            <div class="row">
        <div class="col-md-12">
              <div class="col-md-12">

              </div>
                
                <div class="box-body">

                  <!-- Date range -->
                  <form method="post" action="">     
                 
<?php

    $query=mysqli_query($conn,"SELECT * FROM sales s ORDER BY s.sales_id DESC LIMIT 0,1")or die(mysqli_error($conn));
      
        $row=mysqli_fetch_array($query);
       
        $sales_id=$row['sales_id'];
        $sid=$row['sales_id'];
        $due=$row['amount_due'];
        $discount=$row['discount'];
        $grandtotal=$due-$discount;
        $tendered=$row['cash_tendered'];
        $change=$row['cash_change'];

        $query1=mysqli_query($conn,"SELECT * FROM payment WHERE sales_id='$sales_id'")or die(mysqli_error($conn));
      
        $row1=mysqli_fetch_array($query1);

?>    
         

                   <table class="table ta">
                    <thead>
                      <tr>
                        <th colspan="3"><h5><b>Jinska Water Station</b></h5></th>
                        
                        <th><b><u>SALES INVOICE</u></b></th>
                      </tr>
                      <tr>
                        <th colspan="3"><h6>Sabang, Sibonga, Cebu</h6></th>
                     
                        <th><span style="font-size: 16px;color: red">No. <?php echo $row1['or_no'];?></span></th>
                      </tr>
                      <tr>
                        <th colspan="3"><h6>Contact #: 09353993218</h6></th>
                        <th></th>
                      </tr>
                      
                    </thead>
                    <thead>

                      <tr>
                        <th>SOLD to</th>
                        <th><u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></th>
                        <th>Date</th>
                        <th><u><?php echo date("M d, Y");?> Time <?php echo date("h:i A");?></u></th>
                      </tr>
                      <tr>
                        <th>Address</th>
                        <th><u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></th>
                        <th></th>
                        <th></th>
                      </tr>
                      <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                      </tr>
                    </thead>
                  </table>
                  <table class="table ts">
                    <thead>
                        
                      <tr style="border: solid 1px #000">
                        <th>CODE</th>
                        <th>QTY</th>
                        <th>UNIT</th>
                        <th>CONTAINER</th>
                        <th>PRODUCT NAME</th>
                        <th>Unit Price</th>
                        <th class="text-right">AMOUNT</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
    $query=mysqli_query($conn,"SELECT * FROM sales_details sd JOIN inventory p WHERE sd.sales_id='$sid' AND p.prod_id=sd.prod_id")or die(mysqli_error($conn));
      $grand=0;
    while($row=mysqli_fetch_array($query)){
        //$id=$row['temp_trans_id'];
        $total= $row['qty']*$row['price'];
        $grand=$grand+$total;
        
?>
                      <tr>
                        <td><?php echo $row['transaction_code'] ?></td>
                        <td><?php echo $row['qty'];?></td>
                        <td>pc/s</td>
                        <td class="record"><?php echo $row['prod_name'];?></td>
                        <td><?php echo $row['product'] ;?></td>
                        <td><?php echo number_format($row['price'],2);?></td>
                        <td style="text-align:right"><?php echo number_format($total,2);?></td>
                                    
                      </tr>
            

<?php }?>           
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-right">Subtotal</td>
                        <td style="text-align:right"><?php echo number_format($grand,2);?></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-right">Discount</td>
                        <td style="text-align:right"><?php echo number_format($discount,2);?></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-right"><b>TOTAL AMOUNT DUE</b></td>
                        <td style="text-align:right"><b><?php echo number_format($grand-$discount,2);?></b></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-right">Cash Tendered</td>
                        <td style="text-align:right"><?php echo number_format($tendered,2);?></td>
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-right"><b>Change</b></td>
                        <td style="text-align:right"><b><?php echo number_format($change,2);?></b></td>
                      </tr> 
                      <tr>
                        <th>Prepared by:</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>_________________________</th>
                      </tr> 
<?php
    $id=$_SESSION['admin_id'];
    $query=mysqli_query($conn,"select * from admin where admin_id='$id'")or die(mysqli_error($conn));
    $row=mysqli_fetch_array($query);
 
?>                      
                      <tr>
                        <th><?php echo $row['firstname'];?>&nbsp;<?php echo $row['lastname'];?></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Customer's Signature</th>
                      </tr>  
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
        </div>  
        </form> 
                </div><!-- /.box-body -->
                <a class = "btn btn-theme btn-print noprint" href = "" onclick = "window.print()"><i class ="glyphicon glyphicon-print" style="color: #fff;"></i> Print</a>
                <a class = "btn btn-danger btn-print noprint" href = "daily.php"><i class ="glyphicon glyphicon-arrow-left" style="color: #fff;"></i> Back</a>
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
           
          </div><!-- /.row -->
    
             
          </section>


</div>
  <!--//content-inner-->
      <!--/sidebar-menu-->
<div class="noprint side"><?php include('include/cashier_footer.php');?></div>
</body>
</html>