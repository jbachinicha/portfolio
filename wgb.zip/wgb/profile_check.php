<?php
include('valid.php');
require'account.php';
if ($type == "Administrator") {
 	header('location: admin_profile.php');
 }
 else{
 	header('location: user_profile.php');
 }

?>