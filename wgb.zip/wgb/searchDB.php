<?php
	require_once 'connect.php';
	include('valid.php');

	if (isset($_GET['userInput'])) {
		$value = $_GET['userInput'];
	}
	else{
		echo "No Input!!";
	}

	$sql = "SELECT * FROM customer WHERE status='Active' AND cust_first LIKE '%".$value."%'; ";
	if ($result = mysqli_query($conn, $sql)) {
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_array($result)) {
				$list[] = $row['cust_first'].' '. $row['cust_last'];
			}
		}
		else{
			$list[] = "No match";
		}
	}

	if (!empty($value)) {
		if ($matched = preg_grep('~'.$value.'~', $list)) {
			$count = 0;
			echo '<ul class="suggest-menu col-md-9">';
				while ($count < sizeOf($list)) {
					if (isset($matched[$count])) {
						echo '<a href=search.php?name='.$matched[$count].' class="suggest-link"><li class="suggest-item">'.$matched[$count].'</li></a>';
					}
					$count ++;
				}
				echo "</ul";
		}
		else{
			echo "No result";
		}
	}
?>