<?php 
	require_once 'connect.php';
	include('valid.php');
	$last = $_POST['last'];
	$first = $_POST['first'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$date = date("Y-m-d H:i:s");
	$remarks="added $first as new customer";
	
	$query2=mysqli_query($conn,"SELECT * FROM customer WHERE cust_last='$last' and cust_first='$first'")or die(mysqli_error($conn));
		$count=mysqli_num_rows($query2);

		if ($count>0)
		{
			echo "<script type='text/javascript'>alert('Customer already exist!');</script>";
			echo "<script>document.location='daily.php'</script>";  
		}
		else
		{	
			
			mysqli_query($conn,"INSERT INTO customer(cust_last,cust_first,cust_address,cust_contact,balance,cust_pic,credit_status) 
				VALUES('$last','$first','$address','$contact','0','default.gif','Active')")or die(mysqli_error($conn));

			$id=mysqli_insert_id($conn);
			//$_SESSION['cid']=$id;
			//echo "<script type='text/javascript'>alert('Successfully added new customer!');</script>";
			$t='0';
			echo "<script>document.location='cash_transaction_deliver.php?cid=$id&trans_id=$t'</script>";  
		}
?>