<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('logs').style;
        active.backgroundColor = "#be9b7b";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">

    <div class = "col-lg-12 well breadcrumb" style = "margin-top:20px;">
    				<a class="btn btn-theme" href="history.php" style="color:#fff;"><i class="fa fa-external-link" style="color: #fff"></i> History</a>
					<h3>User Login Records</h3>
					<br />
					<br />
					<div id = "admin_table">
						<table id = "table1" class = "table table-bordered">
							<thead class = "alert">
								<tr>
									<th>Ip Address</th>
									<th>Date</th>
									<th>Username Used</th>
									<th>User Type</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
							<?php
								$q_admin = $conn->query("SELECT * FROM log_records ") or die(mysqli_error());
								while($f_admin = $q_admin->fetch_array()){
									
							?>	
								<tr class = "target table-row">
									<td><?php echo $f_admin['ip_address']?></td>
									<td><?php echo ($f_admin['date'])?></td>
									<td><?php echo $f_admin['username_used']?></td>
									<td><?php echo $f_admin['type']?></td>
									<td>
										<center>
											<?php
												if ($f_admin['Status']=='success') {
													echo "<a href = '#' class = 'btn btn-success'>
												      <span class = 'fa fa-check'></span>Success
											        </a>";
												}
												else{
													echo "<a href = '#' class = 'btn btn-danger'>
												      <span class = 'fa fa-close'></span>Failed
											        </a>";
												}

											?>
										</center>
									</td>
								</tr>
							<?php
								}
							?>	
							</tbody>
						</table>
<?php include('modal/log_modal.php'); ?>
					</div>

			</div>

</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#table1").DataTable();
        $("#table2").DataTable();
        $("#table3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>


</body>
</html>