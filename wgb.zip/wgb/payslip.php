<!DOCTYPE html>
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
<style type="text/css">
	.container{
		font-weight: 900;
	}
</style>
</head> 
<body>
	<div class="container">
		<center>
			<h3><b>Jinska ION Water Station</b> </h3>  
			<h5>Address: Sabang, Sibonga, Cebu</h5>
			<h5>Contact #: 09353993218</h5>
			<h5><b><?php echo date("M d, Y ");?></b></h5>
		</center>
		<br>
			<table cellspacing="0" cellpadding="3" class="table"> 
			<?php
			 include 'connect.php';

                            $deduc_sql = mysqli_query($conn, "SELECT *, SUM(amount) as total_amount FROM deductions")or die(mysqli_error($conn));
                            $r = mysqli_fetch_array($deduc_sql);
                            $deduction = $r['total_amount'];

                            $sql = mysqli_query($conn, "SELECT *, SUM(num_hr) AS total_hr, a.employee_id AS empid FROM attendance a JOIN employee e ON e.id=a.employee_id JOIN position p ON p.id=e.position_id WHERE e.employee_id='$_REQUEST[employee_id]' GROUP BY a.employee_id ORDER BY e.last_name ASC, e.first_name ASC")or die(mysqli_error($conn));
                            $total = 0;
                            while ($row = mysqli_fetch_array($sql)) {
                              $empid = $row['empid'];
                              $casql = mysqli_query($conn, "SELECT *, SUM(amount) AS cashamount FROM cashadvance WHERE employee_id='$empid'")or die(mysqli_error($conn));
                              $carow = mysqli_fetch_array($casql);
                              $cashadvance = $carow['cashamount'];

                              $gross = $row['rate'] * $row['total_hr'];
                              $total_deduction = $deduction + $cashadvance;
                              $net = $gross - $total_deduction; ?>

                              <tr>  
            		<td width="25%" align="right">Employee Name: </td>
                 	<td width="25%"><b><?php echo $row['first_name']." ".$row['last_name']?></b></td>
				 	<td width="25%" align="right">Rate per Hour: </td>
                 	<td width="25%" align="right"><?php echo number_format($row['rate'], 2) ?></td>
    	    	</tr>
    	    	<tr>
    	    		<td width="25%" align="right">Employee ID: </td>
				 	<td width="25%"><?php echo $row['employee_id'] ?></td>   
				 	<td width="25%" align="right">Total Hours: </td>
				 	<td width="25%" align="right"><?php echo number_format($row['total_hr'], 2)?></td> 
    	    	</tr>
    	    	<tr> 
    	    		<td></td> 
    	    		<td></td>
				 	<td width="25%" align="right"><b>Gross Pay: </b></td>
				 	<td width="25%" align="right"><b><?php echo number_format(($row['rate']*$row['total_hr']), 2)?></b></td> 
    	    	</tr>
    	    	<tr> 
    	    		<td></td> 
    	    		<td></td>
				 	<td width="25%" align="right">Deduction: </td>
				 	<td width="25%" align="right"><?php echo number_format($deduction, 2)?></td> 
    	    	</tr>
    	    	<tr> 
    	    		<td></td> 
    	    		<td></td>
				 	<td width="25%" align="right">Cash Advance: </td>
				 	<td width="25%" align="right"><?php echo number_format($cashadvance, 2) ?></td> 
    	    	</tr>
    	    	<tr> 
    	    		<td></td> 
    	    		<td></td>
				 	<td width="25%" align="right"><b>Total Deduction:</b></td>
				 	<td width="25%" align="right"><b><?php echo number_format($total_deduction, 2)?></b></td> 
    	    	</tr>
    	    	<tr> 
    	    		<td></td> 
    	    		<td></td>
				 	<td width="25%" align="right"><b>Net Pay:</b></td>
				 	<td width="25%" align="right"><b><?php echo number_format($net, 2)?></b></td> 
    	    	</tr>

                              <?php
                          }
			?> 
    	    </table>
    	    <hr>
	</div>
<script>window.print();</script>
</body>
</html>