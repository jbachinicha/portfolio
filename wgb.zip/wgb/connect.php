<?php
	$conn = new mysqli('localhost', 'root', '', 'wgb') or die(mysqli_error());
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}