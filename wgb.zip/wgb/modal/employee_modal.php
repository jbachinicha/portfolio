	<div class="modal fade" id="employ" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;" ng-controller="myController">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Add New Employee</h4>
                  </div>
                  <div class="modal-body">
							<form method = "POST" action = "save_employee.php" role="form" name="myForm" novalidate>
								<div class="form-group">
									<label>Personal Data</label>
									<hr>
								</div>

                <div class="form-group">
                  <label>First Name:</label>
                    <input type="text" class = "form-control" name="firstname" ng-model="employee.firstname" required>
                    <div class="errortext" ng-show="myForm.firstname.$dirty && myForm.firstname.$invalid">
                      <span ng-show="myForm.firstname.$error.required">Firstname is required</span>
                    </div>
                </div>

                <div class="form-group">
                  <label>Middle Name:</label>
                  <input type = "text" name = "middlename" class = "form-control" placeholder="Optional" />
                </div>

                <div class="form-group">
                  <label>Last Name:</label>
                    <input type="text" class = "form-control" name="lastname" ng-model="employee.lastname" required>
                    <div class="errortext" ng-show="myForm.lastname.$dirty && myForm.lastname.$invalid">
                      <span ng-show="myForm.lastname.$error.required">Lastname is required</span>
                    </div>
                </div>

                <div class="form-group">
                  <label>Address:</label>
                  <input type="text" class = "form-control" name="address" ng-model="employee.address" required>
                    <div class="errortext" ng-show="myForm.address.$dirty && myForm.address.$invalid">
                      <span ng-show="myForm.address.$error.required">Address is required</span>
                    </div>
                </div>

                <div class="form-group">
                  <label for="empstatus">Gender:</label>
                  <select class="form-control" name="gender" ng-model="gender.phone" required>
                    <option value="">-- Select Gender --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                  <div class="errortext" ng-show="myForm.gender.$dirty && myForm.gender.$invalid">
                      <span ng-show="myForm.gender.$error.required">Position required.</span>
                    </div>
                </div>

                <div class="form-group">
                  <label>Phone Number:</label>
                  <input type="number" class = "form-control" name="phone" ng-model="employee.phone" ng-pattern="/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[\s\.]?[0-9]{4,6}$/">
                    <div class="errortext" ng-show="myForm.phone.$dirty && myForm.phone.$invalid">
                      <span ng-show="myForm.phone.$error.pattern">Must be valid 11 digit phone number.</span>
                    </div>
                </div>

                <div class="form-group">
                  <label for="empstatus">Position:</label>
                  <select class="form-control" name="position" ng-model="position.phone" required>
                    <option value="">-- Select Position --</option>
                    <?php 
                      include 'connect.php';

                      $q=mysqli_query($conn, "SELECT * FROM position")or die(mysqli_error($conn));
                      while ($row = mysqli_fetch_array($q)) {
                        echo "<option value='".$row['id']."'>".$row['description']."</option>";
                      }
                    ?>
                  </select>
                  <div class="errortext" ng-show="myForm.position.$dirty && myForm.position.$invalid">
                      <span ng-show="myForm.position.$error.required">Position required.</span>
                    </div>
                </div>

                <div class="form-group">
                  <input type="hidden" name="schedule" value="1">
                </div>

								<div class = "form-group">	
									<button class = "btn btn-theme" ng-disabled="myForm.$invalid" ng-click="submit()" name = "save_employee"><span class = "gl glyphicon glyphicon-save"></span> Submit</button>
								</div>
							</form>
                  </div>
                </div>
              </div>
            </div>
	<div class="modal fade" id="deduc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index: 99999999999999999999;">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 align="center" style="color: white;"><b>Position</b></h3>
                  </div>
                  <div class="modal-body">
                    <a href="#add" data-target="#add" data-toggle="modal" data-dismiss="modal" class="btn btn-theme"><span class = "fa fa-plus"></span>Add Position</a> <br>
			<form class="form-horizontal" action="#" name="form">
            <table id = "example5" class = "table table-bordered">
              <thead class = "alert">
                <tr>
                  <th>Position</th>
                  <th>Rate</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $q_admin = $conn->query("SELECT * FROM position ") or die(mysqli_error());
                while($f_admin = $q_admin->fetch_array()){
                  $pos = $f_admin['description'];
                  $rate = $f_admin['rate'];
                  $id = $f_admin['id'];
              ?>  
                <tr class = "target table-row">
                  <td><?php echo $f_admin['description']?></td>
                  <td><?php echo $f_admin['rate']?></td>
                  <td width="10%">
                    <center>
                    <a href="#deductions<?php echo $f_admin['id'];?>" data-target="#deductions<?php echo $f_admin['id'];?>" data-toggle="modal"   class="btn btn-theme"><span class = "fa fa-edit"></span>Update</a>
                  </center>
                    
                  </td>
                </tr>

                <div id="deductions<?php echo $f_admin['id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center" style="color: white;"><b>Position</b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">

              <form class="form-horizontal" action="update_position.php" name="form" method="post">
                <div class="form-group">
                  <label class="col-sm-4 control-label">Position</label>
                  <div class="col-sm-8">
                    <input type="hidden" name="id" class="form-control" required="required" value="<?php echo $f_admin['id'] ?>">
                    <input type="text" name="pos" class="form-control" required="required" value="<?php echo $f_admin['description'] ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">Rate</label>
                  <div class="col-sm-8">
                    <input type="text" name="rate" class="form-control" value="<?php echo $f_admin['rate'] ?>" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-8">
                    <input type="submit" name="up" class="btn btn-theme" value="Submit">
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
               <?php
                }
              ?>  
              </tbody>
            </table>
              </form>
                  </div>
                </div>
              </div>
            </div>

              


<div id="add" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center" style="color: white;"><b>Position</b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">

              <form class="form-horizontal" action="add_position.php" name="form" method="post">
                <div class="form-group">
                  <label class="col-sm-4 control-label">Position</label>
                  <div class="col-sm-8">
                    <input type="text" name="pos" class="form-control" required="required" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">Rate</label>
                  <div class="col-sm-8">
                    <input type="text" name="rate" class="form-control" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-8">
                    <input type="submit" name="add" class="btn btn-theme" value="Submit">
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
     