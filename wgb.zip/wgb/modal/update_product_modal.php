<div id="updateordinance<?php echo $row['prod_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
	  <div class="modal-content" style="height:auto">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update Product Details</h4>
              </div>
              <div class="modal-body">
			  <form class="form-horizontal" method="post" action="product_update.php" enctype='multipart/form-data'>
			        <div class="form-group">
			          <label class="control-label col-lg-3" for="price">Item Code:</label>
			          <div class="col-lg-9">
			            <input type="text" class="form-control" id="price" name="serial" value="<?php echo $row['serial'];?>" required>  
			          </div>
			        </div>
			                
							<div class="form-group">
								<label class="control-label col-lg-3" for="name">Item Name:</label>
								<div class="col-lg-9"><input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row['prod_id'];?>" required>  
								  <input type="text" class="form-control" id="name" name="prod_name" value="<?php echo $row['prod_name'];?>" required>  
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-lg-3" for="price">Price:</label>
								<div class="col-lg-9">
								  <input type="text" class="form-control" id="price" name="prod_price" value="<?php echo $row['prod_price'];?>" required>  
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-lg-3" for="price">Reorder:</label>
								<div class="col-lg-9">
								  <input type="number" class="form-control" id="price" name="reorder" value="<?php echo $row['reorder'];?>" required>  
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-lg-3" for="price">Picture:</label>
								<div class="col-lg-9">
								  <input type="hidden" class="form-control" id="price" name="image1" value="<?php echo $row['prod_pic'];?>"> 
								  <input type="file" class="form-control" id="price" name="image">  
								</div>
							</div>
			        <div class="modal-footer">
			    <button type="submit" class="btn btn-theme">Save changes</button>
			                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			              </div>
			              </div>
			  </form>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal--> 

 <div id="reorder<?php echo $row['prod_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
	  <div class="modal-content" style="height:auto">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Stock</h4>
              </div>
              <div class="modal-body">
			  <form class="form-horizontal" method="post" action="product_update.php" enctype='multipart/form-data'>
			        <div class="form-group">
			          <label class="control-label col-lg-3" for="price">Item Code:</label>
			          <div class="col-lg-9">
			            <label><?php echo $row['serial'];?></label>  
			          </div>
			        </div>
			                
							<div class="form-group">
								<label class="control-label col-lg-3" for="name">Item Name:</label>
								<div class="col-lg-9"><input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row['prod_id'];?>" required>  
									<label><?php echo $row['prod_name'];?></label>  
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-lg-3" for="price">Quantity:</label>
								<div class="col-lg-9">
								  <input type="text" class="form-control" id="price" name="prod_price" value="<?php echo $row['prod_price'];?>" required>  
								</div>
							</div>
			        	  <div class="modal-footer">
			    			<button type="submit" class="btn btn-theme">Order</button>
			                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			              </div>
			              </div>
			  </form>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>