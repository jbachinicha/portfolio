<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
  <head>
    <title>Welcome <?php require'account.php'; echo $name;?></title>
    <?php include('include/head_scripts.php');?>

    <link rel="stylesheet" type="text/css" href="js/gritter/css/jquery.gritter.css" />

    <script type="text/javascript">
      $(document).ready(function () {
        // var unique_id = $.gritter.add({
        //   title: 'Welcome to Jinska Admin Panel!',
        //   text: '<h5><?php require'account.php'; echo $name;?></h5>',
        //   image: 'images/users.png',
        //   sticky: false,
        //   time: '',
        //   class_name: 'my-sticky-class'
        // });

        var active = document.getElementById('dashboard').style;
        active.backgroundColor = "#be9b7b";
        active.color = "#fff";

        return false;
      });
    </script>

    <style>
      .low{
        color: red;
      }
    </style>
  </head> 
  <body>
    <div class="page-container">
      <?php include('include/header.php');?>
      <?php include('include/logout_modal.php');?>

        <div class="left-content">
          <div class="mother-grid-inner" style="padding-top: 80px;">
                    <li><a href="home.php" style="font-size: 2.5rem; color: #424a5d" >Dashboard</a></li><hr style="border-top: 2px solid #eeee !important">
<!--heder end here-->

          <div id="poduct_details" class = "col-lg-12 well breadcrumb" style = "margin-top:-20px;">
                    <div class="row">
        <div class="col-lg-6 col-md-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <?php
                $sql = "SELECT * FROM employee WHERE status='Hired'";
                $query = $conn->query($sql);

                echo "<h3>".$query->num_rows."</h3>";
              ?>

              <p>Total Employees</p>
            </div>
            <div class="icon">
              <i class="fa fa-group"></i>
            </div>
            <a href="manage_employee.php" class="small-box-footer" style="color: #337ab7">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-md-12">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <?php
                $conn = mysqli_connect("localhost","root","","wgb");
                $q = mysqli_query($conn, "SELECT COUNT(*) AS TOTAL,SUM(qty) AS TQ, SUM(total) AS TA FROM SALES WHERE DAY(date_added)=DAY(CURDATE()) AND MONTH(date_added)=MONTH(CURDATE())");
                while ($row = mysqli_fetch_assoc($q)) { 
                $total_sales = $row['TOTAL']; ?>
                        <h3><?php echo $total_sales; ?></h3>
                                    <?php
                                        }
                                    ?>
          
              <p>Total Daily Sales</p>
            </div>
            <div class="icon">
              <i class="fa fa-money"></i>
            </div>
            <a href="reports.php" class="small-box-footer" style="color: #5cb85c">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-md-12">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
                        <h3>0</h3>
          
              <p>Total Pending Delivery</p>
            </div>
            <div class="icon">
              <i class="fa fa-truck"></i>
            </div>
            <a href="calendar.php" class="small-box-footer" style="color: #f0ad4e">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-6 col-md-12">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
                        <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, " SELECT COUNT(*) AS COUNTLOW FROM INVENTORY WHERE prod_qty < 50");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $countlow = $row['COUNTLOW'];
                                            ?>
                                            <h3><?php echo "$countlow"; ?></h3>
                                    <?php
                                        }
                                    ?>
          
              <p>Total Reorders</p>
            </div>
            <div class="icon">
              <i class="fa fa-refresh"></i>
            </div>
            <a href="inventory.php" class="small-box-footer" style="color: #d9534f">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

            <div class="row  col-xs-12">
        <div class="col-xs-10">
          <div class="box">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Monthly Sales Chart(<?php echo date("Y") ?>)</h3> -->
              <div class="box-tools">
                <!-- <?php include 'year.php'; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
          </div>
    
          </div>
        </div>
    </div>
<!-- <div class="text-right" style="color: #000; position: bottom;">&#169; Copyright 2017 JinskaION, Inc. | Powered by <a>Randz PC</a> &nbsp;&nbsp;</div> -->

    <script src="js/gritter/js/jquery.gritter.js"></script>
    <script src="js/gritter-conf.js"></script>
    <script type="text/javascript" src="js/jquery.backstretch.min.js"></script>
    <div><?php include('include/footer.php');?></div>
  </body>
</html>