<?php
	require_once('valid.php');
?>

<html>
<head>
<title>Daily Sales</title>

</head>
<body>
<center>
<h2>Daily Sales (<?php echo date("d-m-Y") ?>)</h2>

<?php
    $conn = mysqli_connect("localhost","root","","wgb");
    $q = mysqli_query($conn, "SELECT COUNT(*) AS TOTAL,SUM(qty) AS TQ, SUM(total) AS TA FROM SALES WHERE DAY(date_added)=DAY(CURDATE())");
    
    while ($row = mysqli_fetch_assoc($q)) { 
        $total_sales = $row['TOTAL'];
        $sold = $row['TQ'];
        $ammount = $row['TA'];
?>
        <h5><i class=" fa fa-money"></i> Today's Sales:</h5>
        <span class="subject">
        <b><span><?php echo "Total Amount: $ammount"; ?></span></b><br>
        <b><span><?php echo "Total Sales: $total_sales"; ?></span></b><br>
        <b><span><?php echo "Total Items Sold: $sold"; ?></span></b>
        </span>
<?php
    }
?>



<!--<?php

include 'config.php';

	
try
{
	
	//connect to database
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	//select data from db
	$stmt = $conn->prepare("SELECT * FROM sales s JOIN sales_details sd JOIN customer c WHERE s.sales_id=sd.sales_id AND s.cust_id=c.cust_id AND date_added=CURDATE()");
	
	//execute the sql query
	$stmt->execute();
	
	echo "
		
		
		 <div class='table-responsive'>
		<table class='table table-bordered table-hover table-striped'>
		<tr>
		<th>No.</th>
		<th>Customer</th>
		<th>Date</th>
		<th>Product</th>
		<th>Price</th>
		<th>Quantity</th>
		<th>Cash Tendered</th>
		<th>Amount Due</th>
		<th>Change</th>
		<th>Total</th>
		</tr>
	
	";
	
	$i=0;	
	//use php function fetch() to get the db column data
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
	{
        //use the fetched data to store into variable
		$name = $row['cust_first']." ".$row['cust_last'];
		$date = $row['date_added'];
		$size = $row['SIZE'];
		$sleeve = $row['SLEEVE'];
		$flowers = $row['FLOWERSEMB'];
		$quantity = $row['QUANTITY'];
		$price = $row['PRICE'];
		$revenue = $row['REVENUE'];
		$datetime = $row['DISDATE'];
		$empid = $row['EMPID'];
		$prodid = $row['PRODUCTID'];
		
		$no = $i+1;
		
		echo " 
		
		<tr>
		<td>$no</td>
		<td>$empid</td>
		<td>$datetime</td>
		<td>$prodid</td>
		<td>$name</td>
		<td>$colors</td>
		<td>$size</td>
		<td>$sleeve</td>
		<td>$flowers</td>
		<td>$quantity</td>
		<td>$price</td>
		<td>$revenue</td>
		</tr>
			
		
	
		";
		
		$i++;
	}
	
	$total = $conn->prepare("SELECT SUM(PRICE) AS TOTALSALES, 
											SUM(REVENUE) AS TOTALREV, 
											SUM(QUANTITY) AS TOTALQUANTITY
											FROM SALES 
											WHERE DATE_TIME=CURDATE()");
	
	$total->execute();
	
	$result = $total->fetch(PDO::FETCH_ASSOC);
	$totalprice = $result['TOTALSALES'];
	$totalrevenue = $result['TOTALREV'];
	$totalquantity = $result['TOTALQUANTITY'];
	
	//total
	echo "
	<tr>
	<td  colspan='8'></td>
	<th>Total</th>
	<th>$totalquantity</th>
	<th>$totalprice</th>
	<th>$totalrevenue</th>
	</tr>
	
	</table>
	</div>

	";
	
}	
catch (PDOException $e)
{
	echo "Connection failed: " . $e->getMessage();
}

//close conection
$conn = null;


?> -->

</form>
</center>
</body>
</html>