<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
  <head>
    <title>Jinska Administrator</title>
    <?php include('include/head_scripts.php');?>

    <link rel="stylesheet" type="text/css" href="js/gritter/css/jquery.gritter.css" />

    <script type="text/javascript">
      $(document).ready(function () {
        var unique_id = $.gritter.add({
          title: 'Welcome to Jinska Admin Panel!',
          text: '<h5><?php require'account.php'; echo $name;?></h5>',
          image: 'images/users.png',
          sticky: false,
          time: '',
          class_name: 'my-sticky-class'
        });

        return false;
      });
    </script>

    <style>
      .low{
        color: red;
      }
    </style>
  </head> 
  <body>
    <div class="page-container">
      <?php include('include/header.php');?>
      <?php include('include/logout_modal.php');?>

      <div class="left-content">
        <div class="mother-grid-inner" style="padding-top: 80px;">

	        <ol class="breadcrumb well">
            <li class="breadcrumb-item">
              <a href="home.php">Home</a> <i class="fa fa-angle-right"></i>
            </li>
          </ol>

          <div class="breadcrumb">
            <div class="panel">
              <div class="panel-heading">
                <h3>
                  <i class="fa fa-bell"></i> <b>Notification Panel</b>
                </h3>
              </div>
              <div class="panel-body" style="margin-top: -40px;">
                <div class="list-group">
                  <a href="sales_report.php" class="list-group-item" style="border: 1px solid rgba(0, 0, 0, 0.19); color: black; border-radius: 10px 10px 0px 0px;">
                  <?php
                    include 'config.php';
  
                    try{
                      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                      
                      $salesnum = $conn->prepare("SELECT COUNT(*) AS TOTAL,SUM(qty) AS TQ, SUM(total) AS TA FROM SALES WHERE DAY(date_added)=DAY(CURDATE())");
                      $salesnum->execute();
                      $result = $salesnum->fetch(PDO::FETCH_ASSOC);
                      $total_sales = $result['TOTAL'];
                      $sold = $result['TQ'];
                      $ammount = $result['TA'];
                    
                      $countstmt = $conn->prepare(" SELECT COUNT(*) AS COUNTLOW FROM INVENTORY WHERE prod_qty < 50");
                      $countstmt->execute();
                      $resultlow = $countstmt->fetch(PDO::FETCH_ASSOC);
                      $countlow = $resultlow['COUNTLOW'];
                    
                      echo "
                            <b><i class='fa fa-money fa-fw' style='color: #52d3aa;'></i> Today's Sales : </b><br> 
                            <i>
                              <b>$ammount</b> total ammount <br>
                              <b>$total_sales</b> total sales <br>
                              <b>$sold</b> total items sold    
                            </i>
                          </a>
                          <a href='inventory.php' class='list-group-item'  style='color: black; border: 1px solid rgba(0, 0, 0, 0.19); border-radius: 0px 0px 10px 10px;'>
                      ";
                    
                      echo "
                              <i class='fa fa-shopping-cart fa-fw'></i> <b>$countlow</b> Stock Is Running Low (Stock below 50 pcs) : <br>
                      ";
                     
                      $getlow = $conn->prepare(" SELECT * FROM INVENTORY WHERE prod_qty <50");
                      $getlow->execute();
                    
                      while ($row = $getlow->fetch(PDO::FETCH_ASSOC)){
                        $name = $row['prod_name'];
                        $quantity = $row['prod_qty'];
                      
                        echo "
                              <i class='low'>$name : <b class='low'>$quantity left</b></i> <br>
                        ";
                      }
                    
                      echo "
                            </a>
                          </div>
                        </div>";
                    } 

                    catch (PDOException $e){
                      echo "Connection failed: " . $e->getMessage();
                    }
                    $conn = null;
                  ?>

                </div>
              </div>


              <div class="breadcrumb well">
                <h3><b>Sales Charts</b></h3><span>Yearly Sales (<?php echo date("Y") ?>)</span>
                <div class="tab-pane" id="chartjs">
                  <div class="row mt">
                    <div>
                      <?php
                        include 'config.php';
              
                        try {
                          $c = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                          $c->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                          $graph = $c->prepare("SELECT MONTH(date_added) AS MONTHZ, SUM(qty) AS TQ FROM SALES WHERE YEAR(date_added)=YEAR(CURDATE()) GROUP BY MONTH(date_added)");
  
                          $graph->execute();

                          $jan = 0;
                          $feb = 0;
                          $mar = 0;
                          $apr = 0;
                          $may = 0;
                          $jun = 0;
                          $jul = 0;
                          $aug = 0;
                          $sep = 0;
                          $oct = 0;
                          $nov = 0;
                          $dec = 0;
              
                          while($result = $graph->fetch(PDO::FETCH_ASSOC))
                          {
                            $month = $result['MONTHZ'];
                            $totalquantity = $result['TQ'];
                
                            if($month == 1)
                          {
                            $jan = $totalquantity;
                          }
                            if($month == 2)
                          {
                            $feb = $totalquantity;
                          }
                            if($month == 3)
                          {
                            $mar = $totalquantity;
                          }
                            if($month == 4)
                          {
                            $apr = $totalquantity;
                          }
                            if($month == 5)
                          {
                            $may = $totalquantity;
                          }
                            if($month == 6)
                          {
                            $jun = $totalquantity;
                          }
                            if($month == 7)
                          {
                            $jul = $totalquantity;
                          }
                            if($month == 8)
                          {
                            $aug = $totalquantity;
                          }
                            if($month == 9)
                          {
                            $sep = $totalquantity;
                          }
                            if($month == 10)
                          {
                            $oct = $totalquantity;
                          }
                            if($month == 11)
                          {
                            $nov = $totalquantity;
                          }
                            if($month == 12)
                          {
                            $dec = $totalquantity;
                          }
                          }

                          echo '<div  style="height: auto" class="col-xs-9">
                          <canvas id="canvas"></canvas>
                          </div>
                          <div  style="height: 100%" class="pi-box col-xs-3">
                          <div class="pie_head"><i class="fa fa-calendar"></i> Yearly Pie Chart</div>
                          <h2 class="dated">'.date("Y").'</h2>
                          <canvas id="piecan"></canvas>
                          </div>';

                          
                        } 

                        catch (Exception $e) {
                          echo "Connection failed: " . $e->getMessage();
                        }
                        $conn = null;
                      ?>
                    <script>
                      $jan = <?php echo $jan; ?>;
                      $feb = <?php echo $feb; ?>;
                      $mar = <?php echo $mar; ?>;
                      $apr = <?php echo $apr; ?>;
                      $may = <?php echo $may; ?>;
                      $jun = <?php echo $jun; ?>;
                      $jul = <?php echo $jul; ?>;
                      $aug = <?php echo $aug; ?>;
                      $sep = <?php echo $sep; ?>;
                      $oct = <?php echo $oct; ?>;
                      $nov = <?php echo $nov; ?>;
                      $dec = <?php echo $dec; ?>;
                      $year = <?php echo date("Y"); ?>;

                      var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                      var color = Chart.helpers.color;
                      var horizontalBarChartData = {
                        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        datasets: [{
                          label: 'Sales',
                          backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                          borderColor: window.chartColors.blue,
                          borderWidth: 1,
                          data: [$jan,$feb,$mar,$apr,$may,$jun,$jul,$aug,$sep,$oct,$nov,$dec]
                        }]
                      };

                      var config = {
                        type: 'pie',
                        data: {
                          datasets: [{
                            data: [$jan,$feb,$mar,$apr,$may,$jun,$jul,$aug,$sep,$oct,$nov,$dec],
                            backgroundColor: [
                              window.chartColors.red,
                              window.chartColors.orange,
                              window.chartColors.yellow,
                              window.chartColors.green,
                              window.chartColors.blue,
                            ],
                            label: 'Sales'
                          }],
                          labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                        },

                        options: {
                          responsive: true,
                          legend: {
                            display: false,
                            position: 'right',
                          },
                          title: {
                            display: false,
                            text: 'Yearly Pie Chart'
                          }
                        }
                      };

                      window.onload = function() {
                        var ctx = document.getElementById("canvas").getContext("2d");
                        window.myHorizontalBar = new Chart(ctx, {
                          type: 'horizontalBar',
                          data: horizontalBarChartData,
                          options: {
                              elements: {
                                  rectangle: {
                                      borderWidth: 2,
                                  }
                              },
                              responsive: true,
                              legend: {
                                  position: 'top',
                              },
                              title: {
                                  display: false,
                                  text: 'Chart.js Horizontal Bar Chart'
                              }
                          }
                        });

                        var ct = document.getElementById("piecan").getContext("2d");
                        window.myPie = new Chart(ct, config);
                      };
                    </script>
                  </div>
                </div>
              </div><br>
              <?php
                include 'config.php';
                try{
                  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                  echo "<h3 class='page-header'><b>Sticky Notes</b></h3> 
                        <div class='panel panel-default'>
                        <div class='panel-heading'>"; 
              ?>
                        <a href="./notes/" onclick="centeredPopup(this.href,'Add Notes','470','540','no');return false"><button class="myButton btn btn-theme"><i class='fa fa-edit fa-fw'></i> Add Notes</button></a>
              <?php
                echo "</div>";
                echo '<div class="notes"><ul>';
                $getnotes = $conn->prepare(" SELECT * FROM NOTES ORDER BY ID DESC");
                $getnotes->execute();
                while ($row = $getnotes->fetch(PDO::FETCH_ASSOC)){
                  $id = $row['ID'];
                  $title = $row['TITLE'];
                  $texts = $row['TEXT'];
                  echo "<li>";
              ?>
              <a href="./notes/edit.php?notesid=<?php echo $id ?>" onclick="centeredPopup(this.href,'Add Notes','470','590','no');return false">
              <?php
                echo "<h2>".htmlentities($title)."</h2><p>".htmlentities($texts)."</p></a></li>";}} 
                catch (PDOException $e){echo "Connection failed: " . $e->getMessage();}
                $conn = null;
              ?>
            </ul>
          </div>

          <script language="javascript">
            var popupWindow = null;
            function centeredPopup(url,winName,w,h,scroll){
              LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
              TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
              settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
              popupWindow = window.open(url,winName,settings)}
          </script>
        </div>
      </div>
    </div>

    <?php include('include/footer.php');?>
    <script src="js/gritter/js/jquery.gritter.js"></script>
    <script src="js/gritter-conf.js"></script>
  </body>
</html>