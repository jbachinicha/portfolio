   	<header class="logo1 col-lg-12 noprint" style="position: fixed; z-index: 99; border-bottom:3px solid #3c2f2f">
			<div class="row">
				<div style="float: left; position: fixed; padding: 10px; margin-left: 12px">
					<script src="js/date_time.js"></script> 
					<a href="#" class="sidebar-icon"> <span class="fa fa-home"></span></a> <span class="web-name">WGB Construction</span><br>
					<b class="date-container" style="color: #fff;"><span id="date_time"></span></b>
        			<script type="text/javascript">window.onload = date_time('date_time');</script>
				</div>
				<div class="nav notify-row" id="top_menu" style="margin-left: 300px;">
                <!--  notification start -->
                <ul class="nav top-menu">
                    <li id="header_inbox_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#" style="margin-right: 5px;">
                            <i class="fa fa-bell" style="margin: 5px !important"></i>
                            <i class="fa fa-caret-down" style="font-size: 15px"></i>
                                    <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, "SELECT COUNT(*) AS TOTAL FROM SALES WHERE DAY(date_added)=DAY(CURDATE()) AND MONTH(date_added)=MONTH(CURDATE())");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $total_sales = $row['TOTAL'];

                                            ?>
                                            <h4 id="badge1" class='badge'><b><?php echo "$total_sales"; ?></b></h4>
                                    <?php
                                        }

                                        if ($total_sales == 0) { ?>
                                            <script>
                                                var empt = document.getElementById('badge1');
                                                empt.style.display = "none";
                                            </script>
                                    <?php
                                            
                                        }
                                    ?>     
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-green"></div>
                            <li>
                                <p class="green">Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, "SELECT COUNT(*) AS TOTAL,SUM(qty) AS TQ, SUM(total) AS TA FROM SALES WHERE DAY(date_added)=DAY(CURDATE()) AND MONTH(date_added)=MONTH(CURDATE())");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $total_sales = $row['TOTAL'];
                                            $sold = $row['TQ'];
                                            $ammount = $row['TA'];

                                            ?>
                                            <h5><i class=" fa fa-money"></i> Today's Sales:</h5>
                                            <span class="subject">
                                                <b><span><?php echo "Total Amount: $ammount"; ?></span></b><br>
                                                <b><span><?php echo "Total Sales: $total_sales"; ?></span></b><br>
                                                <b><span><?php echo "Total Items Sold: $sold"; ?></span></b>
                                            </span>
                                    <?php
                                        }
                                    ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li id="header_inbox_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#" style="margin-right: 5px;">
                            <i class="fa fa-truck" style="margin: 5px !important"></i>
                            <i class="fa fa-caret-down" style="font-size: 15px"></i>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-green"></div>
                            <li>
                                <p class="green">Delivery</p>
                            </li>
                            <li>
                                <a href="calendar.php">
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li id="header_inbox_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
                            <i class="fa fa-refresh" style="margin: 5px !important"></i>
                            <i class="fa fa-caret-down" style="font-size: 15px"></i>
                            <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, " SELECT COUNT(*) AS COUNTLOW FROM INVENTORY WHERE prod_qty < 50");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $countlow = $row['COUNTLOW'];
                                            ?>
                                            <h4 id="badge" class='badge'><b><?php echo "$countlow"; ?></b></h4>
                                    <?php
                                        }

                                        if ($countlow == 0) { ?>
                                            <script>
                                                var empt = document.getElementById('badge');
                                                empt.style.display = "none";
                                            </script>
                                    <?php
                                            
                                        }
                                    ?>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-green"></div>
                            <li>
                                <p class="green">Reorders</p>
                            </li>
                            <li>
                                <a href="#">
                                    <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, " SELECT COUNT(*) AS COUNTLOW FROM INVENTORY WHERE prod_qty < 50");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $countlow = $row['COUNTLOW'];
                                            ?>
                                            <h5> Stock below 50 pcs:</h5>
                                            <span class="subject">
                                                <i class='fa fa-shopping-cart fa-fw'></i> <b><?php echo "$countlow"; ?></b> Stock Is Running Low<br>
                                    <?php
                                        }
                                    ?>

                                    <?php
                                        $conn = mysqli_connect("localhost","root","","wgb");
                                        $q = mysqli_query($conn, " SELECT * FROM INVENTORY WHERE prod_qty <50");
                                        while ($row = mysqli_fetch_assoc($q)) { 
                                            $name = $row['prod_name'];
                                            $quantity = $row['prod_qty'];
                                            ?>
                                                <br><i class='low'><?php echo $name ?>: <b class='low'><?php echo $quantity; ?> left</b></i>
                                                <!--span style='margin-left: 60px; background-color: red; padding: 5px; border-radius: 10px; color: #fff;' onclick="order();">
                                                    <i class='fa fa-refresh'></i>Re-order
                                                </span-->
                                    <?php
                                        }
                                    ?>
                                </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>

				<div class="profile_details w3l" style="float: right;">
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							<div class="profile_img">
                                <?php
                                    $q = mysqli_query($conn, "SELECT * FROM admin WHERE admin_id = '$_SESSION[admin_id]' ");
                                    while ($row = mysqli_fetch_assoc($q)) { ?>
							  <span class="prfil-img"><img src="dist/uploads/<?php echo $row['pict'];?>" alt=""> </span>
                              <?php } ?>
								<div class="user-name">
								</div>
								<i class="fa fa-angle-down"></i>
								<!-- <i class="fa fa-angle-up"></i> -->
								<div class="clearfix"></div>	
							</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
                                <li>
									<h4><?php require'account.php'; echo $name;?></h4>
                                    <span><?php require'account.php'; echo $type;?></span>
                                </li>
							  <li> <a href="profile_check.php"><i class="fa fa-user"></i> Profile</a> </li> 
								<li> <a href="#" data-toggle="modal" data-target="#logout"><i class="fa fa-power-off"></i> Logout</a> </li>
								<li> <a href="lock_screen.php"><i class="fa fa-lock"></i> Lock</a> </li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</header>