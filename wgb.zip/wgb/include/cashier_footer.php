
<div class="clearfix"></div>	
<footer class="site-footer">
  <!-- <div class="text-right">&#169; Copyright 2017 SCCPub, Inc. | Powered by <a>Randz PC</a> &nbsp;&nbsp;</div> -->
</footer>	
</div>

<script src="js/Chart.bundle.js"></script>
<script src="js/utils.js"></script>
<script src="js/jquery.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/raphael-min.js"></script>
