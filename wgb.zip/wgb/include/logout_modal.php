<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="myModalLabel">Logout</h4>
          </div>
          <div class="modal-body">Are you sure you want to Logout?</div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            <a href="logout.php"><button type="button" class="btn btn-primary">Logout</button></a>
          </div>
        </div>
      </div>
    </div>