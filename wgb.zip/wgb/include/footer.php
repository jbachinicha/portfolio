<div class="sidebar-menu" style="z-index: 0;">
	<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
  <div class="menu"><br><br><br><br><br>
		<ul id="menu" >

			<li><a href="home.php" id="dashboard"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>


      <li><a href="inventory.php" id="inventory"><i class="fa fa-dropbox" aria-hidden="true"></i><span>Inventory</span><div class="clearfix"></div></a></li>

      <li><a href="calendar.php" id="delivery"><i class="fa fa-car"></i><span>Delivery</span><div class="clearfix"></div></a></li>

      <!-- <li><a href="purchases.php" id="purchases"><i class="fa fa-money" aria-hidden="true"></i><span> Purchases</span><div class="clearfix"></div></a></li> -->

      <li><a href="manage_customer.php" id="customer"><i class="fa fa-book" aria-hidden="true"></i><span>Customer</span><div class="clearfix"></div></a></li>

      <li><a href="manage_employee.php" id="employee"><i class="fa fa-group" aria-hidden="true"></i><span> Employee</span><div class="clearfix"></div></a></li>

      <li><a href="attendance.php" id="attend"><i class="fa fa-list" aria-hidden="true"></i><span> Attendance</span><div class="clearfix"></div></a></li>
      <li><a href="manage_employee_payroll.php" id="payroll"><i class="fa fa-list" aria-hidden="true"></i><span> Payroll</span><div class="clearfix"></div></a></li>
      <li><a href="cash_advance.php" id="cashAdvance"><i class="fa fa-list" aria-hidden="true"></i><span> Cash Advance</span><div class="clearfix"></div></a></li>

      <li><a href="reports.php" id="reports"><i class="fa fa-bar-chart" aria-hidden="true"></i><span> Reports</span><div class="clearfix"></div></a></li>

      <li><a href="log.php" id="logs"><i class="fa fa-external-link" aria-hidden="true"></i>  <span>Logs</span><div class="clearfix"></div></a></li>

      <!-- <li><a href="settings.php" id="settings"><i class="fa fa-cogs" aria-hidden="true"></i>  <span>Settings</span><div class="clearfix"></div></a></li> -->

		</ul>
	</div>
</div>
<div class="clearfix"></div>	
<footer class="site-footer">
  <!-- <div class="text-right" style="color: #000;">&#169; Copyright 2017 SCCPub, Inc. | Powered by <a>Randz PC</a> &nbsp;&nbsp;</div> -->
</footer>	
</div>
<!-- <script>
	var toggle = true;
	$(".sidebar-icon").click(function() {                
	  if (toggle){
		  $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
		  $("#menu span").css({"position":"absolute"});}
	  else{
			$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
				setTimeout(function() {
			$("#menu span").css({"position":"relative"});}, 400);}
		toggle = !toggle;});
</script> -->

<script src="js/Chart.bundle.js"></script>
<script src="js/utils.js"></script>
<script src="js/jquery.js"></script>
<!-- <script src="js/jquery.nicescroll.js"></script> -->
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/raphael-min.js"></script>
