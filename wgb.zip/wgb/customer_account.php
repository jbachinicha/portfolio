<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('customer').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
    <div class="breadcrumb">
    <section class="content-header">
        
          <?php
          if(isset($_REQUEST['cid']))
            {
              $cid=$_REQUEST['cid'];
            }
            else
            {
            $cid=$_POST['cid'];
          }
          ?>
            <a class = "btn btn-danger noprint" href = "manage_customer.php"><i class ="fa fa-arrow-left" style="color: #fff;"></i> Back</a> 
            
          </section>
          <br>

          <!-- Main content -->
          <section class="content">
            <div class="row">
	      <div class="col-md-3">
              <div class="box box-primary">
                <div class="box-body bord">
                  <!-- Date range -->
		  <?php
		    
		      $query=mysqli_query($conn,"select * from customer where cust_id='$cid'")or die(mysqli_error());
			       $row=mysqli_fetch_array($query);
		  ?>	
		    <img class = "profile_pic" src = "dist/uploads/<?php echo $row['cust_pic'];?>"><br><br>
                  <div class="form-group">
                    <label for="date">Customer Name:</label>
                    <div class="input-group col-md-12">
                      <h3><?php echo $row['cust_last'].", ".$row['cust_first'];?></h3>
                    </div><!-- /.input group -->
                  </div><!-- /.form group -->
		  
                  <div class="form-group">
                    <label for="date">Address:</label>
                    <div class="input-group col-md-12">
                      <?php echo $row['cust_address'];?>
                    </div><!-- /.input group -->
                  </div><!-- /.form group -->
                  <div class="form-group">
                    <label for="date">Contact:</label>
                    <div class="input-group col-md-12">
                      <?php echo $row['cust_contact'];?>
                    </div><!-- /.input group -->
                  </div><!-- /.form group -->
                  <!--div class="form-group">
                    <label for="date">Balance:</label>
                    <div class="input-group col-md-12">
                      <h3><?php echo number_format($row['balance'],2);?></h3>
                    </div>
                  </div--><!-- /.form group -->
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
            
            <div class="col-xs-9">
              <div class="nav-tabs-custom">
                <h3>Payment History</h3>
              	<!--div class="btn-group btn-group-justified breadcrumb">
						  <div class="btn-group">
						    <button type="button" class="btn btn-theme"><a href="#fa-icons" data-toggle="tab" aria-expanded="true">Credit History</a></button>
						  </div>
						  <div class="btn-group">
						    <button type="button" class="btn btn-theme"><a href="#cash" data-toggle="tab">Cash History</a></button>
						  </div>
						  <div class="btn-group">
						    <button type="button" class="btn btn-theme"><a href="#payments" data-toggle="tab" aria-expanded="false">Payments</a></button>
						  </div>
						</div-->
                <div class="tab-content">
                  <!-- Font Awesome Icons -->
                  
                  <!--div class="tab-pane active" id="fa-icons">
                    <table id="cre" class="table table-bordered table-striped">
                  <thead>
                      <tr>
                        <th>Credit #</th>                      
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Term</th>
                        <th>Payable for</th>
                        <th>Amount Due</th>
                        <th>Order Date</th>
                        <th>Due Date</th>
                        <th>Payment Status</th>
                        <th>View</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
   // $cid=$_REQUEST['cid'];
    $query1=mysqli_query($conn,"SELECT * FROM sales JOIN sales_details JOIN product JOIN inventory JOIN term WHERE cust_id='$cid' order by date_added desc")or die(mysqli_error($conn));
    while($row1=mysqli_fetch_array($query1)){
    
?>
                      <tr>
                        <td><?php echo $row1['term_id'];?></td>
                        <td><?php echo $row1['qty'];?></td>
                        <td><?php echo $row1['prod_price'];?></td>
                        <td><?php echo $row1['term'];?></td>
                        <td><?php echo $row1['payable_for'];?> month/s</td>
                        <td><?php echo $row1['due'];?></td>
                        <td><?php echo date("M d, Y",strtotime($row1['date_added']));?></td>
                       <td><?php echo date("M d, Y",strtotime($row1['due_date']));?></td>
                        <td><?php 
                        if ($row1['status']=='paid') 
                        echo "<span class='badge bg-green'>".$row1['status']."</span>";
                        else echo "<span class='badge bg-red'>unpaid</span>";
                        ?>

                      </td>
                      <td>
                        <a href="payment.php?cid=<?php echo $row['cust_id'];?>&sid=<?php echo $row1['sales_id'];?>"><i class="glyphicon glyphicon-share-alt"></i></a>
                        <a href="reprint.php?sid=<?php echo $row1['sales_id'];?>"><i class="glyphicon glyphicon-print"></i></a>
                        <a href="print.php?sid=<?php echo $row1['sales_id'];?>&cid=<?php echo $row['cust_id'];?>"><i class="glyphicon glyphicon-list"></i></a>
                      </td>  
                      </tr>
    <?php }?>       
                      </tbody>
                  
                  </table>
                  </div>

                  <div class="tab-pane" id="cash">
                    <table id="cas" class="table table-bordered table-striped">
                  <thead>
                      <tr>
                        <th>Transaction #</th>                      
                        <th>Product Name</th>
                        <th>Product Code</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Amount</th>
                        <th>Date Paid</th>
                        <th>Reprint</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
   // $cid=$_REQUEST['cid'];
    $query1=mysqli_query($conn,"select * from sales natural join sales_details natural join product where cust_id='$cid' and modeofpayment='cash' order by date_added desc")or die(mysqli_error($conn));
    while($row1=mysqli_fetch_array($query1)){
    
?>
                      <tr>
                        <td><?php echo $row1['sales_id'];?></td>
                        <td><?php echo $row1['prod_name'];?></td>
                        <td><?php echo $row1['serial'];?> month/s</td>
                        <td><?php echo $row1['price'];?></td>
                        <td><?php echo $row1['qty'];?></td>
                        <td><?php echo number_format($row1['total'],2);?></td>
                        <td><?php echo date("M d, Y",strtotime($row1['date_added']));?></td>
                        <td><a href="reprint_cash.php?sid=<?php echo $row1['sales_id'];?>"><i class="glyphicon glyphicon-print"></i></a>
                      </td>  
                      </tr>
    <?php }?>       
                      </tbody>
                  
                  </table>
                  </div--><!-- /#fa-icons -->
                  <!-- glyphicons-->
                  <div class="tab-pane active" id="payments">
                    <table id="pay" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Amount Paid</th>
                        <th>Due Date</th>
                        <th>Date of Payment</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
    $cid=$_REQUEST['cid'];
    $query3=mysqli_query($conn,"select * from payment natural join sales_details natural join product where cust_id='$cid' and status='paid' order by payment_date desc")or die(mysqli_error());
    while($row3=mysqli_fetch_array($query3)){
    
?>
                      <tr>
                        <td><?php echo $row3['serial'];?></td>
                        <td><?php echo $row3['prod_name'];?></td>
                        <td><?php echo $row3['payment'];?></td>
                        <td><?php echo date("M d, Y",strtotime($row3['payment_for']));?></td>
                        <td><?php echo date("M d, Y",strtotime($row3['payment_date']));?></td>
    
                        
                      </tr>
    <?php }?>       
                    </tbody>
                  
                  </table>
                    
                  </div><!-- /#ion-icons -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div>
          </div><!-- /.row -->
	  
            
          </section>
      </div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#pay").DataTable();
        $("#cas").DataTable();
        $("#cre").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    <script type = "text/javascript">
		$(document).ready(function(){
			$result = $('<center><label>Deleting...</label></center>');
			$('.deladmin_id').click(function(){
				$admin_id = $(this).attr('value');
				$(this).parents('td').empty().append($result);
				$('.deladmin_id').attr('disabled', 'disabled');
				$('.eadmin_id').attr('disabled', 'disabled');
				setTimeout(function(){
					window.location = 'delete_product.php?prod_id=' + $admin_id;
				}, 1000);
			});
		});
	</script>

</body>
</html>