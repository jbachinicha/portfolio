<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
	<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Sales <i class="fa fa-angle-right"></i> Sales Report</li>
    </ol>

              <section class="content breadcrumb">
                <a class="btn btn-danger" href="daily.php" style="color:#fff;"><i class="fa fa-arrow-left" style="color: #fff"></i> Back</a><br>

                <h1 class='page-header'>Show Sales</h1>

                <form action="sales_report.php" method="get">

                  <input type="submit" name="today" value="Daily Sales" class="myButton">&nbsp;
                  <input type="submit" name="month" value="Monthly Sales" class="myButton">&nbsp;
                  <input type="submit" name="year" value="Yearly Sales" class="myButton">&nbsp;

                  From <input type="date" size='5' name="from" id="datepicker-start">&nbsp;
                  To <input type="date" size='5' name="to" id="datepicker-end">&nbsp; 

                  <input type="submit" name="range" value="Show" class="myButton">

                </form>
                <?php

if(isset($_GET['today']))
{
  include 'today.php';
}
if(isset($_GET['month']))
{
  include 'month.php';
}
if(isset($_GET['year']))
{
  include 'year.php';
}
if(isset($_GET['from']) && isset($_GET['to']) && isset($_GET['range']))
{
  $from = $_GET['from'];
  $to = $_GET['to'];
  
  //echo "from : $from <br> to : $to";
  include 'range.php';
}

?>
              </section>

</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>
</body>
</html>