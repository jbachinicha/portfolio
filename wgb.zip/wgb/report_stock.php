<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('reports').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">

          <section class="content breadcrumb well">
            <div class="row">
              <div class="col-md-12">
                <div class="box box-primary">
                  <div class="box-header with-border noprint">
                    <h3 class="box-title">Reports</h3>
                  </div>
                  <div class="box-body">
                  	<br>

                  		<div class="btn-group noprint">
						    <button type="button" class="btn btn-theme"><a href="reports.php" aria-expanded="true"><i class="fa fa-bar-chart" style="color: #fff"></i> Sales Reports</a></button>
						</div>
						<div class="btn-group noprint">
						   	<button type="button" class="btn btn-theme"><a href="report_stock.php" ><i class="fa fa-inbox" style="color: #fff"></i> Stock In Reports</a></button>
						</div>
						<br><br>


								<div class="btn-group noprint">
									 <button type="button" class="btn btn-theme"><a href="#daily" data-toggle="tab" aria-expanded="true"><i class="fa fa-calendar-o" style="color: #fff"></i> Daily</a></button>
								</div>
								<div class="btn-group noprint">
									<a class = "btn btn-theme btn-print noprint" data-toggle="tab" href = "#monthly" ><i class ="fa fa-calendar-o" style="color: #fff;"></i> Monthly</a>
								</div>
								<div class="btn-group noprint">
									<a class = "btn btn-theme btn-print noprint" data-toggle="tab" href = "#yearly" ><i class ="fa fa-calendar-o" style="color: #fff;"></i> Yearly</a>
								</div>

								<a class = "btn btn-info btn-print noprint" href = "" onclick = "window.print()"><i class ="glyphicon glyphicon-print" style="color: #fff;"></i> Print</a>

								<div class="tab-content">
									<div class="tab-pane active" id="daily">
							        <?php include('connect.php'); ?>
							        <center>      
							                  <h5><b>Jinska ION Water Station</b> </h5>  
							                  <h6>Address: Sabang, Sibonga, Cebu</h6>
							                  <h6>Contact #: 09353993218</h6>
							          <h5><b>Product Inventory as of today, <?php echo date("M d, Y h:i a");?></b></h5></center>
							           
							           <br>  <br> 
							            
							                  <table id="example1" class="table table-bordered table-striped">
							                    <thead>
							          
							                      <tr>
							                        <th>Product Code</th> 
							                        <th>Product Name</th>                      
							                        <th>Qty Left</th>
							                        <th>Qty Added</th>
							                        <th>Date Stocked</th>
							                        <th>Price</th>
							                        <th>Total</th>
							                        <th>Reorder</th>
							                       
							                      </tr>
							                    </thead>
							                    <tbody>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM inventory i JOIN stockin s WHERE DAY(date)=DAY(CURDATE()) AND i.prod_id=s.prod_id ")or die(mysqli_error());
							    $grand=0;
							    while($row=mysqli_fetch_array($query)){
							      $total=$row['prod_price']*$row['prod_qty'];
							      $grand+=$total;
							?>
							                      <tr>
							                        <td><?php echo $row['serial'];?></td>
							                        <td><?php echo $row['prod_name'];?></td>
							                        <td><?php echo $row['prod_qty'];?></td>
							                        <td><?php echo $row['qty'];?></td>
							                        <td><?php echo $row['date'];?></td>
							            
							            <td><?php echo $row['prod_price'];?></td>
							            <td><?php echo number_format($total,2);?></td>
							            <td class="text-center"><?php if ($row['prod_qty']<=$row['reorder'])echo "<span class='badge bg-red' style='background-color: red;'><i class='fa fa-refresh' style='color: #fff;'></i> Reorder</span>";?></td>
							                       
							                      </tr>

							<?php }?>           
							                    </tbody>
							                    <tfoot>
							                      <tr>
							                        <th colspan="6">Total</th>
							                        
							            
							            <th colspan="2">P<?php echo number_format($grand,2);?></th>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'")or die(mysqli_error($con));
							    $row=mysqli_fetch_array($query);
							    $name = $row['firstname']." ".$row['lastname'];
							 
							?>                      
							                             </tr>
							                    </tfoot>
							                  </table>
							                  <label>Prepared By: <?php echo $name;?></label>
							    </div>

							    <div class="tab-pane" id="monthly">
							        <?php include('connect.php'); ?>
							        <center>      
							                  <h5><b>Jinska ION Water Station</b> </h5>  
							                  <h6>Address: Sabang, Sibonga, Cebu</h6>
							                  <h6>Contact #: 09353993218</h6>
							          <h5><b>Product Inventory as of today, <?php echo date("M Y h:i a");?></b></h5></center>
							           
							           <br>  <br> 
							            
							                  <table id="example1" class="table table-bordered table-striped">
							                    <thead>
							          
							                      <tr>
							                        <th>Product Code</th> 
							                        <th>Product Name</th>                      
							                        <th>Qty Left</th>
							                        <th>Qty Added</th>
							                        <th>Date Stocked</th>
							                        <th>Price</th>
							                        <th>Total</th>
							                        <th>Reorder</th>
							                       
							                      </tr>
							                    </thead>
							                    <tbody>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM inventory i JOIN stockin s WHERE MONTH(date)=MONTH(CURDATE()) AND i.prod_id=s.prod_id")or die(mysqli_error());
							    $grand=0;
							    while($row=mysqli_fetch_array($query)){
							      $total=$row['prod_price']*$row['prod_qty'];
							      $grand+=$total;
							?>
							                      <tr>
							                        <td><?php echo $row['serial'];?></td>
							                        <td><?php echo $row['prod_name'];?></td>
							                        <td><?php echo $row['prod_qty'];?></td>
							                        <td><?php echo $row['qty'];?></td>
							                        <td><?php echo $row['date'];?></td>
							            
							            <td><?php echo $row['prod_price'];?></td>
							            <td><?php echo number_format($total,2);?></td>
							            <td class="text-center"><?php if ($row['prod_qty']<=$row['reorder'])echo "<span class='badge bg-red' style='background-color: red;'><i class='fa fa-refresh' style='color: #fff;'></i> Reorder</span>";?></td>
							                       
							                      </tr>

							<?php }?>           
							                    </tbody>
							                    <tfoot>
							                      <tr>
							                        <th colspan="6">Total</th>
							                        
							            
							            <th colspan="2">P<?php echo number_format($grand,2);?></th>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'")or die(mysqli_error($con));
							    $row=mysqli_fetch_array($query);
							    $name = $row['firstname']." ".$row['lastname'];
							 
							?>                      
							                             </tr>
							                    </tfoot>
							                  </table>
							                  <label>Prepared By: <?php echo $name;?></label>
							    </div>

							    <div class="tab-pane" id="yearly">
							        <?php include('connect.php'); ?>
							        <center>      
							                  <h5><b>Jinska ION Water Station</b> </h5>  
							                  <h6>Address: Sabang, Sibonga, Cebu</h6>
							                  <h6>Contact #: 09353993218</h6>
							          <h5><b>Product Inventory as of today, <?php echo date("Y h:i a");?></b></h5></center>
							           
							           <br>  <br> 
							            
							                  <table id="example1" class="table table-bordered table-striped">
							                    <thead>
							          
							                      <tr>
							                        <th>Product Code</th> 
							                        <th>Product Name</th>                      
							                        <th>Qty Left</th>
							                        <th>Qty Added</th>
							                        <th>Date Stocked</th>
							                        <th>Price</th>
							                        <th>Total</th>
							                        <th>Reorder</th>
							                       
							                      </tr>
							                    </thead>
							                    <tbody>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM inventory i JOIN stockin s WHERE YEAR(date)=YEAR(CURDATE()) AND i.prod_id=s.prod_id")or die(mysqli_error());
							    $grand=0;
							    while($row=mysqli_fetch_array($query)){
							      $total=$row['prod_price']*$row['prod_qty'];
							      $grand+=$total;
							?>
							                      <tr>
							                        <td><?php echo $row['serial'];?></td>
							                        <td><?php echo $row['prod_name'];?></td>
							                        <td><?php echo $row['prod_qty'];?></td>
							                        <td><?php echo $row['qty'];?></td>
							                        <td><?php echo $row['date'];?></td>
							            
							            <td><?php echo $row['prod_price'];?></td>
							            <td><?php echo number_format($total,2);?></td>
							            <td class="text-center"><?php if ($row['prod_qty']<=$row['reorder'])echo "<span class='badge bg-red' style='background-color: red;'><i class='fa fa-refresh' style='color: #fff;'></i> Reorder</span>";?></td>
							                       
							                      </tr>

							<?php }?>           
							                    </tbody>
							                    <tfoot>
							                      <tr>
							                        <th colspan="6">Total</th>
							                        
							            
							            <th colspan="2">P<?php echo number_format($grand,2);?></th>
							<?php
							    $query=mysqli_query($conn,"SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'")or die(mysqli_error($con));
							    $row=mysqli_fetch_array($query);
							    $name = $row['firstname']." ".$row['lastname'];
							 
							?>                      
							                             </tr>
							                    </tfoot>
							                  </table>
							                  <label>Prepared By: <?php echo $name;?></label>
							    </div>
						</div>
                  </div>
                </div>
              </div>
            </div>
          </section>

</div>
<div class="noprint"><?php include('include/footer.php');?></div>
</body>
</html>