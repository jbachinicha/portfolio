<?php 
  require_once 'connect.php';
  include('valid.php');

  $id           = $_POST['id'];
  $deduction    = $_POST['deduction'];
  $overtime     = $_POST['overtime'];
  $bonus        = $_POST['bonus'];
  $idh = $_SESSION['admin_id'];
  $date = date("Y-m-d H:i:s");
  $qedit_admin = $conn->query("SELECT * FROM `employee` WHERE `employee_id` = '$_REQUEST[employee_id]'") or die(mysqli_error());
  $fedit_admin = $qedit_admin->fetch_array();
  $firstname = $fedit_admin['first_name'];

  $remarks="updated $firstname account"; 

  mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$idh','$remarks','$date')")or die(mysqli_error($conn));
  mysqli_query($conn,"UPDATE `employee` SET `deduction`='$deduction', `overtime`='$overtime', `bonus`='$bonus' WHERE `employee_id` = '$_REQUEST[employee_id]'")or die(mysqli_error($conn));
      
      echo '
      <script type = "text/javascript">
          alert("Account Updated");
          window.location = "manage_employee.php";
        </script>
      ';

?>