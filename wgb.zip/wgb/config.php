<?php

//db info needed to connect
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wgb";

?>