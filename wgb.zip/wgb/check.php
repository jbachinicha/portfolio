<?php
require_once 'valid.php';
require 'account.php';
 if ($type == 'Administrator') {
 	header('location: home.php');
 }
 else{
 	header('location: daily.php');
 }



?>