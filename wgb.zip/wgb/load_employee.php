<?php
	require_once 'connect.php';
	$qedit_admin = $conn->query("SELECT * FROM employee e JOIN position p JOIN schedules s WHERE e.employee_id = '$_REQUEST[employee_id]' AND e.position_id=p.id AND e.schedule_id=s.id ") or die(mysqli_error());
	$fedit_admin = $qedit_admin->fetch_array();
?>
<div><button id = "back" type = "button" class = "btn btn-danger"><a href="manage_employee.php" class="gl f"><span class = "fa fa-arrow-circle-o-left"></span> back</a></button></div>
<div class="col-lg-3"></div>
<div class = "col-lg-6">
	<form method = "POST" action = "edit_employee.php?employee_id=<?php echo $fedit_admin['employee_id']?>" enctype = "multipart/form-data" >
		<div class="form-group">
									<label>Edit Employee Data</label>
									<hr>
								</div>
		<div class="form-group" >
			<label>Employee ID:</label>
			<input type = "text" value = "<?php echo $fedit_admin['employee_id']?>" name = "employee_id" class = "form-control disabled" readonly />
		</div>
		<div class="form-group">
			<label>First Name:</label>
			<input type = "text" value = "<?php echo $fedit_admin['first_name']?>" required = "required" name = "firstname" class = "form-control" />
		</div>
		<div class="form-group">
			<label>Middle Name:</label>
			<input type = "text" value = "<?php echo $fedit_admin['middle_name']?>" required = "required" name = "middlename" class = "form-control" />
		</div>
		<div class="form-group">
			<label>Last Name:</label>
			<input type = "text" value = "<?php echo $fedit_admin['last_name']?>" required = "required" name = "lastname" class = "form-control" />
		</div>
		<div class="form-group">
			<label>Address:</label>
			<input type = "text" value = "<?php echo $fedit_admin['address']?>" required = "required" name = "address" class = "form-control" />
		</div>
		<div class="form-group">
                  <label for="empstatus">Gender:</label>
                  <select class="form-control" name="gender" required>
                    <option value="<?php echo $fedit_admin['gender']?>"><-- <?php echo $fedit_admin['gender']?> --></option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
		<div class="form-group">
			<label>Phone Number:</label>
			<input type = "text" value = "<?php echo $fedit_admin['phone']?>" required = "required" name = "phone" class = "form-control" />
		</div>
		<div class="form-group">
			<label>Position:</label>
			<select class="form-control" name="position" required>
				<option value = "<?php echo $fedit_admin['position_id']?>"><-- <?php echo $fedit_admin['description']?> --></option>
				<?php 
                      include 'connect.php';

                      $q=mysqli_query($conn, "SELECT * FROM position")or die(mysqli_error($conn));
                      while ($row = mysqli_fetch_array($q)) {
                        echo "<option value='".$row['id']."'>".$row['description']."</option>";
                      }
                    ?>
			</select>
		</div>
		<div class="form-group">
			<input type="hidden" name="schedule" value="<?php echo $fedit_admin['schedule_id']?>">
		</div>
		<div class="form-group">
			<label>Date Employed:</label>
			<input type = "date" value = "<?php echo $fedit_admin['date_employed']?>" required = "required" name = "date_employed" class = "form-control" />
		</div>
		<div class="form-group col-xs-3">
						<label>Picture:</label>
						<img src="dist/uploads/<?php echo $fedit_admin['pic']?>" height="100px" width="100px" id="pic" style="border: solid white 2px;">
					</div>
					<div class="form-group col-xs-9">
					  <input type="hidden" class="form-control" id="price" name="image1" value="<?php echo $fedit_admin['pic'] ?>">
					  <input type ="file" class="form-control" name="image" onchange="document.getElementById('pic').src=window.URL.createObjectURL(this.files[0])" /> 
						
					</div>
		<div class = "form-group">	
			<button class = "btn btn-primary" name = "edit_admin"><span class = "fa fa-edit"></span> Save Changes</button>
		</div>
	</form>		
</div>	