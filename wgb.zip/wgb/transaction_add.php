<?php 
	require_once 'connect.php';
	include('valid.php');
	$id=$_SESSION['admin_id'];

	$cid = $_POST['cid'];
	$name = $_POST['prod_name'];
	$qty = $_POST['qty'];
	$prod = $_POST['prod'];
	$pr = $_POST['gallprice'];
	$trans_id = $_POST['trans_id'];

	if (isset($_POST['addtocart'])){

	$q1=mysqli_query($conn,"SELECT * FROM inventory  WHERE prod_id='$name'")or die(mysqli_error());
	while ($r1=mysqli_fetch_array($q1)) {
		$quan = $r1['prod_qty'];

		if ($quan>0)
		{

		$query=mysqli_query($conn,"SELECT market_price, prod_id FROM inventory  WHERE prod_id='$name'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);
		$price=$row['market_price'];

		$query1=mysqli_query($conn,"SELECT * FROM temp_trans WHERE prod_id='$name' AND product='$prod'")or die(mysqli_error());
		$r=mysqli_fetch_array($query1);
		$count=mysqli_num_rows($query1);
		
		$total=$price*$qty;
		
		if ($count>0){
			mysqli_query($conn,"UPDATE temp_trans SET qty=qty+'$qty',price=price+'$total' WHERE prod_id='$name' AND product='$prod'")or die(mysqli_error());
	
		}
		else{

			mysqli_query($conn,"INSERT INTO temp_trans(temp_trans_id,prod_id,qty,price,admin_id,product) VALUES('$trans_id','$name','$qty','$pr','$id','$prod')")or die(mysqli_error($conn));
		}

	
		echo "<script>document.location='cash_transaction.php?trans_id=$trans_id'</script>"; 
		}
		else{
			echo "<script>alert('Not Enough Stock!!');window.document.location='cash_transaction.php'</script>";
		}
	}
}

/*
if (isset($_POST['addtocart'])) {
	$q2=mysqli_query($conn,"SELECT * FROM inventory  WHERE prod_id='$name'")or die(mysqli_error());
	while ($r2=mysqli_fetch_array($q2)) {
		$quan1 = $r2['prod_qty'];

		if ($quan1>0)
		{

		$query2=mysqli_query($conn,"SELECT * FROM temp_trans WHERE prod_id='$name' AND product='$prod'")or die(mysqli_error());
		$count=mysqli_num_rows($query2);
		
		$total=$pr*$qty;
		
		if ($count>0){
			mysqli_query($conn,"UPDATE temp_trans SET qty=qty+'$qty',price=price+'$total' WHERE prod_id='$name' AND product='$prod'")or die(mysqli_error());
	
		}
		else{
			mysqli_query($conn,"INSERT INTO temp_trans(prod_id,qty,price,admin_id,product) VALUES('$name','$qty','$pr','$id','$prod')")or die(mysqli_error($conn));
		}

	
		echo "<script>document.location='cash_transaction.php?cid=$cid'</script>"; 
		}
		else{
			echo "<script>alert('Not Enough Stock!!');window.document.location='cash_transaction.php?cid=$cid'</script>";
		}
	}
}*/

	
?>