<!DOCTYPE html>
<?php 
	session_start();
	if(ISSET($_SESSION['admin_id'])){
		header('location:check.php');
	}
?>
<html ng-app="app">
	<head>
	    <title>WGB Contruction Supply</title>

	    <link href="css/bootstrap.css" rel="stylesheet">
	    <link href="css/style1.css" rel="stylesheet">
	    <link href="css/style-responsive.css" rel="stylesheet">
	    <link href="css/css.css" rel="stylesheet">
	    <link rel="stylesheet" href="css/icomoon.css">
		<link rel="stylesheet" href="css/font-awesome.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

	    <script src="js/angular.min.js"></script>
	    <style type="text/css">
	    	.errortext{
	    		color:red;
	    	}
	    </style>
  	</head>

	<body ng-controller="myController">
		<div id="login-page">
			<div class="container">
				<div class="page-wrepper" style="justify-content: center">
					<form class="form-login" role="form" name="myForm" autocomplete="off" novalidate>
						<h2 class="form-login-heading">	login</h2>
						<div class="login-wrap">

							<div id = "username_warning" class="form-group">
								<div class="input-group">
									<span class="input-group-addon">
												<i class="icon-user"></i>
											</span>
									<input type="text" class = "form-control" id = "username" name="username" placeholder="Username" ng-minlength="10" ng-maxlength="30" ng-pattern="/^[a-zA-Z0-9_]*$/" ng-model="user.username" title="Username" required autofocus>
									<div class="errortext" ng-show="myForm.username.$dirty && myForm.username.$invalid">
										<span ng-show="myForm.username.$error.required">Username is required</span>
										<span ng-show="myForm.username.$error.minlength">Username must contain at 	least 10 characters</span>
										<span ng-show="myForm.username.$error.maxlength">Username should not be greater than 30 characters</span>
										<span ng-show="myForm.username.$error.pattern && !myForm.username.$error.minlength && !myForm.username.$error.maxlength">Only letters, numbers and underscore allowed</span>
									</div>
								</div>
							</div>

							<div id = "password_warning" class="form-group">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="icon-lock2"></i>
									</span>
									<input type="password" class = "form-control" id = "password" name="password" placeholder="Password" ng-minlength="10" ng-maxlength="30" ng-model="user.password" title="Password" required>
									<div class="errortext" ng-show="myForm.password.$dirty && myForm.password.$invalid">
										<span ng-show="myForm.password.$error.required">Password is required</span>
										<span ng-show="myForm.password.$error.minlength">Password contain atleast 10 characters</span>
										<span ng-show="myForm.password.$error.maxlength">Password should not be greater than 30 characters</span>
									</div>
								</div>
							</div>

							<div class="form-group">
								<button type="button" id = "login" class = "btn btn-theme btn-block" ng-disabled="myForm.$invalid" ng-click="submit()"><span class="icon-login "></span> Login</button>
								<button class="btn btn-theme btn-block cancel" style="width: 100%;"><span class="fa fa-close"></span> Cancel</button>
							</div>
						</div>
						<div id = "result"></div>
					</form>
				</div>
	        	
			</div>

			<script>
				document.getElementById('login').onclick = function() {
				}
				var app = angular.module('app', []);
			app.controller('myController', function($scope){
				$scope.valid = false;
				$scope.submit = function(){
					$scope.valid = true;
				}
				$scope.close = function(){
					$scope.valid = false;
				}
			});
			</script>
		</div>

		<div id="main-page">
		  	<div class="page-wrepper">
		  		<div class="full-web-name">
					<div class="block1">
						<div class="center">
							<h1><b>WGB Construction Supply</b></h1>
							<small>Management Information System</small>
						</div>
						<div class="logo"></div>
					</div>
		  			<p class="admin-btn"><a href="#" class="btn btn-primary btn-outline with-arrow btn-sm">Login <i class="fas fa-sign-in-alt"></i></a></p>
		  			<div class="bottom-notif" style="background-color: white;"></div>
		  		</div>
		  	</div>
	  	</div>
	  	<script src = "js/jquery.js"></script>
		<script src = "js/bootstrap.js"></script>
		<script src = "js/login.js"></script>
    	<script type="text/javascript" src="js/jquery.backstretch.min.js"></script>
    	<script>
    	</script>
	</body>
</html>