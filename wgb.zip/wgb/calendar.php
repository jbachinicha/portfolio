<!DOCTYPE HTML>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title><?php require'account.php'; echo $name;?></title>
<?php include('include/head_scripts.php');?>
<link type="text/css" rel="stylesheet" href="style.css"/>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('delivery').style;
        active.backgroundColor = "#be9b7b";
        active.color = "#fff";

        return false;
      });
</script>
</head>
<?php include_once('functions.php'); ?> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">
    <div class="breadcrumb well" style="height: 900px;"><br>


    
    <div class="grids">
		  <div class="w3-row w3-padding w3-border">

    <!-- Blog entries -->
    <div class="w3-col l12 s12">
    
      <!-- Blog entry -->
      <div class="w3-container w3-white w3-margin w3-padding-large">
        
          <h2 style="text-align: center";>Delivery Schedule</h2>
          <br>
          <div id="calendar_div">
	<?php echo getCalender(); ?>
</div>

          
            
      </div>
      
    </div>

  </div>
				</div>
      </div>

  <!--//content-inner-->
			<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>



</body>
</html>