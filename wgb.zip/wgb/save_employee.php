<?php
	require_once 'connect.php';
	include('valid.php');
	if(ISSET($_POST['save_employee'])){
		$id = $_SESSION['admin_id'];
		$letters = '';
		$numbers = '';
		foreach (range('A', 'Z') as $char) {
		    $letters .= $char;
		}
		for($i = 0; $i < 10; $i++){
			$numbers .= $i;
		}
		$employee_id = substr(str_shuffle($letters), 0, 3).substr(str_shuffle($numbers), 0, 9);
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$position = $_POST['position'];
		$schedule = $_POST['schedule'];
		$gender = $_POST['gender'];
		$empstatus = 'Hired';
		$date = date("Y-m-d H:i:s");


		$remarks="added $firstname as new employee";

		$q_admin = $conn->query("SELECT * FROM `employee` WHERE `employee_id` = '$employee_id'") or die(mysqli_error());
		$v_admin = $q_admin->num_rows;
		if($v_admin == 1){
			echo '
				<script type = "text/javascript">
					alert("Employee Exist!!");
					window.location = "manage_employee.php";
				</script>
			';
		}else{

			mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));

			mysqli_query($conn,"INSERT INTO `employee` VALUES('', '$employee_id', '$firstname', '$middlename', '$lastname', '$address','$phone','$date','$empstatus','default.gif','$gender','$position','$schedule')")or die(mysqli_error($conn));
			header("location: manage_employee.php");
			
		}
	}
