<!DOCTYPE html>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>Jinska Administrator</title>
<?php include('include/head_scripts.php');?>
<script type="text/javascript">
  $(document).ready(function () {

        var active = document.getElementById('customer').style;
        active.backgroundColor = "#52d3aa";
        active.color = "#fff";

        return false;
      });
</script>
</head> 
<body>

   <div class="page-container">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>

<div class="left-content">
<div class="mother-grid-inner" style="padding-top: 80px;">

<div class="col-xs-12 breadcrumb well">
              <div class="box box-primary">
    
                <div class="box-header">
                  <a class="btn btn-danger" href="manage_customer.php" style="color:#fff;"><i class="fa fa-arrow-left text-blue" style="color: #fff"></i> Back</a><br><br>
                  <h3>Customer List</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                      	<th>Picture</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Address</th>
						            <th>Contact #</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
		$query=mysqli_query($conn,"SELECT * FROM customer")or die(mysqli_error());
		$i=1;
		while($row=mysqli_fetch_array($query)){
      $cid=$row['cust_id'];
?>
                      <tr class="table-row">
                      	<td><img style="width:80px;height:60px" src="dist/uploads/<?php echo $row['cust_pic'];?>"></td>
					              <td><?php echo $row['cust_last'];?></td>
                        <td><?php echo $row['cust_first'];?></td>
                        <td><?php echo $row['cust_address'];?></td>
				            		<td><?php echo $row['cust_contact'];?></td>
                        <td>
                          <?php 
                      if ($row['status']=='Active') {
                        echo "<a href = '#'' class = 
                        'btn btn-success'><span class = 'fa fa-check'></span>Active</a>";
                      }
                      else{
                        echo "<a href = '#'' class = 
                        'btn btn-danger'><span class = 'fa fa-close'></span>Removed</a>";
                      }
?>
                        </td>
                        <td width="10%">
				<a href="<?php if ($row['credit_status']=='Active') echo "customer_account.php?cid=$cid";?>" class="btn btn-theme"><i class="glyphicon glyphicon-share-alt text-white"></i> Account</a>
				<a href="#updateordinance<?php echo $row['cust_id'];?>" data-target="#updateordinance<?php echo $row['cust_id'];?>" data-toggle="modal" style="color:#fff;" class="btn btn-success"><i class="glyphicon glyphicon-edit text-white"></i> Update&nbsp;&nbsp;&nbsp;</a>
        <a href="#delete<?php echo $row['cust_id'];?>" data-target="#delete<?php echo $row['cust_id'];?>" data-toggle="modal" style="color:#fff;" class="btn btn-danger"><i class="glyphicon glyphicon-trash text-white"></i> Remove&nbsp;&nbsp;</a>

				
						</td>
                      </tr>
	
 <div id="updateordinance<?php echo $row['cust_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none; margin-top: 130px;">
	<div class="modal-dialog">
	  <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update Customer Details</h4>
              </div>
              <div class="modal-body">
			  <form class="form-horizontal" method="post" action="customer_update.php" enctype='multipart/form-data'>
                
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Last Name</label>
					<div class="col-lg-9">
						<input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row['cust_id'];?>" required>  
						<input type="text" class="form-control" id="name" name="last" value="<?php echo $row['cust_last'];?>" required>  
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">First Name</label>
					<div class="col-lg-9">
						<input type="text" class="form-control" id="name" name="first" value="<?php echo $row['cust_first'];?>" required>  
					</div>
				</div>				
				<div class="form-group">
					<label class="control-label col-lg-3" for="file">Address</label>
					<div class="col-lg-9">
					    <textarea class="form-control" id="name" name="address" required><?php echo $row['cust_address'];?></textarea>  
					</div>
				</div> 
				<div class="form-group">
					<label class="control-label col-lg-3" for="price">Contact Number</label>
					<div class="col-lg-9">
					  <input type="text" class="form-control" id="price" name="contact" value="<?php echo $row['cust_contact'];?>" required>  
					</div>
				</div>
				<div class="form-group">
          						<label class="control-label col-lg-3" for="status">Status:</label>
          						<div class="col-lg-9">
              				<select class="form-control" name="status" required>
                  				<option value="Active">Active</option>
                  				<option value="Inactive">Inactive</option>
              				</select>
          				</div>
          			</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="price">Picture:</label>
					<div class="col-lg-9">
					  <input type="hidden" class="form-control" id="price" name="image1" value="<?php echo $row['cust_pic'];?>"> 
					  <input type="file" class="form-control" id="price" name="image">  
					</div>
				</div>
              <div class="modal-footer">
		<button type="submit" class="btn btn-theme">Save changes</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              </div>
			  </form>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->   
 </div>	


        <div id="delete<?php echo $row['cust_id'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none; margin-top: 130px;">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Sure to Remove Customer?</h4>
              </div>
              <div class="modal-body">
                <form class="form-horizontal" method="post" action="customer_remove.php" enctype='multipart/form-data'>
                        
                  <div class="modal-footer">
                    <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row['cust_id'];?>" required>
                    <button type="submit" class="btn btn-theme">YES</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">NO</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
                 
<?php $i++;}?>					  
                    </tbody>
                  </table>

                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
<?php include('include/footer.php');?>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $(".example1").DataTable();
        $("#example3").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    <script type = "text/javascript">
		$(document).ready(function(){
			$result = $('<center><label>Deleting...</label></center>');
			$('.deladmin_id').click(function(){
				$admin_id = $(this).attr('value');
				$(this).parents('td').empty().append($result);
				$('.deladmin_id').attr('disabled', 'disabled');
				$('.eadmin_id').attr('disabled', 'disabled');
				setTimeout(function(){
					window.location = 'delete_product.php?prod_id=' + $admin_id;
				}, 1000);
			});
		});
	</script>

</body>
</html>