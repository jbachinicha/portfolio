<!DOCTYPE html>
<?php
    require_once 'valid.php';
?>  
<html>
  <head>

    <title>WGB Construction Supply</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style1.css" rel="stylesheet">
    <link href="assets/css/css.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
  </head>

  <body onload="getTime()">
	  	<div class="container">
	  	
	  		<div id="showtime"></div>
	  			<div class="col-lg-4 col-lg-offset-4">
	  				<div class="lock-screen">
		  				<h2><a data-toggle="modal" href="#myModal"><i class="fa fa-lock"></i></a></h2>
		  				<p style="color: #FFF;">UNLOCK</p>
		  				
				          <form enctype = "multipart/form-data" class="form-login">
				          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
				              <div class="modal-dialog">
				                  <div class="modal-content">
				                      <div class="modal-header">
				                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				                          <h4 class="modal-title">Welcome Back</h4>
				                      </div>
				                      <div class="modal-body">
				                          <p class="centered"><img class="img-circle" width="80" src="assets/img/users.png"></p>
                                            <div id = "password_warning" class = "form-group">
                                                <input type="password" name="password" id = "password" placeholder="Password" autocomplete="off" class="form-control placeholder-no-fix">
                                            </div>
				
				                      </div>
				                      <div class="modal-footer centered">
				                        <div class = "form-group">
                                            <button class="btn btn-theme03" id = "login" type="button">Login</button>
                                            <button data-dismiss="modal" class="btn btn-theme04" type="button">Cancel</button>
                                        </div>
                                        <div id = "result"></div>
				                      </div>
				                  </div>
				              </div>
				          </div>
                      </form>
		  				
		  				
	  				</div>
	  			</div>
	  	
	  	</div>

    
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script type="text/javascript" src="js/lock.js"></script>
    <script>
        // $.backstretch("assets/img/images-18.jpeg", {speed: 500});
    </script>

    <script>
        function getTime()
        {
            var today=new Date();
            var h=today.getHours();
            var m=today.getMinutes();
            var s=today.getSeconds();
            // add a zero in front of numbers<10
            m=checkTime(m);
            s=checkTime(s);
            document.getElementById('showtime').innerHTML=h+":"+m+":"+s;
            t=setTimeout(function(){getTime()},500);
        }

        function checkTime(i)
        {
            if (i<10)
            {
                i="0" + i;
            }
            return i;
        }
    </script>

  </body>
</html>
