

<?php
	require_once 'connect.php';
	include('valid.php');
	if(ISSET($_POST['submit'])){
		$product_name = $_POST['prod_name'];
		$qty = $_POST['qty'];
		$id = $_SESSION['admin_id'];
		$date = date("Y-m-d H:i:s");

		$query=mysqli_query($conn,"select prod_name from inventory where prod_id='$product_name'")or die(mysqli_error($conn));
  		while ($row=mysqli_fetch_array($query)) {
  			$product=$row['prod_name'];
			$remarks="added $qty of $product"; 
			

			mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));
		
		
	mysqli_query($conn,"UPDATE inventory SET prod_qty=prod_qty+'$qty' where prod_id='$product_name'") or die(mysqli_error($conn)); 
			
			mysqli_query($conn,"INSERT INTO stockin(prod_id,qty,date) VALUES('$product_name','$qty','$date')")or die(mysqli_error($conn));

			header("location: inventory.php");
  		}  
	}
	?>