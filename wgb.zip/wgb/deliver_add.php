<?php 
	require_once 'connect.php';
	include('valid.php');
	$id=$_SESSION['admin_id'];
	$discount = $_POST['discount'];
	$amount_due = $_POST['amount_due'];
	$date = date("Y-m-d H:i:s");
	$cid=$_REQUEST['cid'];
	$total=$amount_due-$discount;
	$cid=$_REQUEST['cid'];
	$del_date=$_POST['del_date'];

	$tendered = $_POST['tendered'];
	$change = $_POST['change'];

	$quan=mysqli_query($conn,"SELECT * FROM temp_trans")or die(mysqli_error($conn));
	$row=mysqli_fetch_array($quan);
	$qty=$row['qty'];



		mysqli_query($conn,"INSERT INTO events_details VALUES('','$cid','$tendered','$discount','$amount_due','$change','$date','$total','$qty')")or die(mysqli_error($conn));
		
	$sales_id=mysqli_insert_id($conn);
	$_SESSION['sid']=$sales_id;
	$query=mysqli_query($conn,"SELECT * FROM temp_trans")or die(mysqli_error($conn));
		while ($row=mysqli_fetch_array($query))
		{
			$pid=$row['prod_id'];	
 			$qty=$row['qty'];
			$price=$row['price'];
			$prod=$row['product'];
			
			
			
			mysqli_query($conn,"INSERT INTO events VALUES('','$sales_id','$pid','$price','$qty','$prod','$del_date','0')")or die(mysqli_error($conn));
				
		}
			
		
		$result=mysqli_query($conn,"DELETE FROM temp_trans where admin_id='$id'")	or die(mysqli_error($conn));
		header("location: deliver_form.php"); 	
		
	
?>