<?php
	require_once 'connect.php';
  	include('valid.php');
	
	$rate		= $_POST['rate'];
	$id = $_SESSION['admin_id'];
	$date = date("Y-m-d H:i:s");
	$remarks="updated the overtime rate to $rate";  


	mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));
	mysqli_query($conn,"UPDATE `overtime` SET rate='$rate' WHERE ot_id='1'")or die(mysqli_error($conn));
			
	echo '
		<script type = "text/javascript">
		alert("Save Changes");
		window.location = "manage_employee_payroll.php";
		</script>
	';

 ?>