<?php
	require_once 'connect.php';
	include('valid.php');
	if(ISSET($_POST['edit_admin'])){	
		$employee_id = $_POST['employee_id'];
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$position = $_POST['position'];
		$schedule = $_POST['schedule'];
		$gender = $_POST['gender'];
		$date_employed = $_POST['date_employed'];
		$id = $_SESSION['admin_id'];
		$date = date("Y-m-d H:i:s");
		$remarks="updated $firstname info";  

		$pic = $_FILES["image"]["name"];
			if ($pic=="")
			{	
				if ($_POST['image1']<>""){
					$pic=$_POST['image1'];
				}
				else
					$pic="default.gif";
			}
			else
			{
				$pic = $_FILES["image"]["name"];
				$type = $_FILES["image"]["type"];
				$size = $_FILES["image"]["size"];
				$temp = $_FILES["image"]["tmp_name"];
				$error = $_FILES["image"]["error"];
			
				if ($error > 0){
					die("Error uploading file! Code $error.");
					}
				else{
					if($size > 100000000000) //conditions for the file
						{
						die("Format is not allowed or file size is too big!");
						}
				else
				      {
					move_uploaded_file($temp, "dist/uploads/".$pic);
				      }
					}
			
			}


			mysqli_query($conn,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($conn));
			mysqli_query($conn,"UPDATE `employee` SET `first_name` = '$firstname', `middle_name` = '$middlename', `last_name` = '$lastname', `address` = '$address', `phone` = '$phone', `date_employed` = '$date_employed', `position_id` = '$position', `schedule_id` = '$schedule',  `gender` = '$gender', `pic` = '$pic' WHERE `employee_id` = '$_REQUEST[employee_id]'")or die(mysqli_error($conn));
			
			header("location: manage_employee.php");
	}	