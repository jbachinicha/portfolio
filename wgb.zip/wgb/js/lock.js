$(document).ready(function(){
	$error = $('<center><label class = "text-danger">Please fill up the form</label></center>');
	$error1 = $('<center><label class = "text-danger">Invalid password</label></center>');
	$loading = $('<center><div class="progress progress-striped active"><div class="progress-bar"  role="progressbar" aria-valuenow="100" aria-valuemin="100" aria-valuemax="100" style="width: 100%"></div></div></center>');
	$('#login').click(function(){
		$error.remove();
		$error1.remove();
		$('#password').focus(function(){	
			$('#password_warning').each(function(){
				$(this).removeClass('has-error has-feedback');
				$(this).find('span').remove();
			});
		});	
		$password = $('#password').val();
		if($password == ""){
			$error.appendTo('#result');
			$('#password_warning').addClass('has-error has-feedback');
			$('<span class = "glyphicon glyphicon- form-control-feedback"></span>').appendTo('#password_warning');
		}else{
			$loading.appendTo('#result');
			setTimeout(function(){	
				$.post('check_lock.php', {password: $password},
					function(result){
						if(result == 'Success'){
							window.location  = 'check.php';
						}else{
							$loading.remove();
							$error1.appendTo('#result');
						}
					}
				)
			}, 1000);	
		}
	});
});