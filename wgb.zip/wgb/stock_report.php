<!DOCTYPE HTML>
<?php
	require_once 'valid.php';
?>	
<html>
<head>
<title>WGB Construction Supply</title>
<?php include('include/head_scripts.php');?>
</head> 

<body>
   <div class="page-container">
   	<div class="noprint">
    <?php include('include/header.php');?>
    <?php include('include/logout_modal.php');?>
</div>

<div class="left-content">
	   <div class="mother-grid-inner" style="padding-top: 80px;">
<!--heder end here-->
		<ol class="breadcrumb noprint">
        <li class="breadcrumb-item"><a href="home.php">Home</a> <i class="fa fa-angle-right"></i> Inventory <i class="fa fa-angle-right"></i> Stock Report</li>
    </ol>
    <section class="content breadcrumb">
            <div class="row">
      <div class="col-xs-12">
              <div class="box box-primary">
          
              
                <div class="box-body">
        <?php include('connect.php'); ?>
        <center>      
                  <h5><b>Jinska Water Station</b> </h5>  
                  <h6>Address: Sabang, Sibonga, Cebu</h6>
                  <h6>Contact #: 09353993218</h6>
          <h5><b>Product Inventory as of today, <?php echo date("M d, Y h:i a");?></b></h5></center>
           
          <a class = "btn btn-danger noprint" href = "inventory.php"><i class ="fa fa-arrow-left" style="color: #fff;"></i> Back</a> 
          <a class = "btn btn-theme btn-print noprint" href = "" onclick = "window.print()"><i class ="glyphicon glyphicon-print" style="color: #fff;"></i> Print</a> <br>  <br> 
            
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
          
                      <tr>
                        <th>Product Code</th> 
                        <th>Product Name</th>                      
                        <th>Qty Left</th>
                        <th>Qty Added</th>
                        <th>Date Stocked</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Reorder</th>
                       
                      </tr>
                    </thead>
                    <tbody>
<?php
    $query=mysqli_query($conn,"select * from inventory join stockin")or die(mysqli_error());
    $grand=0;
    while($row=mysqli_fetch_array($query)){
      $total=$row['prod_price']*$row['prod_qty'];
      $grand+=$total;
?>
                      <tr>
                        <td><?php echo $row['serial'];?></td>
                        <td><?php echo $row['prod_name'];?></td>
                        <td><?php echo $row['prod_qty'];?></td>
                        <td><?php echo $row['qty'];?></td>
                        <td><?php echo $row['date'];?></td>
            
            <td><?php echo $row['prod_price'];?></td>
            <td><?php echo number_format($total,2);?></td>
            <td class="text-center"><?php if ($row['prod_qty']<=$row['reorder'])echo "<span class='badge bg-red' style='background-color: red;'><i class='fa fa-refresh' style='color: #fff;'></i> Reorder</span>";?></td>
                       
                      </tr>

<?php }?>           
                    </tbody>
                    <tfoot>
                      <tr>
                        <th colspan="6">Total</th>
                        
            
            <th colspan="2">P<?php echo number_format($grand,2);?></th>
<?php
    $query=mysqli_query($conn,"SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'")or die(mysqli_error($con));
    $row=mysqli_fetch_array($query);
    $name = $row['firstname']." ".$row['lastname'];
 
?>                      
                             
                    </tfoot>
                  </table>
                  <label>Prepared By: <?php echo $name;?></label>
                </div><!-- /.box-body -->

        </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

          </section>
    
<!--inner block end here-->
<!--copy rights start here-->

<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
		<!--/sidebar-menu-->
<div class="noprint"><?php include('include/footer.php');?></div>
</body>
</html>